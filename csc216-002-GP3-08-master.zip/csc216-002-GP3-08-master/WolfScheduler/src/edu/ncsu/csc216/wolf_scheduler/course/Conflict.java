/**
 * 
 */
package edu.ncsu.csc216.wolf_scheduler.course;

/**
 * Checks for conflicts between two Activities 
 * and throws a Conflict Exception.
 * @author Amiya Renavikar
 */
public interface Conflict {

	/**
	 * Checks for Conflict.
	 * @param possibleConflictingActivity possible conflict
	 * @throws ConflictException if there is a conflict
	 */
	void checkConflict(Activity possibleConflictingActivity) throws ConflictException;
}
