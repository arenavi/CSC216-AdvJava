/**
 * 
 */
package edu.ncsu.csc216.wolf_scheduler.course;

/**
 * Extends the Exception super class and handles the functionality
 * of the Conflict Exception that is thrown between two similar activities.
 * @author Amiya Renavikar
 */
public class ConflictException extends Exception {

	/** ID used for serialization. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Parameterized constructor constructs the Conflict Exception.
	 * @param message message to be displayed
	 */
	public ConflictException(String message) {
		
		super(message);
	}
	
	/**
	 * Constructs the default message to be passed.
	 */
	public ConflictException() {
		
		super("Schedule conflict.");
	}
 }
