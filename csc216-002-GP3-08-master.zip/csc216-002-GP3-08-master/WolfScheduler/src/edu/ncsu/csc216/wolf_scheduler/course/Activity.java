package edu.ncsu.csc216.wolf_scheduler.course;

/**
 * Handles functionality and implementation for an Activity
 * and for its subclasses Event and Course.
 * @author Amiya Renavikar
 */
public abstract class Activity implements Conflict {


	/** Course's title. */
	private String title;
	
	/** Course's meeting days */
	private String meetingDays;
	
	/** Course's starting time */
	private int startTime;
	
	/** Course's ending time */
	private int endTime;

	/**
	 * Constructs the Activity class.
	 * @param title Activity title
	 * @param meetingDays Activity meetingDays
	 * @param startTime Activity startTime
	 * @param endTime Activity endTime
	 */
	public Activity(String title, String meetingDays, int startTime, int endTime) {
		
		setTitle(title);
		setMeetingDays(meetingDays);
		setActivityTime(startTime, endTime);
		
	}

	/**
	 * Returns the Course's title.
	 * @return title course title
	 */
	public String getTitle() {
		
		return title;
	}

	/**
	 * Sets the Course's title. If the title is null or empty, an
	 * IllegalArgumentException is thrown.
	 * 
	 * @param title
	 *            the title to set
	 * @throws IllegalArgumentException
	 *             if title is null or empty
	 */
	public void setTitle(String title) {
		if (title == null || title.equals("")) {
			throw new IllegalArgumentException();
		}
		this.title = title;
	}

	/**
	 * Returns the days that the Course meets
	 * 
	 * @return the meetingDays meeting days
	 */
	public String getMeetingDays() {
		return meetingDays;
	}

	/**
	 * Sets the days that the Course meets. If meeting days are anything besides
	 * 'M', 'T', 'W', 'H', 'F', or 'A', an IllegalArgumentException is thrown.
	 * If 'A' is in the meeting days list, it must be the only character.
	 * 
	 * @param meetingDays
	 *            meeting days
	 * @throws IllegalArgumentException
	 *             if meeting days are anything besides 'M', 'T', 'W', 'H', 'F',
	 *             or 'A', an IllegalArgumentException is thrown.
	 */
	public void setMeetingDays(String meetingDays) {
	
		this.meetingDays = meetingDays;
	}

	/**
	 * Returns the start time of the Course
	 * 
	 * @return the startTime start time
	 */
	public int getStartTime() {
		return startTime;
	}

	/**
	 * Returns the end time of the Course
	 * 
	 * @return the endTime end time
	 */
	public int getEndTime() {
		return endTime;
	}
	

	/**
	 * Sets the Activity Time.
	 * @param startTime Course start time
	 * @param endTime Course end time
	 */
	public void setActivityTime(int startTime, int endTime) {
	
		if (meetingDays.equals("A") && (startTime != 0 || endTime != 0)) {
			
			throw new IllegalArgumentException();
		}
		
		if (startTime < 0000 || startTime > 2359) {
	
			throw new IllegalArgumentException();
		}
	
		if (endTime % 100 > 59 || startTime % 100 > 59) {
	
			throw new IllegalArgumentException();
		}
		
		if (endTime < 0000 || endTime > 2359) {
			
			throw new IllegalArgumentException();
		}
		
		if (endTime < startTime) {
			
			throw new IllegalArgumentException();
		}
	
		this.startTime = startTime;
		this.endTime = endTime;
	}

	/**
	 * Returns the meeting days in AM/PM.
	 * @return meeting days in AM/PM
	 */
	public String getMeetingString() {
	
		String standard = "AM";
		
		String actualTime = null;
		
		int fst = startTime;
		
		int est = endTime;
		
		String ft = null;
		
		String et = null;
		
		if (meetingDays.equals("A")) {
			
			actualTime = "Arranged";
			
		} else {
			
			if (fst >= 1300) {
				
				standard = "PM";
				
				fst = fst - 1200;
				String s = String.valueOf(fst);
				s = s.substring(0, 1) + ":" + s.substring(1, 3);
				
				ft = s + standard;
				
			} else if (fst < 1000) {
				
				standard = "AM";
				
				String s = String.valueOf(fst);
				s = s.charAt(0) + ":" + s.substring(1, 3);
				
				ft = s + standard;
				
			} else if (fst >= 1200 && fst <= 1300) {
				
				standard = "PM";
				
				
				String s = String.valueOf(fst);
				s = s.substring(0, 2) + ":" + s.substring(2, 4);
				
				ft = s + standard;
				
		    } else if (fst >= 1000 && fst < 1200) {
				
				standard = "AM";
				
				String s = String.valueOf(fst);
				s = s.substring(0, 2) + ":" + s.substring(2, 4);
				
				
				ft = s + standard;
				
			} else if (fst == 1200) {
				
				standard = "PM";
				
				String s = String.valueOf(fst);
				s = s.substring(0, 2) + ":" + s.substring(2, 4);
				
				ft = s + standard;
			}
			
			
			if (est >= 1300) {
				
				standard = "PM";
				
				est = est - 1200;
				
				String t = String.valueOf(est);
				t = t.substring(0, 1) + ":" + t.substring(1, 3);
				
				et = t + standard;
				
				
			} else if (est < 1000) {
				
				standard = "AM";
				
				String t = String.valueOf(est);
				t = t.charAt(0) + ":" + t.substring(1, 3);
				
				et = t + standard;
				
			} else if (est >= 1200 && est <= 1300) {
				
				standard = "PM";
				
				
				String t = String.valueOf(est);
				t = t.substring(0, 2) + ":" + t.substring(2, 4);
				
				et = t + standard;
				
		    } else if (est >= 1000 && est < 1200) {
				
				standard = "AM";
				
				String t = String.valueOf(est);
				t = t.substring(0, 2) + ":" + t.substring(2, 4);
				
				et = t + standard;
				
			} else if (est == 1200) {
				
				standard = "PM";
				
				String t = String.valueOf(fst);
				t = t.substring(0, 2) + ":" + t.substring(2, 4);
				
				et = t + standard;
			} 
			
			
			actualTime = meetingDays + " " + ft + "-" + et;
		}
		
		
		return actualTime;
	}

	/**
	 * Returns the hashCode of Activity class.
	 * @return result hash code
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + endTime;
		result = prime * result + ((meetingDays == null) ? 0 : meetingDays.hashCode());
		result = prime * result + startTime;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	/**
	 * Returns true if the two objects are equal.
	 * @return true if objects are equal, false if not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Activity other = (Activity) obj;
		if (endTime != other.endTime)
			return false;
		if (meetingDays == null) {
			if (other.meetingDays != null)
				return false;
		} else if (!meetingDays.equals(other.meetingDays))
			return false;
		if (startTime != other.startTime)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	
	/**
	 * Returns the short display array of length 4.
	 * @return short display array
	 */
	public abstract String[] getShortDisplayArray();
	
	/**
	 * Returns the long display array of length 7.
	 * @return long display array
	 */
	public abstract String[] getLongDisplayArray();
	
	/**
	 * Returns true if the object is an object of Activity class.
	 * @param activity Activity
	 * @return true is Activity object is duplicate
	 */
	public abstract boolean isDuplicate(Activity activity);
	
	/* (non-Javadoc)
	 * @see edu.ncsu.csc216.wolf_scheduler.course.Conflict#checkConflict(edu.ncsu.csc216.wolf_scheduler.course.Activity)
	 */
	@Override
	public void checkConflict(Activity possibleConflictingActivity) throws ConflictException {
		
		
		if ((meetingDays.equals("A")) || possibleConflictingActivity.getMeetingDays().equals("A")) {
					
			return;
				
		}
				
				
		for (int i = 0 ; i < this.getMeetingDays().length(); i++) {
			
			if (possibleConflictingActivity.getMeetingDays().contains("" + this.getMeetingDays().charAt(i))){
					
				if ((this.getStartTime() >= possibleConflictingActivity.getStartTime() && this.getStartTime() <= possibleConflictingActivity.getEndTime())){
							
					throw new ConflictException();
				}
						
				if ((possibleConflictingActivity.getStartTime() >= this.getStartTime() && possibleConflictingActivity.getStartTime() <= this.getEndTime())) {
							
					throw new ConflictException();
				}
		    }
		
	   }
		
	}	
	
}