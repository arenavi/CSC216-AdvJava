/**
 * 
 */
package edu.ncsu.csc216.wolf_scheduler.course;

/**
 * Handles all the functionality and implementation of an Event 
 * by extending the Activity class.
 * @author Amiya Renavikar
 */
public class Event extends Activity {
	
	/** Weekly Repeat */
	private int weeklyRepeat;
	
	/** Event Details */
	private String eventDetails;

	/**
	 * Constructs the Event class.
	 * @param title Event title
	 * @param meetingDays Event meeting days
	 * @param startTime Event start time
	 * @param endTime Event end time
	 * @param weeklyRepeat Event weekly repeat
	 * @param eventDetails Event details
	 */
	public Event(String title, String meetingDays, int startTime, int endTime, int weeklyRepeat, String eventDetails) {
		
		super(title, meetingDays, startTime, endTime);
		
		try {
			
			setWeeklyRepeat(weeklyRepeat);
			setEventDetails(eventDetails);
			
		} catch(IllegalArgumentException e) {
			
			throw new IllegalArgumentException();
			
		}
		
		
	}

	/**
	 * Returns the number of times Event repeats weekly.
	 * @return weeklyRepeat no. of time event repeats weekly
	 */
	public int getWeeklyRepeat() {
		
		return weeklyRepeat;
	}

	/**
	 * Sets the number of times that the Event repeats weekly.
	 * @param weeklyRepeat no. of time event repeats weekly
	 * @throws IllegalArgumentException if parameter is less than 1 or greater than 4
	 */
	public void setWeeklyRepeat(int weeklyRepeat) {
		
		if (weeklyRepeat < 1 || weeklyRepeat > 4) {
			
			throw new IllegalArgumentException("Invalid weekly repeat");
		}
		
		this.weeklyRepeat = weeklyRepeat;
	}

	/**
	 * Returns the Event details.
	 * @return eventDetails Event details
	 */
	public String getEventDetails() {
		
		return eventDetails;
	}

	/**
	 * Sets the Event details.
	 * @param eventDetails Event details
	 * @throws IllegalArgumentException if eventDetails parameter is null
	 */
	public void setEventDetails(String eventDetails) {
		
		if (eventDetails == null) {
			
			throw new IllegalArgumentException("Invalid event details");
			
		}
		
		this.eventDetails = eventDetails;
	}

	/**
	 * Returns the short display array of length 4.
	 */
	@Override
	public String[] getShortDisplayArray() {
		
		String[] sd = new String[4];
		
		sd[0] = "";
		sd[1] = "";
		sd[2] = getTitle();
		sd[3] = getMeetingString();
		
		return sd;
	}

	/**
	 * Returns the long display array of length 7.
	 */
	@Override
	public String[] getLongDisplayArray() {
		
		String[] ld = new String[7];
		
		ld[0] = "";
		ld[1] = "";
		ld[2] = getTitle();
		ld[3] = "";
		ld[4] = "";
		ld[5] = getMeetingString();
		ld[6] = eventDetails;
		
		return ld;
	}

	/**
	 * Returns the meeting period as a String.
	 * @return meeting period
	 */
	@Override
	public String getMeetingString() {
		
		return super.getMeetingString() + " (every " + weeklyRepeat + " weeks)";
		
	}

	/**
	 * Returns a String representation of the Event.
	 * @return event
	 */
	@Override
	public String toString() {
		
		return getTitle() + "," + getMeetingDays() + "," + Integer.toString(getStartTime()) + "," + Integer.toString(getEndTime()) + "," + weeklyRepeat + "," + eventDetails;
		
	}
	
	/**
	 * Returns true if object belongs to Activity class.
	 * @param activity Activity class object
	 */
	@Override
	public boolean isDuplicate(Activity activity) {
	
		try {
			
			Event e = (Event) activity;
			
			if (e.getTitle().equals(this.getTitle())) {
				
				return true;
			}
			
		} catch(ClassCastException e) {
			
			return false;
		}
		return false;
		
	}

	/* (non-Javadoc)
	 * @see edu.ncsu.csc216.wolf_scheduler.course.Activity#setMeetingDays(java.lang.String)
	 */
	@Override
	public void setMeetingDays(String meetingDays) {
		
		if (meetingDays == null || meetingDays.equals("")) {
			
			throw new IllegalArgumentException();
		}
	
		String sample = "MTWHFSU";
		
		for (int i = 0; i < meetingDays.length(); i++) {
			
			if (!(sample.contains(String.valueOf(meetingDays.charAt(i))))) {
		
				throw new IllegalArgumentException();
			}
		}
		
		if (meetingDays.equals("A") && meetingDays.length() != 1) {
			
			throw new IllegalArgumentException();
		}
		
		super.setMeetingDays(meetingDays);
		
	}

}
