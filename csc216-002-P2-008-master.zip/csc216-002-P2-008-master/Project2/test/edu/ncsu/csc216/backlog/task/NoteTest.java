package edu.ncsu.csc216.backlog.task;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the Note class.
 * @author Amiya Renavikar
 *
 */
public class NoteTest {

    /**
     * Tests the Note class constructor.
     */
    @Test
    public void testNote() {
        
        try {
            
            @SuppressWarnings("unused")
            Note n = new Note(null, "note");
            fail();
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
    }
    
    /**
     * Tests the getNoteAuthor method.
     */
    @Test
    public void testGetNoteAuthor() {
        
        Note n1 = new Note("candice", "please fix");
        assertEquals("candice", n1.getNoteAuthor());
    }
    
    /**
     * Tests the getNoteText method.
     */
    @Test
    public void testGetNoteText() {
        
        Note n1 = new Note("candice", "please fix");
        assertEquals("please fix", n1.getNoteText());
    }
    
    /**
     * Tests the getNoteArray method.
     */
    @Test
    public void testGetNoteArray() {
        
        Note n1 = new Note("amiya", "please fix");
        assertEquals("amiya", n1.getNoteArray()[0]);
        assertEquals("please fix", n1.getNoteArray()[1]);
    }

}
