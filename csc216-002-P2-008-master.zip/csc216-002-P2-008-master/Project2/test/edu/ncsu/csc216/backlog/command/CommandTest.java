/**
 * 
 */
package edu.ncsu.csc216.backlog.command;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.backlog.command.Command.CommandValue;

/**
 * Tests the Command class.
 * @author Amiya Renavikar
 */
public class CommandTest {
    
    /** Command c */
    @SuppressWarnings("unused")
    private Command c;
    
    /** Command c1 */
    @SuppressWarnings("unused")
    private Command c1;
    
    /** Command c2 */
    private Command c2;
    
    /** Command c3 */
    private Command c3;
    
    /** Command c4 */
    @SuppressWarnings("unused")
    private Command c4;
    
    /** Command c5 */
    @SuppressWarnings("unused")
    private Command c5;

    /**
     * Sets up the environment for testing.
     */
    @Before
    public void setUp() {
        
        c = new Command(CommandValue.BACKLOG, "arenavi", "note text");
        c1 = new Command(CommandValue.CLAIM, "arenavi", "note text");
        c2 = new Command(CommandValue.PROCESS, "arenavi", "note text");
        c3 = new Command(CommandValue.VERIFY, "arenavi", "note text");
        c4 = new Command(CommandValue.COMPLETE, "arenavi", "note text");
        c5 = new Command(CommandValue.REJECT, "arenavi", "note text");
        
    }

    /**
     * Tests the Constructor.
     */
    @Test
    public void testCommand() {
        
        
        try {
           
            c1 = new Command(null, "amiya", "solve this");
            fail();
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
        
        try {
            
            c2 = new Command(null, "", "solve this");
            fail();
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
        
        boolean t = true;
        try {
            
            c3 = new Command(CommandValue.BACKLOG, "arenavi", null);
            t = false;
            fail();
        } catch (IllegalArgumentException e) {
            
            assertTrue(t);
        }
        
        try {
            
            c4 = new Command(CommandValue.CLAIM, "arenavi", "");
            t = false;
            fail();
        } catch (IllegalArgumentException e) {
            
            assertTrue(t);
        }
        
    }
    
    /**
     * Tests the getCommand methos and commandValue enum.
     */
    @Test
    public void testGetCommand() {
        
        c3 = new Command(CommandValue.COMPLETE, "amiya", "fix");
        
        assertEquals(CommandValue.COMPLETE, c3.getCommand());
        
        CommandValue.valueOf(CommandValue.BACKLOG.toString());
    }
    
    /**
     * Tests the getNoteText method.
     */
    @Test
    public void testGetNoteText() {
        
        c2 = new Command(CommandValue.VERIFY, "amiya", "fix");
        
        assertEquals("fix", c2.getNoteText());
    }
    
    /**
     * Tests the getNoteAuthor method.
     */
    @Test
    public void testGetNoteAuthor() {
        
        c3 = new Command(CommandValue.PROCESS, "amiya", "fix");
        
        assertEquals("amiya", c3.getNoteAuthor());
    }

}
