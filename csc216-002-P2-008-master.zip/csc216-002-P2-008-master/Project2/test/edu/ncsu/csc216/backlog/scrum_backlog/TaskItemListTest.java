/**
 * 
 */
package edu.ncsu.csc216.backlog.scrum_backlog;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import edu.ncsu.csc216.backlog.command.Command;
import edu.ncsu.csc216.backlog.command.Command.CommandValue;
import edu.ncsu.csc216.backlog.task.TaskItem;
import edu.ncsu.csc216.backlog.task.TaskItem.Type;
import edu.ncsu.csc216.task.xml.NoteList;
import edu.ncsu.csc216.task.xml.Task;

/**
 * Tests the TaskItemList class.
 * @author Amiya Renavikar
 */
public class TaskItemListTest {

    /**
     * Tests the taskItemList() method.
     */
    @Test
    public void testTaskItemList() {
        
        TaskItemList l = new TaskItemList();
        
        try {
            
            assertNull(l.addTaskItem("express cart", null, "arenavi", "shortest line"));
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
        
    }
    
    /**
     * Tests the addTaskItem() method.
     */
    @Test
    public void testAddTaskItem() {
        
        TaskItemList l = new TaskItemList();
        assertEquals(1, l.addTaskItem("some cart", Type.FEATURE, "jep", "type of cart"));
    }
    
    /**
     * Tests the getTaskItems() method.
     */
    @Test
    public void testGetTaskItems() {
        
        TaskItemList l = new TaskItemList();
        l.addTaskItem("some cart", Type.FEATURE, "jep", "type of cart");
        List<TaskItem> ll = l.getTaskItems();
        
        assertEquals(1, ll.size());
        
    } 
    
    /**
     * Tests the getTaskItemsByCreator() method.
     */
    @Test
    public void testGetTaskItemsByCreator() {
        
        TaskItemList l = new TaskItemList();
        l.addTaskItem("some cart", Type.FEATURE, "jep", "type of cart");
        l.addTaskItem("cart", Type.FEATURE, "arenavi", "type");
        List<TaskItem> ll = l.getTasksByCreator("arenavi");
        
        assertEquals("arenavi", ll.get(0).getCreator());
        
        try {
            
            l.getTasksByCreator(null);
        } catch (IllegalArgumentException e) {
            
            // do nothing
        }
        
        
    }

    /**
     * Tests the getTaskItemsByOwner() method.
     */
    @Test
    public void testGetTaskItemsByOwner() {
        
        TaskItemList l = new TaskItemList();
        l.addTaskItem("some cart", Type.FEATURE, "jep", "type of cart");
        l.addTaskItem("cart", Type.FEATURE, "arenavi", "type");
        
        try {
            
            assertNull(l.getTaskItemsByOwner(null));
        } catch (IllegalArgumentException e) {
            
            // do nothing
        }
        
    }
    
    /**
     * Tests the getTaskItemsById() method.
     */
    @Test
    public void testGetTaskItemsById() {
        
        TaskItemList l = new TaskItemList();
        l.addTaskItem("some cart", Type.FEATURE, "jep", "type of cart");
        l.addTaskItem("cart", Type.FEATURE, "arenavi", "type");
        
        TaskItem t = l.getTaskItemById(2);
        assertEquals(2, t.getTaskItemId());
        
        l.deleteTaskItemById(2);
        assertEquals(1, l.getTaskItems().size());
        
    }
    
    /**
     * Tests the addXMLTasks method.
     */
    @Test
    public void testAddXMLTasks() {
        
        TaskItemList l = new TaskItemList();
        
        Task task = new Task();
        
        task.setTitle("RegularShoppingCart");
        task.setCreator("arenavi");
        task.setNoteList(new NoteList());
        
        task.setOwner("spider");
        task.setState("Backlog");
        task.setType("FEATURE");
        
        task.setId(1);
        
        
        Task task2 = new Task();
        
        task2.setTitle("ShoppingCart");
        task2.setCreator("ai");
        task2.setNoteList(new NoteList());
        
        task2.setOwner("ziekr");
        task2.setState("Processing");
        task2.setType("BUG");
        
        task2.setId(2);
        
        List<Task> ll = new ArrayList<Task>();
        
        ll.add(task);
        ll.add(task2);
        
        l.addXMLTasks(ll);
        
        List<TaskItem> tt = l.getTasksByCreator("arenavi");
        
        assertEquals(1, tt.size());
        
        Command com = new Command(CommandValue.BACKLOG, "arenavi", "abcd");
        
        try {
           l.executeCommand(1, com);
           assertEquals("Backlog", l.getTaskItemById(1).getStateName());
        } catch (UnsupportedOperationException e) {
            
            //do nothing
        }
        
    }
    
    
    
    
}
