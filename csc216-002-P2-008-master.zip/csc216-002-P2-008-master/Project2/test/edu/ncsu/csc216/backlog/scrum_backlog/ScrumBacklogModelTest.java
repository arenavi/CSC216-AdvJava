/**
 * 
 */
package edu.ncsu.csc216.backlog.scrum_backlog;

import static org.junit.Assert.*;


import java.util.List;

import org.junit.Test;

import edu.ncsu.csc216.backlog.command.Command;
import edu.ncsu.csc216.backlog.command.Command.CommandValue;
import edu.ncsu.csc216.backlog.task.TaskItem.Type;
import edu.ncsu.csc216.task.xml.Task;
import edu.ncsu.csc216.task.xml.TaskList;

/**
 * Tests the ScrumBacklogModel class.
 * @author Amiya Renavikar
 */
public class ScrumBacklogModelTest {

    /**
     * Tests the ScrumBacklog() method.
     */
    @Test
    public void testScrumBacklog() {
        
        ScrumBacklogModel sbm = ScrumBacklogModel.getInstance();
        
        assertNotNull(sbm);
    }
    
    /**
     * Tests the rest of the methods.
     */
    @Test
    public void test() {
        
        ScrumBacklogModel sbm = ScrumBacklogModel.getInstance();
        
        sbm.addTaskItemToList("express cart", Type.FEATURE, "arenavi", "short line");
        
        sbm.createNewTaskItemList();
        
        sbm.addTaskItemToList("regular cart", Type.FEATURE, "arenavi", "short line");
        
        sbm.addTaskItemToList("shopping cart", Type.FEATURE, "bee", "short line");
    
        assertEquals(2, sbm.getTaskItemListAsArray().length);
        
        assertEquals(1, sbm.getTaskItemListByCreatorAsArray("bee").length);
        
        try {
            
            @SuppressWarnings("unused")
            int a = sbm.getTaskItemListByCreatorAsArray(null).length;
            fail();
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
        
        assertEquals(0, sbm.getTaskItemListByOwnerAsArray("arenavi").length);
    
        try {
            
            @SuppressWarnings("unused")
            int a = sbm.getTaskItemListByOwnerAsArray(null).length;
            fail();
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
    }
    
    /**
     * Tests the other methods.
     */
    @Test
    public void testTwo() {
        
        ScrumBacklogModel sbm = ScrumBacklogModel.getInstance();
        sbm.addTaskItemToList("regular cart", Type.FEATURE, "arenavi", "short line");
        
        sbm.addTaskItemToList("shopping cart", Type.FEATURE, "bee", "short line");
    
        assertEquals("shopping cart", sbm.getTaskItemById(2).getTitle());
        
        sbm.deleteTaskItemById(1);
        
        assertEquals(1, sbm.getTaskItemListAsArray().length);
        
        sbm.executeCommand(2, new Command(CommandValue.CLAIM, "arenavi", "note"));
        
        TaskList list = new TaskList();
        
        @SuppressWarnings("unused")
        List<Task> ll = list.getTasks();
        
        sbm.saveTasksToFile("file.xml");
        
        try {
            
            sbm.loadTasksFromFile("test-files/task1.xml");
            
            fail();
        } catch (IllegalArgumentException e) {
            
            //do nothing
        }
        
    }

        
        
 
}
