/**
 * 
 */
package edu.ncsu.csc216.backlog.task;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import edu.ncsu.csc216.backlog.command.Command;
import edu.ncsu.csc216.backlog.command.Command.CommandValue;
import edu.ncsu.csc216.backlog.task.TaskItem.BacklogState;
import edu.ncsu.csc216.backlog.task.TaskItem.DoneState;
import edu.ncsu.csc216.backlog.task.TaskItem.OwnedState;
import edu.ncsu.csc216.backlog.task.TaskItem.ProcessingState;
import edu.ncsu.csc216.backlog.task.TaskItem.RejectedState;
import edu.ncsu.csc216.backlog.task.TaskItem.Type;
import edu.ncsu.csc216.backlog.task.TaskItem.VerifyingState;
import edu.ncsu.csc216.task.xml.Task;

/**
 * Tests the TaskItemTest class.
 * @author Amiya Renavikar
 */
public class TaskItemTest {
    
    /**
     * Tests the TaskItem() method.
     */
    @Test
    public void testTaskItem() {
        
        TaskItem ti = new TaskItem("express cart", Type.BUG, "carol", "work this");
        
        try {
            
            TaskItem.setCounter(-1);
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem(null, Type.KNOWLEDGE_ACQUISITION, "carol", "Work");
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem("express cart", null, "carol", "Work");
            fail();
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, null, "Work");
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "carol", null);
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem("", Type.KNOWLEDGE_ACQUISITION, "carol", "Work");
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "", "Work");
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        try {
            
            ti = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "carol", "");
        } catch (IllegalArgumentException e) {
            
            e.getMessage();
        }
        
        assertEquals("express cart", ti.getTitle());
        assertEquals(Type.BUG, ti.getType());
        assertEquals("B", ti.getTypeString());
        assertEquals("Bug", ti.getTypeFullString());
        ti = new TaskItem("express cart", Type.TECHNICAL_WORK, "a", "note");
        assertEquals(Type.TECHNICAL_WORK, ti.getType());
        assertEquals("TW", ti.getTypeString());
        assertEquals("Technical Work", ti.getTypeFullString());
        assertEquals("a", ti.getCreator());
        assertNotNull(ti.getType());
        ti = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "a", "note");
        assertEquals("KA", ti.getTypeString());
        assertEquals(Type.KNOWLEDGE_ACQUISITION, ti.getType());
        assertEquals("Knowledge Acquisition", ti.getTypeFullString());
        ti = new TaskItem("express cart", Type.FEATURE, "a", "note");
        assertEquals("F", ti.getTypeString());
        assertEquals(Type.FEATURE, ti.getType());
        assertEquals("Feature", ti.getTypeFullString());
        
        Type.valueOf(Type.FEATURE.toString());
    }

    /**
     * Tests the getNotes method and additional methods.
     */
    @Test
    public void testGetNotes() {
        
        TaskItem item = new TaskItem("express cart", Type.BUG, "carol", "work this");
        
        Note na = new Note("spider", "feature");
        Note nb = new Note("cat", "task");
        
        ArrayList<Note> arr = item.getNotes();
        arr.add(na);
        arr.add(nb);
        
        String[][] array = item.getNotesArray();
        
        assertEquals(3, array.length);
        
        Task ta = item.getXMLTask();
        assertEquals("carol", ta.getCreator());
    }
    
    /**
     * Tests the update() method and FSM methods.
     */
    @Test
    public void testUpdate() {
        
        TaskItem item = new TaskItem("express cart", Type.TECHNICAL_WORK, "bagel", "should work properly");
        
        assertEquals("Backlog", item.getStateName());
        item.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        assertEquals("Owned", item.getStateName());
        item.update(new Command(CommandValue.REJECT, "arenavi", "note text"));
        assertEquals("Rejected", item.getStateName());
        item.update(new Command(CommandValue.BACKLOG, "arenavi", "note text"));
        assertEquals("Backlog", item.getStateName());
        item.update(new Command(CommandValue.REJECT, "arenavi", "note text"));
        assertEquals("Rejected", item.getStateName());
        item.update(new Command(CommandValue.BACKLOG, "arenavi", "note text"));
        assertEquals("Backlog", item.getStateName());
        
        item.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        assertEquals("Owned", item.getStateName());
        item.update(new Command(CommandValue.BACKLOG, "arenavi", "note text"));
        assertEquals("Backlog", item.getStateName());
        try {
            
            item.update(new Command(CommandValue.VERIFY, "arenavi", "note"));
            fail();
        } catch (UnsupportedOperationException e) {
            
            assertEquals("Backlog", item.getStateName());
        }
        
        TaskItem item2 = new TaskItem("express cart", Type.TECHNICAL_WORK, "bagel", "should work properly");
        item2.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item2.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        assertEquals("Processing", item2.getStateName());
        item2.update(new Command(CommandValue.BACKLOG, "arenavi", "note text"));
        assertEquals("Backlog", item2.getStateName());
        
        TaskItem item3 = new TaskItem("express cart", Type.BUG, "bagel", "should work properly");
        item3.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item3.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        assertEquals("Processing", item3.getStateName());
        item3.update(new Command(CommandValue.VERIFY, "arenavi", "note text"));
        assertEquals("Verifying", item3.getStateName());
        
        TaskItem item4 = new TaskItem("express cart", Type.FEATURE, "bagel", "should work properly");
        item4.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item4.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        assertEquals("Processing", item4.getStateName());
        item4.update(new Command(CommandValue.VERIFY, "arenavi", "note text"));
        assertEquals("Verifying", item4.getStateName());
        
        TaskItem item5 = new TaskItem("express cart", Type.TECHNICAL_WORK, "bagel", "should work properly");
        item5.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item5.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        assertEquals("Processing", item5.getStateName());
        item5.update(new Command(CommandValue.VERIFY, "arenavi", "note text"));
        assertEquals("Verifying", item5.getStateName());
        item5.update(new Command(CommandValue.COMPLETE, "arenavi", "note"));
        assertEquals("Done", item5.getStateName());
        item5.update(new Command(CommandValue.PROCESS, "arenavi", "note"));
        assertEquals("Processing", item5.getStateName());
        item5.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        assertEquals("Processing", item5.getStateName());
        try {
            
            item5.update(new Command(CommandValue.COMPLETE, "arenavi", "note text"));
            fail();
        } catch (UnsupportedOperationException e) {
            
            assertEquals("Processing", item5.getStateName());
        }
        
        
        
        TaskItem item6 = new TaskItem("express cart", Type.TECHNICAL_WORK, "bagel", "should work properly");
        assertEquals("Backlog", item6.getStateName());
        try {
            
            item6.update(new Command(CommandValue.PROCESS, "arenavi", "note"));
            fail();
        } catch (UnsupportedOperationException e) {
            
            assertEquals("Backlog", item6.getStateName());
        }
        
        TaskItem item7 = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "bagel", "should work properly");
        assertEquals("Backlog", item7.getStateName());
        item7.update(new Command(CommandValue.CLAIM, "arenavi", "note"));
        item7.update(new Command(CommandValue.PROCESS, "arenavi", "note"));
        item7.update(new Command(CommandValue.COMPLETE, "arenavi", "note"));
        assertEquals("Done", item7.getStateName());
        
        TaskItem item8 = new TaskItem("express cart", Type.FEATURE, "bagel", "should work properly");
        assertEquals("Backlog", item8.getStateName());
        item8.update(new Command(CommandValue.CLAIM, "arenavi", "note"));
        item8.update(new Command(CommandValue.PROCESS, "arenavi", "note"));
        item8.update(new Command(CommandValue.VERIFY, "arenavi", "note"));
        assertEquals("Verifying", item8.getStateName());
        item8.update(new Command(CommandValue.PROCESS, "arenavi", "note"));
        assertEquals("Processing", item8.getStateName());
        item8.update(new Command(CommandValue.VERIFY, "arenavi", "note"));
        try {
            
            item8.update(new Command(CommandValue.BACKLOG, "arenavi", "note"));
            fail();
        } catch (UnsupportedOperationException e) {
            
            assertEquals("Verifying", item8.getStateName());
        }
        
        TaskItem item9 = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "bagel", "should work properly");
        item9.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item9.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        item9.update(new Command(CommandValue.COMPLETE, "arenavi", "note text"));
        assertEquals("Done", item9.getStateName());
        item9.update(new Command(CommandValue.BACKLOG, "arenavi", "note text"));
        assertEquals("Backlog", item9.getStateName());
        item9.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item9.update(new Command(CommandValue.PROCESS, "arenavi", "note text"));
        item9.update(new Command(CommandValue.COMPLETE, "arenavi", "note text"));
        try {
           
            item9.update(new Command(CommandValue.VERIFY, "arenavi", "note text"));
            fail();
        } catch (UnsupportedOperationException e) {
            
            assertEquals("Done", item9.getStateName());
        }
        
        TaskItem item10 = new TaskItem("express cart", Type.KNOWLEDGE_ACQUISITION, "bagel", "should work properly");
        item10.update(new Command(CommandValue.CLAIM, "arenavi", "note text"));
        item10.update(new Command(CommandValue.REJECT, "arenavi", "note text"));
        assertEquals("Rejected", item10.getStateName());
        try {
            
            item10.update(new Command(CommandValue.VERIFY, "arenavi", "note text"));
            fail();
        } catch (UnsupportedOperationException e) {
            
            assertEquals("Rejected", item10.getStateName());
        }
        
        VerifyingState s = item10.new VerifyingState();
        assertEquals("Verifying", s.getStateName());
        
        BacklogState b = item10.new BacklogState();
        assertEquals("Backlog", b.getStateName());
        
        OwnedState o = item10.new OwnedState();
        assertEquals("Owned", o.getStateName());
        
        ProcessingState p = item10.new ProcessingState();
        assertEquals("Processing", p.getStateName());
        
        DoneState d = item10.new DoneState();
        assertEquals("Done", d.getStateName());
        
        RejectedState r = item10.new RejectedState();
        assertEquals("Rejected", r.getStateName());
        
    }
    
    
    
}
