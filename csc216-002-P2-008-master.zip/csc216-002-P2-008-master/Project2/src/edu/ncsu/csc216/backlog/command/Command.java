
package edu.ncsu.csc216.backlog.command;

/**
 * Concrete class that encapsulates user interactions with the GUI 
 * for processing by the scrum backlog FSM in TaskItem.
 * @author Amiya Renavikar
 */
public class Command {
    
    /** Note String */
    private String note;
    
    /** Note Author */
    private String noteAuthor;
    
    /** Command value */
    private CommandValue c;
    
    /**
     * Constructs the Command class.
     * @param c Command Value
     * @param noteAuthor note author
     * @param note note text
     * @throws IllegalArgumentException if any of the parameters are null or empty strings
     */
    public Command(CommandValue c, String noteAuthor, String note) {
        
        if (c == null || noteAuthor == null || noteAuthor.equals("") || note == null || note.equals("")) {
            
            throw new IllegalArgumentException();
        }
        
        this.c = c;
        this.note = note;
        this.noteAuthor = noteAuthor;
    }
    
    /**
     * Returns the command value.
     * @return c Command Value
     */
    public CommandValue getCommand() {
        
        return c;
    }
    
    /**
     * Returns the note text.
     * @return note Note text
     */
    public String getNoteText() {
        
        return note;
    }
    
    /**
     * Returns the note author.
     * @return noteAuthor note author
     */
    public String getNoteAuthor() {
        
        return noteAuthor;
    }
    
    /**
     * Acts as enum for Command class.
     * @author Amiya Renavikar
     */
    public static enum CommandValue { BACKLOG, CLAIM, PROCESS, VERIFY, COMPLETE, REJECT }

}
