
package edu.ncsu.csc216.backlog.scrum_backlog;

import java.util.ArrayList;
import java.util.List;

import edu.ncsu.csc216.backlog.command.Command;
import edu.ncsu.csc216.backlog.task.TaskItem;
import edu.ncsu.csc216.backlog.task.TaskItem.Type;
import edu.ncsu.csc216.task.xml.Task;

/**
 * Concrete class that maintains the current list of TaskItems
 * in the Scrum Backlog system.
 * @author Amiya Renavikar
 */
public class TaskItemList {

    /** Initial counter value */
    public static final int INITIAL_COUNTER_VALUE = 1;
    
    /** Instance of TaskItem */
    private ArrayList<TaskItem> tasks;
    
    /**
     * Constructs the TaskItemList by maintaining a list of task items.
     */
    public TaskItemList() { 
        
        emptyList();
        TaskItem.setCounter(INITIAL_COUNTER_VALUE);
    }
    
    /**
     * Creates an empty list.
     */
    private void emptyList() {
        
        tasks = new ArrayList<TaskItem>();
    }
    
    /**
     * Adds a Task Item to the list.
     * @param title Task title
     * @param type Task type
     * @param creator Task type
     * @param notes Task notes
     * @return taskId task id of added item
     */
    public int addTaskItem(String title, Type type, String creator, String notes) {
        
        TaskItem task = new TaskItem(title, type, creator, notes);
        
        tasks.add(task);
        return task.getTaskItemId();
    }
    
    /**
     * Adds XML Tasks to the list.
     * @param list List of Tasks
     */
    public void addXMLTasks(List<Task> list) {
        
        if (list == null) {
            
            return;
        }
        
        int max = 0;
        
        for (int i = 0; i < list.size(); i++) {
            
            TaskItem item = new TaskItem(list.get(i));
            
            tasks.add(item);
            
            if (item.getTaskItemId() > max) {
                
                max = item.getTaskItemId();
            }
        }
        
        TaskItem.setCounter(max + 1);
        
    }
    
    /**
     * Returns the Task Items present in the list.
     * @return tasks Task Items present in the list
     */
    public List<TaskItem> getTaskItems() {
        
        return tasks;
    }
    
    /**
     * Task item with the owner that is passed as a parameter.
     * @param owner Task owner
     * @return a Task Item present in the list sorted by owner.
     */
    public List<TaskItem> getTaskItemsByOwner(String owner) {
        
        if (owner == null) {
            
            throw new IllegalArgumentException();
        }
        
        ArrayList<TaskItem> a = new ArrayList<TaskItem>();
        
        for (int i = 0; i < tasks.size(); i++) {
            
            if (owner.equals(tasks.get(i).getOwner())) {
                
                a.add(tasks.get(i));
            }
        }
        
        return a;
    }
    
    /**
     * Task item with the creator that is passed as a parameter.
     * @param creator Task creator
     * @return a1 Task Item present in the list sorted by creator.
     */
    public List<TaskItem> getTasksByCreator(String creator) {
        
        if (creator == null) {
            
            throw new IllegalArgumentException();
        }
        
        ArrayList<TaskItem> a1 = new ArrayList<TaskItem>();
        
        for (int i = 0; i < tasks.size(); i++) {
            
            if (creator.equals(tasks.get(i).getCreator())) {
                
                a1.add(tasks.get(i));
            }
        }
        
        return a1;
    }
    
    /**
     * Returns the Task item with the id that is passed as a parameter.
     * @param taskId Task ID
     * @return t Task item with the id that is passed as a parameter
     */
    public TaskItem getTaskItemById(int taskId) {
        
        TaskItem t = null;
        
        for (int i = 0; i < tasks.size(); i++) {
            
            if (taskId == tasks.get(i).getTaskItemId()) {
                
                t = tasks.get(i);
                return t;
            }
        }
        
        return null;
    }
    
    /**
     * Executes the Command specified by user.
     * @param taskId Task id
     * @param c command value
     */
    public void executeCommand(int taskId, Command c) {
        
        for (int i = 0; i < tasks.size(); i++) {
            
            if (taskId == tasks.get(i).getTaskItemId()) {
                
                tasks.get(i).update(c);
                
                break;
                
            }
        }
    }
    
    /**
     * Deletes the Task with the provided id.
     * @param taskId Task id
     */
    public void deleteTaskItemById(int taskId) {
        
        for (int i = 0; i < tasks.size(); i++) {
            
            if (taskId == tasks.get(i).getTaskItemId()) {
                
                tasks.remove(i);
                break;
            }
        }
        
    }
    
    
}
