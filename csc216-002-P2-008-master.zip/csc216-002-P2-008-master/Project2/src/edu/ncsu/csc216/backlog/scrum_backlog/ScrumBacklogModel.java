package edu.ncsu.csc216.backlog.scrum_backlog;

import java.util.List;


import edu.ncsu.csc216.backlog.command.Command;
import edu.ncsu.csc216.backlog.task.TaskItem;
import edu.ncsu.csc216.backlog.task.TaskItem.Type;
import edu.ncsu.csc216.task.xml.TaskIOException;
import edu.ncsu.csc216.task.xml.TaskReader;
import edu.ncsu.csc216.task.xml.TaskWriter;

/**
 * Concrete class that maintains the TaskItemList and handles Commands from the GUI.
 * @author Amiya Renavikar
 */
public class ScrumBacklogModel {

    /** Instance of itself */
    private static ScrumBacklogModel singleton;
    
    /** Instance of TaskItemList */
    private TaskItemList taskIL;
    
    /**
     * Constructs the ScrumBacklogModel class.
     */
    private ScrumBacklogModel() {
        
        taskIL = new TaskItemList();
    }
    
    /**
     * Returns the instance of the ScrumBacklogModel.
     * @return singleton instance of the ScrumBacklogModel
     */
    public static ScrumBacklogModel getInstance() {
        
        if (singleton == null) {
            
            singleton = new ScrumBacklogModel();
        }
        
        return singleton;
    }
    
    /**
     * Saves the Tasks to a file.
     * @param fileName name of the file to save
     */
    public void saveTasksToFile(String fileName) {
        
        try {
           
            TaskWriter writer = new TaskWriter(fileName);
            
            
            for (int i = 0; i < taskIL.getTaskItems().size(); i++) {
                
                writer.addItem(taskIL.getTaskItems().get(i).getXMLTask());
            }
            
            writer.marshal();
        } catch (TaskIOException e) {
            
            throw new IllegalArgumentException("Unable to save task file.");
        }
        
        
        
        
    }
    
    /**
     * Loads the Tasks from a file.
     * @param fileName name of the file to load
     */
    public void loadTasksFromFile(String fileName) {
        
        try {
            
            TaskReader reader = new TaskReader(fileName);
            taskIL.addXMLTasks(reader.getTasks());
        } catch (TaskIOException e) {
            
            throw new IllegalArgumentException("Unable to load task file.");
        }
        
    }
    
    /**
     * Creates a new task item list.
     */
    public void createNewTaskItemList() {
        
        taskIL = new TaskItemList();
    }
    
    /**
     * Returns the TaskItem list as an array.
     * @return o TaskItem list as an array
     */
    public Object[][] getTaskItemListAsArray() {
        
        Object[][] o = new Object[taskIL.getTaskItems().size()][3];
        
        for (int i = 0; i < taskIL.getTaskItems().size(); i++) {
            
            o[i][0] = taskIL.getTaskItems().get(i).getTaskItemId();
            
            o[i][1] = taskIL.getTaskItems().get(i).getStateName();
            
            o[i][2] = taskIL.getTaskItems().get(i).getTitle();
        }
        
        return o;
    }
    
    /**
     * Returns the TaskItem list sorted by owner as an array.
     * @param owner Task owner
     * @return obj TaskItem list sorted by owner as an array
     */
    public Object[][] getTaskItemListByOwnerAsArray(String owner) {
        
        if (owner == null) {
            
            throw new IllegalArgumentException();
        }
        
        List<TaskItem> list = taskIL.getTaskItemsByOwner(owner);
        
        Object[][] obj = new Object[list.size()][3];
        
        for (int i = 0; i < list.size(); i++) {
            
            obj[i][0] = list.get(i).getTaskItemId();
            
            obj[i][1] = list.get(i).getStateName();
            
            obj[i][2] = list.get(i).getTitle();
            
        }
        
        return obj;
    }
    
    /**
     * Returns the TaskItem list sorted by creator as an array.
     * @param creator Task creator
     * @return obj TaskItem list sorted by creator as an array
     */
    public Object[][] getTaskItemListByCreatorAsArray(String creator) {
        
        if (creator == null) {
            
            throw new IllegalArgumentException();
        }
        
        List<TaskItem> list = taskIL.getTasksByCreator(creator);
        
        Object[][] obj = new Object[list.size()][3];
        
        for (int i = 0; i < list.size(); i++) {
            
            obj[i][0] = list.get(i).getTaskItemId();
            
            obj[i][1] = list.get(i).getStateName();
            
            obj[i][2] = list.get(i).getTitle();
            
        }
        
        return obj;
    }
    
    /**
     * Returns the TaskItem list sorted by id.
     * @param taskId Task id
     * @return task TaskItem list sorted by id
     */
    public TaskItem getTaskItemById(int taskId) {
        
        TaskItem task = null;
        
        for (int i = 0; i < taskIL.getTaskItems().size(); i++) {
            
            if (taskId == taskIL.getTaskItems().get(i).getTaskItemId()) {
                
                task = taskIL.getTaskItems().get(i);
            }
        }
        
        return task;
    }
    
    /**
     * Executes the Command specified by user.
     * @param taskId Task id
     * @param c command value
     */
    public void executeCommand(int taskId, Command c) {
        
        taskIL.getTaskItemById(taskId).update(c);
    }
    
    /**
     * Deletes the Task with the provided id.
     * @param taskId Task id
     */
    public void deleteTaskItemById(int taskId) {
        
        for (int i = 0; i < taskIL.getTaskItems().size(); i++) {
            
            if (taskId == taskIL.getTaskItems().get(i).getTaskItemId()) {
                
                taskIL.getTaskItems().remove(i);
            }
        }
    }
    
    /**
     * Adds a Task Item to the list.
     * @param title Task title
     * @param type Task type
     * @param creator Task creator
     * @param notes Task notes
     */
    public void addTaskItemToList(String title, Type type, String creator, String notes) {
        
        taskIL.addTaskItem(title, type, creator, notes);
        
    }
    
}
