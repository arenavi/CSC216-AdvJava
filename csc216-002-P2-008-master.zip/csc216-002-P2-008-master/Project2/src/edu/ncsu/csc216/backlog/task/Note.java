/**
 * 
 */
package edu.ncsu.csc216.backlog.task;

/**
 * Represents a note for a task item that includes the note author and text.
 * @author Amiya Renavikar
 */
public class Note {
    
    /** Note Author */
    private String noteAuthor;
    
    /** Note Text */
    private String noteText;
    
    /**
     * Constructs the Note class.
     * @param noteAuthor note author
     * @param noteText note text
     */
    public Note(String noteAuthor, String noteText) {
        
        if (noteAuthor == null || noteText == null || noteAuthor.equals("") || noteText.equals("")) {
            
            throw new IllegalArgumentException();
        }
        this.noteAuthor = noteAuthor;
        this.noteText = noteText;
        
    }
    
    /**
     * Returns the Note author.
     * @return noteAuthor note author
     */
    public String getNoteAuthor() {
        
        return noteAuthor;
    }
    
    /**
     * Returns the Note text.
     * @return noteText note text
     */
    public String getNoteText() {
        
        return noteText;
    }
    
    /**
     * Returns the Note array.
     * @return s note array
     */
    public String[] getNoteArray() {
        
        String[] s = {this.noteAuthor, this.noteText};
        return s;
    }
}
