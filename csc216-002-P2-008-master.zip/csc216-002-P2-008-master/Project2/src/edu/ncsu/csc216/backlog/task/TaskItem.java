
package edu.ncsu.csc216.backlog.task;

import java.util.ArrayList;
import java.util.List;

import edu.ncsu.csc216.backlog.command.Command;
import edu.ncsu.csc216.backlog.command.Command.CommandValue;
import edu.ncsu.csc216.task.xml.NoteItem;
import edu.ncsu.csc216.task.xml.Task;

/**
 * Concrete class that represents a task item tracked in the Scrum Backlog system. 
 * TaskItem is the Context class of the State design pattern. It maintains the task item's 
 * current state and delegates Commands to the current state to handle.
 * @author Amiya Renavikar
 */
public class TaskItem {

    /** Task ID */
    private int taskId;
    
    /** Task Item State state */
    private TaskItemState state;
    
    /** Task Title */
    private String title;
    
    /** Task creator */
    private String creator;
    
    /** Task owner */
    private String owner;
    
    /** Task isVerifed */
    @SuppressWarnings("unused")
    private boolean isVerified;
    
    /** Backlog state */
    private final TaskItemState backlogState = new BacklogState();
    
    /** Owned state */
    private final TaskItemState ownedState = new OwnedState();
    
    /** Processing state */
    private final TaskItemState processingState = new ProcessingState();
    
    /** Verifying state */
    private final TaskItemState verifyingState = new VerifyingState();
    
    /** Done state */
    private final TaskItemState doneState = new DoneState();
    
    /** Rejected state */
    private final TaskItemState rejectedState = new RejectedState();
    
    /** Backlog constant */
    public static final String BACKLOG_NAME = "Backlog";
    
    /** Owned constant */
    public static final String OWNED_NAME = "Owned";
    
    /** Processing constant */
    public static final String PROCESSING_NAME = "Processing";
    
    /** Verifying constant */
    public static final String VERIFYING_NAME = "Verifying";
    
    /** Done constant */
    public static final String DONE_NAME = "Done";
    
    /** Rejected constant */
    public static final String REJECTED_NAME = "Rejected";
    
    /** T Feature */
    public static final String T_FEATURE = "F";
    
    /** T Bug */
    public static final String T_BUG = "B";
    
    /** T Technical Work */
    public static final String T_TECHNICAL_WORK = "TW";
    
    /** T Knowledge Acquisition */
    public static final String T_KNOWLEDGE_ACQUISITION = "KA";
    
    /** Counter */
    private static int counter = 1;
    
    /** Task note */
    private ArrayList<Note> notes;
    
    /** Type value */
    private Type type;
    
    /**
     * Enum for TaskItem class.
     * @author Amiya Renavikar
     */
    public static enum Type { FEATURE, BUG, TECHNICAL_WORK, KNOWLEDGE_ACQUISITION }
    
    /**
     * Parameterized constructor for TaskItem class.
     * @param title Task title
     * @param type Type of task
     * @param creator Task creator
     * @param note Task notes
     * @throws IllegalArgumentException title, type, creator, or note are null or empty
     */
    public TaskItem(String title, Type type, String creator, String note) {
        
        if (title == null || type == null || creator == null || note == null ||
            title.equals("") || creator.equals("") || note.equals("")) {
            
            throw new IllegalArgumentException("Invalid task information.");
        }
        this.title = title;
        this.creator = creator;
        this.taskId = counter;
        state = backlogState;
        notes = new ArrayList<Note>();        
        incrementCounter();
        this.type = type;
        notes.add(new Note(creator, note));
    }
    
    /**
     * Constructs the Task Item class object.
     * @param task Task to perform
     */
    public TaskItem(Task task) {
        
        this.title = task.getTitle();
        this.creator = task.getCreator();
        this.owner = task.getOwner();
        this.isVerified = task.isVerified();
        this.taskId = task.getId();
        setState(task.getState());
        setType(task.getType());
        
        this.notes = new ArrayList<Note>();
        List<NoteItem> list = task.getNoteList().getNotes();
        
        for(int i = 0; i < list.size(); i++) {
            
            notes.add(new Note(list.get(i).getNoteAuthor(), list.get(i).getNoteText()));
        }
        
        
    }
    
    /**
     * Increments the counter.
     */
    public static void incrementCounter() {
        
        counter++;
    }
    
    /**
     * Returns id of TaskItem.
     * @return taskId Task id
     */
    public int getTaskItemId() {
        
        return taskId;
    }
    
    /**
     * Sets the state of the task.
     * @param state Task state 
     */
    private void setState (String stateValue) {
        
        if (stateValue.equals(BACKLOG_NAME)) {
            
            state = backlogState;
        } else if (stateValue.equals(OWNED_NAME)) {
            
            state = ownedState;
        } else if (stateValue.equals(PROCESSING_NAME)) {
            
            state = processingState;
        } else if (stateValue.equals(VERIFYING_NAME)) {
            
            state = verifyingState;
        } else if (stateValue.equals(DONE_NAME)) {
            
            state = doneState;
        } else if (stateValue.equals(REJECTED_NAME)) {
            
            state = rejectedState;
        } 
        
        
    }
    
    /**
     * Sets the type of the task.
     * @param typeValue Type of task
     */
    private void setType(String typeValue) {
        
        if (typeValue == null) {
            
            throw new IllegalArgumentException();
        }
        
        if (typeValue.equals(T_FEATURE)) {
            
            type = Type.FEATURE;
        } else if (typeValue.equals(T_BUG)) {
            
            type = Type.BUG;
        } else if (typeValue.equals(T_TECHNICAL_WORK)) {
            
            type = Type.TECHNICAL_WORK;
        } else if (typeValue.equals(T_KNOWLEDGE_ACQUISITION)) {
            
            type = Type.KNOWLEDGE_ACQUISITION;
        } 
    }
    
    /**
     * Returns the type of the Task.
     * @return Type of task
     */
    public Type getType() {
        
        return type;
    }
    
    /**
     * Returns the type of Task as a string.
     * @return Type of task as string
     */
    public String getTypeString() {
        
        if (type.toString().equalsIgnoreCase("FEATURE")) {
            
            return T_FEATURE;
        } else if (type.toString().equalsIgnoreCase("BUG")) {
            
            return T_BUG;
        } else if (type.toString().equalsIgnoreCase("TECHNICAL_WORK")) {
            
            return T_TECHNICAL_WORK;
        } else if (type.toString().equalsIgnoreCase("KNOWLEDGE_ACQUISITION")) {
            
            return T_KNOWLEDGE_ACQUISITION;
        } 
        
        return "";
    }
    
    /**
     * Returns the type of Task as a full string.
     * @return Type of task as a full string
     */
    public String getTypeFullString() {
        
        if (type.toString().equalsIgnoreCase("FEATURE")) {
            
            return "Feature";
        } else if (type.toString().equalsIgnoreCase("BUG")) {
            
            return "Bug";
        } else if (type.toString().equalsIgnoreCase("TECHNICAL_WORK")) {
            
            return "Technical Work";
        } else if (type.toString().equalsIgnoreCase("KNOWLEDGE_ACQUISITION")) {
            
            return "Knowledge Acquisition";
        }
        
        return "";
    }
    
    /**
     * Returns the owner of the Task.
     * @return owner Task owner
     */
    public String getOwner() {
        
        return owner;
    }
    
    /**
     * Returns the title of the Task.
     * @return title Task title
     */
    public String getTitle() {
        
        return title;
    }
    
    /**
     * Returns the creator of the Task.
     * @return creator Task creator
     */
    public String getCreator() {
        
        return creator;
    }
    /**
     * Returns the notes of the Task.
     * @return notes ArrayList of notes
     */
    
    public ArrayList<Note> getNotes() {
        
        return notes;
    }
    
    /**
     * Updates the Task Item.
     * @param c Command value
     */
    public void update(Command c) {
        
    
        state.updateState(c);
        
        if (c.getNoteAuthor() != null && c.getNoteText() != null) {
            
            notes.add(new Note(c.getNoteAuthor(), c.getNoteText()));

        }
    }
    
    /**
     * Returns the XML Task.
     * @return task XML Task
     */
    public Task getXMLTask() {
        
        Task task = new Task();
        
        task.setTitle(title);
        task.setCreator(creator);
        task.setOwner(owner);
        task.setState(getStateName());
        
        return task;
    }
    
    /**
     * Sets the counter.
     * @param count counter
     * @throws IllegalArgumentException if counter is less than or equal to 0
     */
    public static void setCounter(int count) {
        
        if (count <= 0) {
            
            throw new IllegalArgumentException();
        }
        
        counter = count;
    }
    
    /**
     * Returns the note array.
     * @return s note array
     */
    public String[][] getNotesArray() {
        
        String[][] s = new String[notes.size()][2];
        
        for (int i = 0; i < notes.size(); i++) {
            
           s[i][0] = notes.get(i).getNoteAuthor();
           
           s[i][1] = notes.get(i).getNoteText();
        }
        
        return s;
    }
    
    /**
     * Returns the State name.
     * @return state name or null if state name not found
     */
    public String getStateName() {
        
        if (state == backlogState) {
            
            return BACKLOG_NAME;
        } else if (state == ownedState) {
            
            return OWNED_NAME;
        } else if (state == processingState) {
            
            return PROCESSING_NAME;
        } else if (state == verifyingState) {
            
            return VERIFYING_NAME;
        } else if (state == doneState) {
            
            return DONE_NAME;
        } else if (state == rejectedState) {
            
            return REJECTED_NAME;
        }
        
        return null;
        
    }
    
    /**
     * Interface for states in the Task State Pattern.  All 
     * concrete task states must implement the TaskState interface.
     * 
     * @author Dr. Sarah Heckman (sarah_heckman@ncsu.edu) 
     */
    private interface TaskItemState {
        
        /**
         * Update the {@link TaskItem} based on the given {@link Command}.
         * An {@link UnsupportedOperationException} is throw if the {@link CommandValue}
         * is not a valid action for the given state.  
         * @param c {@link Command} describing the action that will update the {@link TaskItem}'s
         * state.
         * @throws UnsupportedOperationException if the {@link CommandValue} is not a valid action
         * for the given state.
         */
        void updateState(Command c);
        
        /**
         * Returns the name of the current state as a String.
         * @return the name of the current state as a String.
         */
        String getStateName();
    
    }
    
    /**
     * Concrete class that represents the backlog state 
     * of the Scrum Backlog FSM.
     * @author Amiya Renavikar
     */
    public class BacklogState implements TaskItemState {
        
        /**
         * Updates the state to Backlog.
         * @param c command value
         */
        @Override
        public void updateState(Command c) {
            
            if (c.getCommand() == CommandValue.CLAIM) {
                
                owner = c.getNoteAuthor();
                setState(OWNED_NAME);
                
            } else if (c.getCommand() == CommandValue.REJECT) {
                
                setState(REJECTED_NAME);
                
            } else {
                
                throw new UnsupportedOperationException();
            }
            
        }

        /**
         * Returns the state name as Backlog.
         * @return BACKLOG_NAME name as backlog
         */
        @Override
        public String getStateName() {
            
            return BACKLOG_NAME;
        }
        
        
    }
    
    /**
     * Concrete class that represents the owned state 
     * of the Scrum Backlog FSM.
     * @author Amiya Renavikar
     */
    public class OwnedState implements TaskItemState {

        /**
         * Updates the state to Owned.
         * @param c command value
         */
        @Override
        public void updateState(Command c) {
            
            if (c.getCommand() == CommandValue.PROCESS) {
                
                setState(PROCESSING_NAME);
                
            } else if (c.getCommand() == CommandValue.REJECT) {
                
                owner = null;
                setState(REJECTED_NAME);
                
            } else if (c.getCommand() == CommandValue.BACKLOG) {
                
                owner = null;
                setState(BACKLOG_NAME);
                
            } else {
                
                throw new UnsupportedOperationException();
                
            }
        }

        /**
         * Return the state name as owned.
         * @return state name
         */
        @Override
        public String getStateName() {
            
            return OWNED_NAME;
        }
        
        
    }
    
    /**
     * Concrete class that represents the processing state 
     * of the Scrum Backlog FSM.
     * @author Amiya Renavikar
     */
    public class ProcessingState implements TaskItemState {

        /**
         * Updates the state to Processing.
         * @param c command value
         */
        @Override
        public void updateState(Command c) {
            
            if (c.getCommand() == CommandValue.PROCESS) {
                
                notes.add(new Note(c.getNoteAuthor(), c.getNoteText()));
                setState(PROCESSING_NAME);
                
            } else if (c.getCommand() == CommandValue.VERIFY) {
                
                if (type == Type.FEATURE || type == Type.BUG || type == Type.TECHNICAL_WORK) {
                    
                    setState(VERIFYING_NAME);
                } else {
                    
                    throw new UnsupportedOperationException();
                }
                
                
                
            } else if (c.getCommand() == CommandValue.COMPLETE) {
                
                if (type == Type.KNOWLEDGE_ACQUISITION) {
                    
                    setState(DONE_NAME);
                    
                } else {
                    
                    throw new UnsupportedOperationException();
                }
                
               
                
            } else if (c.getCommand() == CommandValue.BACKLOG) {
                
                owner = null;
                setState(BACKLOG_NAME);
                
            } else {
                
                throw new UnsupportedOperationException();
            }
            
        }

        /**
         * Returns the State name as Processing.
         * @return state name
         */
        @Override
        public String getStateName() {
            
            return PROCESSING_NAME;
        }
        
        
    }
    
    /**
     * Concrete class that represents the verifying state 
     * of the Scrum Backlog FSM.
     * @author Amiya Renavikar
     */
    public class VerifyingState implements TaskItemState {

        /**
         * Updates the state to Verifying.
         * @param c command value
         */
        @Override
        public void updateState(Command c) {
            
            if (c.getCommand() == CommandValue.COMPLETE) {
                
                if (type == Type.FEATURE || type == Type.BUG || type == Type.TECHNICAL_WORK) {
                    
                    isVerified = true;
                    setState(DONE_NAME);
                    
                } 
                
            } else if (c.getCommand() == CommandValue.PROCESS) {
                
                if (type == Type.FEATURE || type == Type.BUG || type == Type.TECHNICAL_WORK) {
                    
                    setState(PROCESSING_NAME);
                    
                } 
                
            } else {
                
                throw new UnsupportedOperationException();
            }
            
        }

        /**
         * Returns the state name.
         * @return state name
         */
        @Override
        public String getStateName() {
            
            return VERIFYING_NAME;
        }
        
        
    }
    
    /**
     * Concrete class that represents the done state 
     * of the Scrum Backlog FSM.
     * @author Amiya Renavikar
     */
    public class DoneState implements TaskItemState {

        /**
         * Updates the state to Done.
         * @param c command value
         */
        @Override
        public void updateState(Command c) {
            
            if(c.getCommand() == CommandValue.PROCESS) {
                
                setState(PROCESSING_NAME);
                
            } else if (c.getCommand() == CommandValue.BACKLOG) {
                
                owner = null;
                setState(BACKLOG_NAME);
                
            } else {
                
                throw new UnsupportedOperationException();
            }
            
        }

        /**
         * Returns the state name.
         * @return state name
         */
        @Override
        public String getStateName() {
            
            return DONE_NAME;
        }
        
        
    }
    
    /**
     * Concrete class that represents the rejected state 
     * of the Scrum Backlog FSM.
     * @author Amiya Renavikar
     */
    public class RejectedState implements TaskItemState {

        /**
         * Updates the state to Rejected.
         * @param c command value
         */
        @Override
        public void updateState(Command c) {
            
            if (c.getCommand() == CommandValue.BACKLOG) {
                
                owner = null;
                setState(BACKLOG_NAME);
            } else {
                
                throw new UnsupportedOperationException();
            }
        }

        /**
         * Returns the state name.
         * @return state name
         */
        @Override
        public String getStateName() {
            
            return REJECTED_NAME;
        }
        
        
    }
    
    

    
}
