/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractList;
import java.util.Arrays;

/**
 * Handles the functionality of an ArrayList.
 * @author Amiya, Liam, Anderson
 * @param <E> Element to construct array
 */
public class ArrayList<E> extends AbstractList<E> {

    /** A constant value for initializing the size list */
    private static final int INIT_SIZE = 10;
    
    /** An array of type E */
    private E[] list;
    
    /** The size of the list */
    private int size;
    
    /**
     * Constructs the ArrayList class, creates a new generic object, and sets 
     * the list to the init size constant.
     */
    @SuppressWarnings("unchecked")
    public ArrayList() {
    	
        list = (E[]) (new Object[INIT_SIZE]);
        
    }
    
    /**
     * Adds item to the list.
     * @param index index of each item
     * @param item E object
     * @throws IndexOutOfBoundsException if index < 0 or index >= size
     * @throws NullPointerException if item = null
     * @throws IllegalArgumentException if there are duplicates
     */
   @Override
    public void add(int index, E item) {
	    
	    if(index == size()){
	    	growArray(size());
	    }
        if (index < 0 || index > size()) {           
            throw new IndexOutOfBoundsException();
        }        
        if (item == null) {            
            throw new NullPointerException();
        }
        
        if (size() > 0) {
        for(int i = 0; i <= size() - 1; i++){
    		if(list[i].equals(item)){
    			throw new IllegalArgumentException();
    		}
    	}
        }
        growArray(size + 1);       
        for (int i = size - 1; i >= index; i--) {           
            list[i + 1] = list[i];
        }
        list[index] = (E) item;
        size++;      
    }
    
   /**
    * Removes the item from Array list.
    * @param index index of item
    * @throws IndexOutOfBoundsException if index >= size or index less than 0
    * @return ret removed item
    */
    @Override
    public E remove(int index) {
		if(index >= size || index < 0){
			throw new IndexOutOfBoundsException();
		}
		E ret = list[index];
		for(int i = index; i < size(); i++){
			list[i] = list[i + 1];
		}
		size--;
		return ret;
	}
    
    /**
     * Sets the item in the ArrayList.
     * @param index index of each item
     * @param item E object
     * @throws NullPointerException if item is null
     * @throws IndexOutOfBoundsException if index >= size or index less than 0
     * @throws IllegalArgumentException if there are duplicates
     * @return item item that is set
     */
    @Override
    public E set(int index, E item){
    	E ret = list[index];
    	if(item == null){
    		throw new NullPointerException();
    	}
    	if (index < 0 || index >= size()) {  
            throw new IndexOutOfBoundsException();
        }
    	for(int i = 0; i <= size() - 1; i++){
    		if(list[i].equals(item)){
    			throw new IllegalArgumentException();
    		}
    	}
    	list[index] = item;
    	return ret;
    }
    
    /**
     * Private helper method that enables the ArrayList to grow.
     * @param capacity capacity of growth
     */
    private void growArray(int capacity) {
        
        if (capacity > list.length) {
            int newCap = list.length * 2 + 1;
            if(capacity > newCap) {                
                newCap = capacity;
            }            
            list = Arrays.copyOf(list, newCap);
        }
    }
    
    /**
     * Returns the item at the provided index.
     * @param index index of item
     * @throws IndexOutOfBoundsException if index is less than 0 or if index >= size
     * @return item at given index
     */
    @Override
    public E get(int index) {
        
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException();
        }       
        return list[index];
    }

    /**
     * Returns the size of the ArrayList.
     * @return size size of ArrayList
     */
    @Override
    public int size() {       
        return size;
    }

}
