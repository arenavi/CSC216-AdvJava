package edu.ncsu.csc216.pack_scheduler.user;
/**
 * Constructs a User Object.
 * @author Anderson, Liam, Amiya
 *
 */
public abstract class User {

	/**
	 * The String firstName of the Student
	 */
	private String firstName;
	/**
	 * The String lastName of the Student
	 */
	private String lastName;
	/**
	 * The String id of the Student
	 */
	private String id;
	/**
	 * The String email of the Student
	 */
	private String email;
	/**
	 * The String password of the Student
	 */
	private String password;
	
	/**
	 * Constructs the User class.
	 * @param firstName First name of user
	 * @param lastName Last Name of User
	 * @param id User's ID
	 * @param email Users Email Address
	 * @param password Users Password
	 */
	public User(String firstName, String lastName, String id, String email, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		this.email = email;
		this.password = password;
	}


	/**
	 *  returns the student's first name
	 *  @return the student's first name
	 */
	public String getFirstName() {
		
		return this.firstName;
	}

	/**
	 * Sets the student's first name
	 * @param firstName the student's first name
	 */
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() == 0){
			throw new IllegalArgumentException("Invalid first name");
		}
		this.firstName = firstName;
	}

	/**
	 * Returns the student's last name
	 * @return the student's last name
	 */
	public String getLastName() {
		
		return this.lastName;
	}

	/**
	 * Sets the student's last name
	 * @param lastName the student's last name
	 */
	public void setLastName(String lastName) {
		if(lastName == null || lastName.length() == 0){
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}

	/**
	 * gets the student's id
	 * @return the student's id
	 */
	public String getId() {
		
		return this.id;
	}

	/**
	 * sets the student's id
	 * @param id the student's id
	 */
	protected void setId(String id) {
		if(id == null || id.length() == 0){
			throw new IllegalArgumentException("Invalid id");
		}
		this.id = id;
	}

	/**
	 * gets the student's email
	 * @return the student's email
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * sets the student's email
	 * @param email the student's email
	 */
	public void setEmail(String email) {
		if(email == null || email.length() == 0){
			throw new IllegalArgumentException("Invalid email");
		}
		if(!email.contains("@") || !email.contains(".")){
			throw new IllegalArgumentException("Invalid email");
		}
		if(!email.substring(email.indexOf('@'), email.length()).contains(".")){
			throw new IllegalArgumentException("Invalid email");
		}
		this.email = email;
	}

	/**
	 * gets the students password
	 * @return the student's password
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 * sets the student's password
	 * @param password the student's password
	 */
	public void setPassword(String password) {
		if(password == null || password.length() == 0){
			throw new IllegalArgumentException("Invalid password");
		}
		this.password = password;
		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

}