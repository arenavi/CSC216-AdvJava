/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

/**
 * Handles the functioning of Course Name Validator.
 * @author Anderson, Amiya
 */
public class CourseNameValidator {
        
    private boolean validEndState;
    
    private int letterCount;
    
    private int numberCount;
    
    private State currentState;

    /**
     * Returns true if the Course Name is valid.
     * @param courseName course name
     * @return false for method to compile
     * @throws InvalidTransitionException if there is invalid input
     */
	public boolean isValid(String courseName) throws InvalidTransitionException {
	    char ch;
	    currentState = new InitialState();
	    try{
	    	int i = 0;
	    	letterCount = 0;
	    	numberCount = 0;
	    	validEndState = false;
	    	while(i < courseName.length()){
	    		ch = courseName.charAt(i);
	    		if(Character.isLetter(ch) && letterCount < LetterState.MAX_PREFIX_LETTERS && !(currentState instanceof NumberState || currentState instanceof SuffixState)){
	    			currentState.onLetter();
	    			currentState = new LetterState();
	    		}
	    		else if(Character.isDigit(ch)){
	    			currentState.onDigit();
	    			currentState = new NumberState();
	    		}
	    		else if(Character.isLetter(ch) && numberCount == 3){
	    			currentState.onLetter();
	    			currentState = new SuffixState();
	    		}
	    		else{
	    			currentState.onOther();
	    		}
	    		i++;
	    	}
	    } catch(InvalidTransitionException e){
	    	throw e;
	    }
	    if(numberCount == NumberState.COURSE_NUMBER_LENGTH && letterCount <= LetterState.MAX_PREFIX_LETTERS){
	    	validEndState = true;
	    }
		return validEndState;
	}
	
	/**
	 * Handles functionality of the State Class.
	 * @author Amiya, Liam, Anderson
	 *
	 */
	public abstract class State {
		
		/** Abstract method for handling a letter input. 
		 * @throws InvalidTransitionException if there is no input
		 */
		public abstract void onLetter() throws InvalidTransitionException; 
       
		
		
		/** Abstract method for handling a digit input 
		 * @throws InvalidTransitionException if there is invalid input
		 */
		public abstract void onDigit() throws InvalidTransitionException;

		/** 
		 * Concrete method for handling any other input 
		 * @return false if there is any other input than letters or digits
		 * @throws InvalidTransitionException if there is invalid input
		 */
		public boolean onOther() throws InvalidTransitionException{
		    
		    throw new InvalidTransitionException("Course name can only contain letters and digits.");
			
		    
		}
	}
	
	/**
	 * Handles Initial State.
	 * @author Amiya, Liam, Anderson
	 */
	private class InitialState extends State {

	    /**
	     * Constructs the InitialState class.
	     */
		private InitialState(){
			
		}
		
		/**
		 * Handles letter input.
		 * @throws InvalidTransitionException if there is invalid input
		 */
		public void onLetter() throws InvalidTransitionException {
			letterCount++;
			
		}

		/**
         * Handles digit input.
         * @throws InvalidTransitionException if there is invalid input
         */
		public void onDigit() throws InvalidTransitionException {
			numberCount++;
			
		}
		
	}
	
	/**
     * Handles Letter State.
     * @author Amiya, Liam, Anderson
     */
	private class LetterState extends State {
	    
	    /** Max prefix letter */
		private static final int MAX_PREFIX_LETTERS = 4;

		/**
         * Handles letter input.
         * @throws InvalidTransitionException
         */
		public void onLetter() throws InvalidTransitionException {
			if(letterCount > 4){
				throw new InvalidTransitionException();
			}
			else{
				letterCount++;
			}
		}

		/**
         * Handles digit input.
         * @throws InvalidTransitionException
         */
		public void onDigit() throws InvalidTransitionException {
			numberCount++;
			
		}
		
	}
	
	/**
     * Handles Number State.
     * @author Amiya, Liam, Anderson
     */
	private class NumberState extends State {
	    
	    /** Course number length */
		private static final int COURSE_NUMBER_LENGTH = 3;	
		
		/**
         * Handles letter input.
         * @throws InvalidTransitionException
         */
		public void onLetter() throws InvalidTransitionException {
			if(letterCount != 3){
				throw new InvalidTransitionException();
			}
			
		}
		
		/**
         * Handles digit input.
         * @throws InvalidTransitionException
         */
		public void onDigit() throws InvalidTransitionException {
			if(numberCount >= 3){
				throw new InvalidTransitionException();
			}
			else{
				numberCount++;
			}
		}
	}
	
	/**
     * Handles Suffix State.
     * @author Amiya, Liam, Anderson
     */
	private class SuffixState extends State {
		
	    /**
         * Handles letter input.
         * @throws InvalidTransitionException
         */
		public void onLetter() throws InvalidTransitionException {
			if(letterCount > 5){
				throw new InvalidTransitionException();
			}
			else{
				letterCount++;
			}
			
		}

		/**
         * Handles digit input.
         * @throws InvalidTransitionException
         */
		public void onDigit() throws InvalidTransitionException {
			throw new InvalidTransitionException();
			
		}
	}
}
