package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.course.Course;

/**
 * Reads Course records from text files.  Writes a set of CourseRecords to a file.
 * 
 * @author Anderson
 */
public class CourseRecordIO {
    /**
     * Reads course records from a file and generates a list of valid Courses.  Any invalid
     * Courses are ignored.  If the file to read cannot be found or the permissions are incorrect
     * a File NotFoundException is thrown.
     * @param fileName file to read Course records from
     * @return a list of valid Courses
     * @throws FileNotFoundException if the file cannot be found or read
     */
		
	public static SortedList<Course> readCourseRecords(String fileName) throws FileNotFoundException {
	    Scanner fileReader = new Scanner(new File(fileName));
	    SortedList<Course> courses = new SortedList<Course>();
	    while (fileReader.hasNextLine()) {
	        try {
	            Course course = readCourse(fileReader.nextLine());
	            boolean duplicate = false;
	            for (int i = 0; i < courses.size(); i++) {
	                Course c = courses.get(i);
	                if (course.getName().equals(c.getName()) && course.getSection().equals(c.getSection())) {
	                    duplicate = true;
	                }
	            }
	            if (!duplicate) {
	                courses.add(course);
	            }
	        }
	         catch (IllegalArgumentException e) {
	        	 //skip the line
	        }
	    }
	    fileReader.close();
	    return courses;
	}

	/**
	 * Reads a line from a file and inputs string tokens separated by commas into
	 * the Course object
	 * @param nextline is the string provided by the readCourseRecords method
	 * @return filled Course object
	 */
    private static Course readCourse(String nextline) {
    	Course course = null;
    	Scanner input = new Scanner(nextline);
    	Scanner inputSmall = new Scanner(nextline);
    	input.useDelimiter(",");
    	inputSmall.useDelimiter(",");
    	while(input.hasNext()){
    		try{
    			course = new Course(input.next(), input.next(), input.next(), input.nextInt(), input.next(), input.nextInt(), input.next(), input.nextInt(), input.nextInt()); 
    		}
    		catch(InputMismatchException ex){
    			input.close();
    	    	inputSmall.close();
    			throw new IllegalArgumentException();
    		}
    		catch(NoSuchElementException e){
    			course = new Course(inputSmall.next(), inputSmall.next(), inputSmall.next(), inputSmall.nextInt(), inputSmall.next(), inputSmall.nextInt(), inputSmall.next(), 0, 0);
    		}
    	}
    	input.close();
    	inputSmall.close();
    	return course ;
    	
	}
	/**
     * Writes the given list of Courses to a file
     * @param fileName name of file where Courses will be saved
     * @param courses SortedList of Course objects
     * @throws IOException if the output operation is failed
     */

    public static void writeCourseRecords(String fileName, SortedList<Course> courses) throws IOException {

    	PrintStream fileWriter = new PrintStream(new File(fileName));

    	
		for (int i = 0; i < courses.size(); i++) {
    	    fileWriter.println(courses.get(i).toString());
    	}

    	fileWriter.close();
        
    }

}