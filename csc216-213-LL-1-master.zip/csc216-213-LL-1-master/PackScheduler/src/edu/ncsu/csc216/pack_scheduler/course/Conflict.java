/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Ensures that Activity dates and times do not overlap causing scheduling conflicts
 * @author Anderson
 *
 */
public interface Conflict {
	/**
	 * Checks that dates and times do not overlap and if they do throws an exception.
	 * @param possibleConflictingActivity Activity to check for conflicts
	 * @throws ConflictException if times overlap on equal days
	 */
	void checkConflict(Activity possibleConflictingActivity) throws ConflictException;
}
