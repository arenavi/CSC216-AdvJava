/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Creates the ConflictException which has direct correlation to the WolfScheduler
 * by allowing an exception when times overlap on days that overlap.
 * @author Anderson
 *
 */
public class ConflictException extends Exception {

	/** ID used for serialization */
	private static final long serialVersionUID = 1L;

	/**
	 * Parameterized Constructor with string for the Exception object
	 * @param message default message 
	 */
	public ConflictException(String message) {
		super(message);
	}
	
	/**
	 * Parameterless Constructor that calls the parameterized constructor with an author specified default message
	 */
	public ConflictException() {
		super("Schedule conflict.");
	}
}
