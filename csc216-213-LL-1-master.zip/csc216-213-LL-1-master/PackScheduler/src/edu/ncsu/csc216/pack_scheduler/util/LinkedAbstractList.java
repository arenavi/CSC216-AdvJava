/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractList;

/**
 * Extension of the AbstractList class in order to construct a LinkedAbstractList
 * for use in the Course Roll class.
 * @author Amiya, Liam, Anderson
 */
public class LinkedAbstractList<E> extends AbstractList<E> {
    
	/** Front Node */
    private ListNode front;
    
    /** Size of the list */
    private int size;
    
    /** Capacity of the list */
    private int capacity;
    
    /**
     * Constructor for the linkedAbstractList
     * @param cap capacity of the list
     * @throws IllegalArgumentException if cap is less than 0
     */
    public LinkedAbstractList(int cap) {
        
        front = null;
        size = 0; 
        
        if(cap > 0) {
            
            this.capacity = cap;
        } else if (cap < 0) {
            
            throw new IllegalArgumentException();
        }
      
    }
    
    /* 
     * (non-Javadoc)
     * @see java.util.AbstractList#get(int)
     */
    @Override
    public E get(int index) {
        
    	ListNode current = front;
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException();
        }
        
        //If index 0
        if (index == 0) {
        	// adding to front of list
        	//front = new ListNode(value, front);
        	return front.data;
        }  
        
        else {
        	for (int i = 0; i < index - 1; i++) {
        	current = current.next;
        	}
        }
        	return current.data;
        
        
    }
    
   
    /* 
     * (non-Javadoc)
     * @see java.util.AbstractList#add(int, E)
     */
    @Override
	public void add(int index, E data) {
    	if (size == capacity) {
    		throw new IllegalArgumentException();
    	}
    	
    	if (data == null) {
    		throw new NullPointerException();
    	}
    	
    	if (data.equals(this)) {
    		throw new IllegalArgumentException();
    	}
    	
    	if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException();
        }
    	
    	if (index == 0) {
    		// adding to front of list
    		front = new ListNode(data, front);
    	} else {
    		// inserting into an existing list
    		ListNode current = front;
    		// stop BEFORE index to add at
    		for (int i = 0; i < index - 1; i++) {
    		    current = current.next;
    		}
    		current.next = new ListNode(data, current.next);
    	}
    	size++;
	}
    
    

	/* (non-Javadoc)
	 * @see java.util.AbstractList#remove(int)
	 */
	@Override
	public E remove(int index) {
	    E ret = null;
	    if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException();
        }
	    
		if (index == 0) {
			// special case: removing first element
		    ret = front.data;
			front = front.next;
		} else {
			// removing from elsewhere in the list
			ListNode current = front;
			for (int i = 0; i < index - 1; i++) {
				current = current.next;
			}
			ret = current.next.data;
			current.next = current.next.next;
		}
		size--;
		return ret;
	}

	/* (non-Javadoc)
     * @see java.util.AbstractList#set(int, java.lang.Object)
     */
    @Override
    public E set(int index, E data) {
        
        if (data == null) {
            throw new NullPointerException();
        }
        
        if (data.equals(this)) {
            throw new IllegalArgumentException();
        }
        
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        
        //this.get(index) = data;
        if (index == 0) {
    		// adding to front of list
    		front.data = data;
    	} else {
    		// inserting into an existing list
    		ListNode current = front;
    		// stop BEFORE index to add at
    		for (int i = 0; i < index - 1; i++) {
    		    current = current.next;
    		}
    		current.next.data = data;
    	}
        
        
        return this.get(index);
    }

    /* (non-Javadoc)
     * @see java.util.AbstractCollection#size()
     */
    @Override
    public int size() {
        
        return size;
    }
    
    /**
     * Private list node class.
     * @author Amiya, Liam, Anderson
     */
    private class ListNode {
        /** element data for specific node */
        private E data;
        /** provides access to the next node */
        private ListNode next;
        /**
         * Constructor for the Listnode
         * @param data Element provided for location
         */
        @SuppressWarnings("unused")
        public ListNode(E data) {
        	 this(data, null);
            
        }
        /**
         * Constructor for next listnode
         * @param data Element provided for location
         * @param next access to the next node
         */
        public ListNode(E data, ListNode next) {
        	this.data = data;
        	this.next = next;
            
        }
        
    }

}
