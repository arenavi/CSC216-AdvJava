package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.user.Student;
/**
 * Reads and Writes student records to a designated file. 
 * @author Udeh William Sam
 *
 */
public class StudentRecordIO {
	/**
	 * Reads in student records and turns them in a sorted list
	 * @param fileName name of file with student records
	 * @return students Array of student objects
	 * @throws FileNotFoundException If file is not in the specified location
	 */
	public static SortedList<Student> readStudentRecords(String fileName) throws FileNotFoundException {
		SortedList<Student> list = new SortedList<Student>();
		Scanner file = new Scanner(new FileInputStream(fileName));
		while (file.hasNextLine()) {
	        try {
	            Student temp = processStudent(file.nextLine());
	            for (int i = 0; i < list.size(); i++) {
	                if (temp.equals(list.get(i))) {
	                    throw new IllegalArgumentException();
	                }
	            }
	            list.add(temp);
	        } catch (IllegalArgumentException e) {
	            //skip the line
	        }
	    }
		file.close(); 
		return list;
	}
	/**
	 * Processes text files to produce a Student object
	 * @param nextLine String provided through readStudentRecords method for processing
	 * @return Student object for addition to Sorted List students
	 */
	private static Student processStudent(String nextLine) {
		Student student = null;
    	Scanner input = new Scanner(nextLine);
    	Scanner inputSmall = new Scanner(nextLine);
    	input.useDelimiter(",");
    	inputSmall.useDelimiter(",");
    	while(input.hasNext()){
    		try{
    			student = new Student(input.next(), input.next(), input.next(), input.next(), input.next(), input.nextInt()); 
    		}
    		catch(InputMismatchException ex){
    			input.close();
    	    	inputSmall.close();
    			throw new IllegalArgumentException();
    		}
    		catch(NoSuchElementException e){
    			input.close();
    	    	inputSmall.close();
    			throw new IllegalArgumentException("The student has no credits");
    		}
    	}
    	input.close();
    	inputSmall.close();
    	return student ;
	}
	/**
	 * Prints out Student records in a file
	 * @param fileName name of file where student records are written
	 * @param studentDirectory Directory of students
	 * @throws IOException if file is unable to be output
	 */
	public static void writeStudentRecords(String fileName, SortedList<Student> studentDirectory) throws IOException {
		PrintStream fileWriter = new PrintStream(new File(fileName));
		for (int i = 0; i < studentDirectory.size(); i++) {
			fileWriter.println(studentDirectory.get(i).toString());
		}
		fileWriter.close();
	}

}
