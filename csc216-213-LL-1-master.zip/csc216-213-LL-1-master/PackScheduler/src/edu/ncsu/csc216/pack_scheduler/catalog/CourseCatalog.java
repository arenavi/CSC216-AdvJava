package edu.ncsu.csc216.pack_scheduler.catalog;

import java.io.FileNotFoundException;
import java.io.IOException;
import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.io.CourseRecordIO;

/** Creates a catalog of courses from a input file
 * @author Anderson Rowe
 * @author Udeh Onwuka
 * @author Samuel Pruett
 */
public class CourseCatalog {
	/** The catalog of sorted courses */
	private SortedList<Course> catalog; 
	
	/**
	 * Creates a empty catalog
	 */
	public CourseCatalog() {
		newCourseCatalog();

	}
	/**
	 * Creates a new empty catalog
	 */
	public void newCourseCatalog() {
		catalog = new SortedList<Course>();
	}
	/**
	 * Adds the courses from the input file to the course catalog
	 * @param fileName the input file's name
	 */
	public void loadCoursesFromFile(String fileName) {
		try {
			catalog = CourseRecordIO.readCourseRecords(fileName);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to read file " + fileName);
		}
	}
	/**
	 * Adds a course to a catalog
	 * @param name the name of the course to be added
	 * @param title the title of the course to be added
	 * @param section the section of the course to be added
	 * @param credits the credit hours of the course to be added
	 * @param instructorId the id of the course
	 * @param enrollmentCap the enrollment cap
	 * @param meetingDays the days the course meets
	 * @param startTime the time the course starts
	 * @param endTime the time the course ends
	 * @return whether the course can be added to the catalog
	 */
	public boolean addCourseToCatalog(String name, String title, String section,  int credits, String instructorId, int enrollmentCap,
			String meetingDays, int startTime, int endTime){
		Course c = new Course(name, title, section, credits, instructorId, enrollmentCap, meetingDays, startTime, endTime);
		for(int j = 0; j < catalog.size(); j++) {
			Course course = catalog.get(j);
			if (course.getName().equals(name) && course.getSection().equals(section)) {
				return false;
			}
		}
		if(catalog.contains(c)){
			return false;
		}
		else{
			catalog.add(c);
			return true;
		}
	}
	/**
	 * Removes a course from the catalog 
	 * @param name the name of the course to be removed
	 * @param section the section of the course to be removed
	 * @return true or false
	 */
	public boolean removeCourseFromCatalog(String name, String section){
		Course c = getCourseFromCatalog(name, section);
		for(int i = 0; i < catalog.size(); i++){
			if(catalog.get(i).equals(c)) { 
				catalog.remove(i);
				return true;
			}
		}
		return false;
		
	}
	/**
	 * Returns a specified course that is in the catalog or null if the course is absent
	 * @param name the name of the course to be returned
	 * @param section the section of the course to be returned
	 * @return the course specified or null
	 */
	public Course getCourseFromCatalog(String name, String section){
		for(int i = 0; i < catalog.size(); i++){
			Course c = catalog.get(i);
			if(name.equals(c.getName()) && section.equals(c.getSection())){
				return c;
			}
		}
		return null;
	}
	/**
	 * Returns the course catalog
	 * @return 2d array of the catalog
	 */
	public String[][] getCourseCatalog(){
		if (catalog.size() == 0) {
			String[][] empty = new String[0][0];
			return empty;
		}
		String[][] catalogArray = new String[catalog.size()][4];
		for (int i = 0; i < catalog.size(); i++) {
			Course c = catalog.get(i);
			String name = c.getName();
			String section = c.getSection();
			String cTitle = c.getTitle();
			String meetingInfo = c.getMeetingString();
			
			catalogArray[i][0] = name;
			catalogArray[i][1] = section;
			catalogArray[i][2] = cTitle;
			catalogArray[i][3] = meetingInfo;
		}
		return catalogArray;
	}
	/**
	 * Saves the course catalog to a file 
	 * @param fileName the name of the file to be saved to
	 */
	public void saveCourseCatalog(String fileName) {
		try {
			CourseRecordIO.writeCourseRecords(fileName, catalog);
		} catch (IOException e) {
			throw new IllegalArgumentException("The file cannot be saved");
		}
	}
}

