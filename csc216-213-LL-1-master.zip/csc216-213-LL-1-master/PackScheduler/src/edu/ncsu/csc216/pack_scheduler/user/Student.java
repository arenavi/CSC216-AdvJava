package edu.ncsu.csc216.pack_scheduler.user;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.schedule.Schedule;

/**
 * Creates the Student object.
 * @author Udeh William Sam
 * 
 */
public class Student extends User implements Comparable<Student> {
	/**
	 * The integer number of maxCredits
	 */
	private int maxCredits;
	/**
	 * The maximum number of credits a student can take
	 */
	private String sendPassword;
	/**
	 * Maximum number of credits allowed
	 */
	public static final int MAX_CREDITS = 18;
	
	/** Schedule */
	private Schedule schedule = new Schedule();
	
	
	/**
	 * Student Constructor
	 * @param firstName The student's first name
	 * @param lastName The student's last name
	 * @param id the student's id
	 * @param email The student's email address
	 * @param password the student's password
	 * @param maxCredits The student's max amount of credits
	 */
	public Student(String firstName, String lastName, String id, String email, String password, int maxCredits){
		super(firstName, lastName, id, email, password);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setId(id);
		this.setEmail(email);
		this.setPassword(password);
		this.setMaxCredits(maxCredits);
		sendPassword = password;
		
	}
	/**
	 * Student Constructor
	 * @param firstName the students first name
	 * @param lastName the student's last name
	 * @param id the student's id
	 * @param email the student's email address
	 * @param password the student's password
	 */
	public Student(String firstName, String lastName, String id, String email, String password){
		
		this(firstName, lastName, id, email, password, MAX_CREDITS);
		
	}
	/**
	 * returns the student's max credits
	 * @return the students max credits
	 */
	public int getMaxCredits(){
		return this.maxCredits;
	}
	/**
	 * Sets the max credits
	 * @param maxCredits the student's maxCredits
	 */
	public void setMaxCredits(int maxCredits){
		if( maxCredits < 3 || maxCredits > 18){
			throw new IllegalArgumentException("Invalid max credits");
		}
		this.maxCredits = maxCredits;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		
		return super.getFirstName() + "," + super.getLastName() + "," + super.getId() + "," + super.getEmail() + "," + super.getPassword() + "," + maxCredits;
	}
	
	@Override
	public int compareTo(Student s) {
		if (this.getLastName().compareTo(s.getLastName()) != 0) {
			return this.getLastName().compareTo(s.getLastName());
		} else if (this.getFirstName().compareTo(s.getFirstName()) != 0){
			return this.getFirstName().compareTo(s.getFirstName());
		} else if (this.getId().compareTo(s.getId()) != 0){
			return this.getId().compareTo(s.getId());
		} else {
			return 0;
		}
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + maxCredits;
		result = prime * result + ((sendPassword == null) ? 0 : sendPassword.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (maxCredits != other.maxCredits)
			return false;
		if (sendPassword == null) {
			if (other.sendPassword != null)
				return false;
		} else if (!sendPassword.equals(other.sendPassword))
			return false;
		return true;
	}
	/**
	 * Getter for the current Students Schedule
	 * @return schedule array of scheduled courses
	 */
	public Schedule getSchedule() {
		return schedule;
	}
	/**
	 * Boolean method which determines whether or not a course can be added, including Credits
	 * @param c Course 
	 * @return boolean true for able to add and false for unable to add
	 */
	public boolean canAdd(Course c) {
		if(!schedule.canAdd(c)) {
			return false;
		}
		else if(schedule.getScheduleCredits() + c.getCredits() > maxCredits) {
			return false;
		}
		return true;
	}
}
