/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user.schedule;

import edu.ncsu.csc216.pack_scheduler.course.ConflictException;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.util.ArrayList;

/**
 * Handles functionality of the Student's Schedule.
 * @author Liam, Amiya
 */
public class Schedule {
	
    /** Arraylist to store schedule */
	private ArrayList<Course> schedule;
	
	/** Title of schedule */
	private String title;

	/**
	 * Constructs the Schedule class.
	 */
	public Schedule() {
		this.title = "My Schedule";
		schedule = new ArrayList<Course>();
	}
	
	/**
	 * Adds a course to the Schedule.
	 * @param course Course to be added
	 * @return true if the course is added to the schedule
	 */
	public boolean addCourseToSchedule(Course course) {
		for (int i = 0; i < schedule.size(); i++) {
			try {
				schedule.get(i).checkConflict(course);
			} catch(ConflictException e){
				throw new IllegalArgumentException("There is a conflict with the course.");
			}
		}
		for(int i = 0; i < schedule.size(); i++) {
			if(schedule.get(i).isDuplicate(course)){
				throw new IllegalArgumentException("You are already enrolled in " + course.getName());
			}
		}
		try{
			schedule.add(course);
		} catch(IllegalArgumentException e){
			return false;
		}
		return true;		
	}
	
	/**
	 * Removes the course from the Schedule.
	 * @param course Course to be removed
	 * @return true if the course is removed, else return false
	 */
	public boolean removeCourseFromSchedule(Course course) {
		for (int i = 0; i < schedule.size(); i++) {
			if (schedule.get(i).equals(course)) {
				schedule.remove(i);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Resets the Schedule to contain no courses.
	 */
	public void resetSchedule() {
		ArrayList<Course> newSchedule = new ArrayList<Course>();
		schedule = newSchedule;
	}
	
	/**
	 * Returns the all the courses in the Schedule.
	 * @return scheduleArray array of courses
	 */
	public String[][] getScheduledCourses() {
		String [][] scheduleArray = new String[schedule.size()][4];
		for (int i = 0; i < schedule.size(); i++) {
			scheduleArray[i][0] = ((Course) schedule.get(i)).getName();
			scheduleArray[i][1] = ((Course) schedule.get(i)).getSection();
			scheduleArray[i][2] = ((Course) schedule.get(i)).getTitle();
			scheduleArray[i][3] = ((Course) schedule.get(i)).getMeetingString();
		}
		
		return scheduleArray;
	}
	
	/**
	 * Sets the title of the Schedule.
	 * @param title schedule title
	 * @throws IllegalArgumentException if title is null
	 */
	public void setTitle(String title) {
		if (title == null) {
			throw new IllegalArgumentException();
		}
		this.title = title;
	}
	
	/**
	 * Returns the title of the Schedule.
	 * @return title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * Getter for the total number of credits scheduled
	 * @return s number of credits scheduled
	 */
	public int getScheduleCredits() {
		int s = 0;
		for(int i = 0; i < schedule.size(); i++) {
			s += schedule.get(i).getCredits();
		}
		return s;
	}
	/**
	 * Boolean method for determining whether or not a course can be added to the schedule
	 * @param c Course Object
	 * @return false is unable to add and true if able to add
	 */
	public boolean canAdd(Course c) {
		if(c == null) {
			return false;
		}
		for(int i = 0; i < schedule.size(); i++) {
			if(c.isDuplicate(schedule.get(i))) {
				return false;
			}
			try{
				c.checkConflict(schedule.get(i));
			} catch(ConflictException e) {
				return false;
			}
		}
		return true;
		
	}
	

}
