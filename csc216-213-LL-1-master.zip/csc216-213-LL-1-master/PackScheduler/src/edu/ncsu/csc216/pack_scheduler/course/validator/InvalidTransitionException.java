/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

/**
 * Handles Invalid Transition Exceptions.
 * @author Liam, Amiya
 */
public class InvalidTransitionException extends Exception {

    /** Serial Version UID */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructs parameterized conflict exception with a default message.
	 * 
	 * @param message
	 *            default message used for the conflict exception
	 */
	public InvalidTransitionException(String message) {
		super(message);
	}

	/**
	 * Constructs a conflict exception with a custom message.
	 */
	public InvalidTransitionException() {
		super("Invalid FSM Transition.");
	}

}
