package edu.ncsu.csc216.pack_scheduler.course.roll;

import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.util.LinkedAbstractList;

/**
 * Creates the course roll linked list of students
 * 
 * @author Anderson
 *
 */
public class CourseRoll {

	/** LinkedAbstractList of students */
	private LinkedAbstractList<Student> roll;

	/** Enrollment cap */
	private int enrollmentCap;

	/** Smallest class size */
	private static final int MIN_ENROLLMENT = 10;

	/** Largest class size */
	private static final int MAX_ENROLLMENT = 250;

	/**
	 * Constructor for the CourseRoll class
	 * 
	 * @param enrollmentCap
	 *            the maximum number of allowable members of the class
	 */
	public CourseRoll(int enrollmentCap) {
		setEnrollmentCap(enrollmentCap);
		roll = new LinkedAbstractList<Student>(enrollmentCap);
	}

	/**
	 * Getter for the enrollmentCap
	 * 
	 * @return enrollmentCap the maximum number of allowable members of the
	 *         class
	 */
	public int getEnrollmentCap() {

		return enrollmentCap;
	}

	/**
	 * Setter for the enrollmentCap
	 * 
	 * @param enrollmentCap
	 *            the maximum number of allowable members of the class
	 */
	public void setEnrollmentCap(int enrollmentCap) {

		if (enrollmentCap < MIN_ENROLLMENT || enrollmentCap > MAX_ENROLLMENT) {

			throw new IllegalArgumentException();
		}
		this.enrollmentCap = enrollmentCap;
	}

	/**
	 * Method to enroll a student in a course
	 * 
	 * @param s
	 *            Student object
	 */
	public void enroll(Student s) {

		if (s == null) {
			throw new IllegalArgumentException();
		}

		if (roll.size() > enrollmentCap) {
			throw new IllegalArgumentException();
		}

		if (roll.contains(s)) {
			throw new IllegalArgumentException();
		}

		try {
			roll.add(s);
		} catch (IllegalArgumentException e) {

			// catch exception
		}

	}

	/**
	 * Method to drop a student from a class
	 * 
	 * @param s
	 *            Student object
	 */
	public void drop(Student s) {
		if (s == null) {
			throw new IllegalArgumentException();
		}

		try {
			roll.remove(s);
		} catch (IllegalArgumentException e) {

			// catch exception
		}

	}

	/**
	 * Method to determine the number of open seats in an available course
	 * 
	 * @return the number of seats remaining in the class
	 */
	public int getOpenSeats() {
		return enrollmentCap - roll.size();
	}

	/**
	 * Boolean method to determine whether or not a student can enroll in a
	 * class
	 * 
	 * @param s
	 *            Student object
	 * @return false for unable to enroll and true for able to enroll.
	 */
	public boolean canEnroll(Student s) {
		if (getOpenSeats() <= 0) {
			return false;
		}
		if (roll.size() > 0) {
			for (int i = 0; i <= roll.size(); i++) {
				if (s.equals(roll.get(i))) {
					return false;
				}
			}
		}
		return true;
	}
}
