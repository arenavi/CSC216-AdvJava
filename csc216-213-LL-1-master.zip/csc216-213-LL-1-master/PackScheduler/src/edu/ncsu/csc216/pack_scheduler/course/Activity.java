package edu.ncsu.csc216.pack_scheduler.course;


/**
 * Super class for implementing Course and Event Objects
 * @author Anderson
 *
 */
public abstract class Activity implements Conflict {

	/** Maximum minutes allowed */
	private static final int UPPER_TIME = 2400;
	/** Maximum Hours allowed */
	private static final int UPPER_HOUR = 60;
	/** Activities title. */
	private String title;
	/** Activities meeting days */
	private String meetingDays;
	/** Activities starting time */
	private int startTime;
	/** Activities ending time */
	private int endTime;
	/**
	 * Activities short display array 
	 * @return short display array
	 */
	public abstract String[] getShortDisplayArray();
	/**
	 * Activities long display array
	 * @return long display array
	 */
	public abstract String[] getLongDisplayArray();
	/**
	 * Returns boolean value indicating a duplicate activity or not
	 * @param activity Supplied Course or Event object
	 * @return boolean true if duplicate, false if not
	 */
	public abstract boolean isDuplicate(Activity activity);
		
	/**
	 * Constructs an Activity
	 * @param title title of activity
	 * @param meetingDays days with activity
	 * @param startTime start time of activity
	 * @param endTime end time of activity
	 */
	public Activity(String title, String meetingDays, int startTime, int endTime) {
		super();
		setTitle(title);
		setMeetingDays(meetingDays);
		setActivityTime(startTime, endTime);		
		this.title = title;
		this.meetingDays = meetingDays;
		this.startTime = startTime;
		this.endTime = endTime;		
	}

	/**
	 * Returns the Activities title.
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the Activities title.
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		if(title == null || title.equals("")){
			throw new IllegalArgumentException("Invalid Title");
		}		
		this.title = title;
	}

	/**
	 * Returns the Activities meeting days.
	 * @return the meetingDays
	 */
	public String getMeetingDays() {
		return meetingDays;
	}

	/**
	 * Sets the Activities meeting days.
	 * @param meetingDays the meetingDays to set
	 */
	public void setMeetingDays(String meetingDays) {
		if(meetingDays == null || meetingDays.equals("")){
			throw new IllegalArgumentException("Invalid meeting days");
		}
		this.meetingDays = meetingDays;
	}

	/**
	 * Returns the Activities start time.
	 * @return the startTime
	 */
	public int getStartTime() {
		return startTime;
	}

	/**
	* Returns the Activities end time.
	* @return the endTime
	*/
	public int getEndTime() {
		return endTime;
	}

	/**
	 * Sets the Activities start and end times
	 * @param startTime Course start time
	 * @param endTime Course End time
	 */
	public void setActivityTime(int startTime, int endTime) {
		if(startTime > endTime){
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if(startTime % 100 < 0 || startTime % 100 >= 60 ){
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if(endTime % 100 < 0 || endTime % 100 >= 60 ){
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if(startTime < 0 || startTime >= (UPPER_TIME) || endTime < 0 || endTime >= (UPPER_TIME)){
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if(meetingDays.matches("[A]?") && (startTime > 0 || endTime > 0)){
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if(meetingDays.matches("[MTWHF]+?") && endTime == 0){
			throw new IllegalArgumentException("Invalid meeting times");
		}
		this.startTime = startTime;
		this.endTime = endTime;
	}
		
	/**
	 * 
	 * Generates a String which includes the Meeting days and time in standard form
	 * @return String of Meeting day and standard time. 
	 */
	public String getMeetingString() {
		int endClock = getEndTime();
		int startClock = getStartTime();
		String s = getMeetingDays();
		if(s.equals("A")){
			return "Arranged";
		}		
		boolean amStart = false;
		boolean amEnd = false;
		if(startClock > UPPER_TIME / 2){
			amStart = false;
		}
		if(startClock < UPPER_TIME / 2){
			amStart = true;
		}
		if(endClock > UPPER_TIME / 2){
			amEnd = false;
		}
		if(endClock < UPPER_TIME / 2){
			amEnd = true;
		}
	    if(startClock > ((UPPER_TIME / 2) + UPPER_HOUR - 1)){
	       startClock = startClock - UPPER_TIME / 2;
	    }
	    if(endTime > ((UPPER_TIME / 2) + UPPER_HOUR - 1)){
	        endClock = endClock - UPPER_TIME / 2;
	    }
		int endLastMinute = endClock % 10;
		int startLastMinute = startClock % 10;
		startClock = startClock / 10;
		endClock = endClock / 10;
		int startMinute = startClock % 10;
		int endMinute = endClock % 10;
		startClock = startClock / 10;
		endClock = endClock / 10;
		int startHour = startClock % 10;
		int endHour = endClock % 10;
		startClock = startClock / 10;
		endClock = endClock / 10;
		int startHour2 = startClock % 10;
		int endHour2 = endClock % 10;
		String begin = "" + startHour + ":" + startMinute + startLastMinute;
		String end = "" + endHour + ":" + endMinute + endLastMinute;
		if(startHour2 != 0){
			begin = "" + startHour2 + startHour + ":" + startMinute + startLastMinute;
		}
		if(endHour2 != 0){
			end = "" + endHour2 + endHour + ":" + endMinute + endLastMinute;
		}
		
		if(amStart && amEnd){
			return s + " " + begin + "AM" + "-" + end + "AM";
		}
		if(amStart && !amEnd){
				return s + " " + begin + "AM" + "-" + end + "PM";
		}
		return s + " " + begin + "PM" + "-" + end + "PM";
	}

	/**
	 * Stores values in hash form
	 * @return hash values for Activity objects 
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + endTime;
		result = prime * result + ((meetingDays == null) ? 0 : meetingDays.hashCode());
		result = prime * result + startTime;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	/**
	 * Checks to make sure that object is not equal to another
	 * @param obj Object
	 * @return true if object is equal to another object false if not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Activity other = (Activity) obj;
		if (endTime != other.endTime)
			return false;
		if (meetingDays == null) {
			if (other.meetingDays != null)
				return false;
		} else if (!meetingDays.equals(other.meetingDays))
			return false;
		if (startTime != other.startTime)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see edu.ncsu.csc216.wolf_scheduler.course.Conflict#checkConflict(edu.ncsu.csc216.wolf_scheduler.course.Activity)
	 */
	@Override
	public void checkConflict(Activity possibleConflictingActivity) throws ConflictException {
		int startThis = this.getStartTime();
		int endThis = this.getEndTime();
		int startPCA = possibleConflictingActivity.getStartTime();
		int endPCA = possibleConflictingActivity.getEndTime();
		
		for(int i = 0; i < this.getMeetingDays().length(); i++){
			if(this.getMeetingDays().charAt(i) == 'A'){
				break;
			}
			for(int j = 0; j < possibleConflictingActivity.getMeetingDays().length(); j++){
				if(this.getMeetingDays().charAt(i) == possibleConflictingActivity.getMeetingDays().charAt(j)){
					if(startThis >= startPCA && startThis <= endPCA){
						throw new ConflictException();
					}
					if(startPCA >= startThis && startPCA <= endThis){
						throw new ConflictException();
					}
				}
			}
		}
	}
}