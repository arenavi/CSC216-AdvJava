/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

import edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll;
import edu.ncsu.csc216.pack_scheduler.course.validator.CourseNameValidator;
import edu.ncsu.csc216.pack_scheduler.course.validator.InvalidTransitionException;

/**
 * Creates a Course object
 * @author Anderson
 *
 */
public class Course extends Activity implements Comparable<Course> {
	/** Minimum name length */
	private static final int MIN_NAME_LENGTH = 4;
	/** Maximum name length */
	private static final int MAX_NAME_LENGTH = 6;
	/** Maximum credits */
	private static final int MAX_CREDITS = 5;
	/** MinimumCredits */
	private static final int MIN_CREDITS = 1;
	/** Required Length of Section */
	private static final int SECTION_LENGTH = 3;
	/** Course's name. */
	private String name;
	/** Course's section. */
	private String section;
	/** Course's credit hours */
	private int credits;
	/** Course's instructor */
	private String instructorId;
	/**Course Name Validator*/
	private CourseNameValidator validator = new CourseNameValidator();
	/** Course roll */
	private CourseRoll roll;
	/**
	 * Constructs a Course object with the given parameters
	 * @param name the name of the course
	 * @param title the title of the course
	 * @param section the section of the course
	 * @param credits the credit hours of the course
	 * @param instructorId the instructor's unity id
	 * @param enrollmentCap the enrollment cap
	 * @param meetingDays the days the course meets
	 * @param startTime the time the course starts
	 * @param endTime the time the course ends
	 */
	public Course(String name, String title, String section, int credits, String instructorId, int enrollmentCap, String meetingDays, int startTime, int endTime) {
		super(title, meetingDays, startTime, endTime);
		setName(name);
		setTitle(title);
		setSection(section);
		setCredits(credits);
		setInstructorId(instructorId);
		setMeetingDays(meetingDays);
		setActivityTime(startTime, endTime);
		this.name = name;
		this.section = section;
		this.credits = credits;
		this.instructorId = instructorId;
		roll = new CourseRoll(enrollmentCap);
		
	}
	/**
	 * Constructs a Course object with the given name, title, section, credits instructorID, and meetingDays for
	 * courses that are arranged.
	 * @param name name of Course
	 * @param title title of Course
	 * @param section section of Course
	 * @param credits credit hours for Course
	 * @param instructorId instructor's unity ID
	 * @param enrollmentCap the enrollment cap
	 * @param meetingDays meeting days for Course as series of chars
	 */
	public Course(String name, String title, String section, int credits, String instructorId, int enrollmentCap, String meetingDays) {
		this(name, title, section, credits, instructorId, enrollmentCap, meetingDays, 0, 0);
	}
	/**
	 * Returns the Course's name.
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets the Course's name.  If the name is null, has a length less than 4 or 
	 * greater than 6, an IllegalArgumentException is thrown.
	 * @param name the name to set
	 * @throws IllegalArgumentException if name is null or length is less than 4 or 
	 * greater than 6
	 */
	private void setName(String name) {
	    if (name == null) {
	        throw new IllegalArgumentException("Invalid name");
	    }
	    if (name.length() <  MIN_NAME_LENGTH || name.length() >  MAX_NAME_LENGTH) {
	        throw new IllegalArgumentException("Invalid name");
	    }
	    try{
	    	validator.isValid(name);
	    } catch(InvalidTransitionException e){
	    	throw new IllegalArgumentException("Invalid name");
	    }
	    this.name = name;
	}
	/**
	 * Returns the Course's section.
	 * @return the section
	 */
	public String getSection() {
		return section;
	}
	/**
	 * Sets the Course's section.
	 * @param section the section to set
	 */
	public void setSection(String section) {
		if(section == null || section.equals("")){
			throw new IllegalArgumentException("Invalid section");
		}
		if(section.length() != SECTION_LENGTH){
			throw new IllegalArgumentException("Invalid section");
		}
		for(int i = 0; i < SECTION_LENGTH; i++){
			if (!Character.isDigit(section.charAt(i))){
				throw new IllegalArgumentException("Invalid section");
			}
		}
		this.section = section;
	}
	/**
	 * Returns the Course's credit amount.
	 * @return the credits
	 */
	public int getCredits() {
		return credits;
	}
	/**
	 * Sets the Course's credit amount.
	 * @param credits the credits to set
	 */
	public void setCredits(int credits) {
		if(credits < MIN_CREDITS || credits > MAX_CREDITS){
			throw new IllegalArgumentException();
		}
		
		this.credits = credits;
	}
	/**
	 * Returns the Course's instructor ID.
	 * @return the instructorId
	 */
	public String getInstructorId() {
		return instructorId;
	}
	/**
	 * Sets the Course's instructor ID.
	 * @param instructorId the instructorId to set
	 */
	public void setInstructorId(String instructorId) {
		if(instructorId == null || instructorId.equals("")){
			throw new IllegalArgumentException("Invalid instructor id");
		}
		this.instructorId = instructorId;
	}
	
	
	/**
	 * Stores values in hash form
	 * @return hash values for Course object 
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + credits;
		result = prime * result + ((instructorId == null) ? 0 : instructorId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		return result;
	}
	/**
	 * Checks to make sure that object is not equal to another
	 * @param obj Object
	 * @return true if object is equal to another object false if not
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (credits != other.credits)
			return false;
		if (instructorId == null) {
			if (other.instructorId != null)
				return false;
		} else if (!instructorId.equals(other.instructorId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} else if (!section.equals(other.section))
			return false;
		return true;
	}
	/**
	 * Returns a comma separated value String of all Course fields.
	 * @return String representation of Course
	 */
	@Override
	public String toString() {
	    if (getMeetingDays().equals("A")) {
	        return name + "," + getTitle() + "," + section + "," + credits + "," + instructorId + "," + roll.getEnrollmentCap() + "," + getMeetingDays();
	    }
	    return name + "," + getTitle() + "," + section + "," + credits + "," + instructorId + "," + roll.getEnrollmentCap() + "," + getMeetingDays() + "," + getStartTime() + "," + getEndTime(); 
	}
	
	
	/**
	 * Returns a short display array of an Course
	 * @return shortDisplayArray array of the Course object
	 */
	@Override
	public String[] getShortDisplayArray() {
		String [] shortDisplayArray = new String[5];
		shortDisplayArray[0] = getName();
		shortDisplayArray[1] = getSection();
		shortDisplayArray[2] = getTitle();
		shortDisplayArray[3] = getMeetingString();
		shortDisplayArray[4] = String.valueOf(roll.getOpenSeats());
		return  shortDisplayArray;
	}
	/**
	 * Returns a long display array of a Course
	 * @return longDisplayArray array of the Course object
	 */
	@Override
	public String[] getLongDisplayArray() {
		String [] longDisplayArray = new String[7];
		longDisplayArray[0] = getName();
		longDisplayArray[1] = getSection();
		longDisplayArray[2] = getTitle();
		longDisplayArray[3] = String.valueOf(getCredits());
		longDisplayArray[4] = getInstructorId();
		longDisplayArray[5] = getMeetingString();
		longDisplayArray[6] = "";
		return longDisplayArray;
	}
	/**
	 * Sets the meetingDays for a Course object
	 */
	@Override
	public void setMeetingDays(String meetingDays) {
		if(meetingDays == null || meetingDays.equals("")){
			throw new IllegalArgumentException("Invalid meeting days");
		}
		if(!meetingDays.matches("[MTWHFA]+?")){
			throw new IllegalArgumentException("Invalid meeting days");
		}
		if(meetingDays.contains("A") && meetingDays.length() != 1){
				throw new IllegalArgumentException("Invalid meeting days");
		}
		super.setMeetingDays(meetingDays);
	}
	/**
	 * Checks to be sure that a duplicate Course is not being called by Activity
	 * @return true if duplicate and false if not duplicate
	 */
	@Override
	public boolean isDuplicate(Activity activity) {
		if(activity instanceof Course){
			Course c = (Course) activity;		
			return c.getName().equals(this.getName());
		}
		return false;		
	}
	/**
	 * Compares the Courses to determine if they are the same or not
	 */
	@Override
	public int compareTo(Course c) {
		if (this.getName().compareTo(c.getName()) != 0) {
			return this.getName().compareTo(c.getName());
		} else if (this.getSection().compareTo(c.getSection()) != 0) {
			return this.getSection().compareTo(c.getSection());
		} else {
			return 0;
		}
	}
	/**
	 * Getter for the Course roll object
	 * @return roll Course Roll object
	 */
	public CourseRoll getCourseRoll(){
		return roll;
	}
	
}
