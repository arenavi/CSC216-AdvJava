/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.roll;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import edu.ncsu.csc216.pack_scheduler.user.Student;


/**
 * Tests the Course Roll class for functionality
 * @author Anderson
 *
 */
public class CourseRollTest {
	private Student student1;
	private Student student2;
	private Student student3;
	private CourseRoll rollTest;
	/** Enrollment cap */
    private int enrollmentCap = 50;    
    /** Smallest class size */
    @SuppressWarnings("unused")
    private static final int MIN_ENROLLMENT = 10;
        /** Largest class size */
    @SuppressWarnings("unused")
    private static final int MAX_ENROLLMENT = 250;
   
    /**
     * Sets up the testing environment.
     */
    @Before
	public void testSetUp(){
		rollTest = new CourseRoll(enrollmentCap);
        student1 = new Student("Liam", "Hall", "lbhall2",  "lbhall2@ncsu.edu", "pw", 15);
        student2 = new Student("Piam", "Pall", "pbhall2", "pbhall2@ncsu.edu", "pw", 15);
        student3 = new Student("Miam", "Mall", "mbhall2", "mbhall2@ncsu.edu", "pw", 15);
		rollTest.enroll(student1);
		rollTest.enroll(student2);
		rollTest.enroll(student3);
	}
 
    /**
     * Tests the Course Roll constructor.
     */
	@Test
	public void testCourseRoll() {
		try {
			assertEquals(50, rollTest.getEnrollmentCap());
		} catch(IllegalArgumentException e) {

		    //do nothing
		}
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll#getEnrollmentCap()}.
	 */
	@Test
	public void testGetEnrollmentCap() {
		assertEquals(50, rollTest.getEnrollmentCap());
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll#setEnrollmentCap(int)}.
	 */
	@Test
	public void testSetEnrollmentCap() {
		try{
			rollTest.setEnrollmentCap(-1);
		} catch(IllegalArgumentException e) {
			assertEquals(null, e.getMessage());
		}
		
		
		rollTest.setEnrollmentCap(enrollmentCap);
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll#drop(edu.ncsu.csc216.pack_scheduler.user.Student)}.
	 */
	@Test
	public void testDrop() {
		try{
			rollTest.drop(null);
		} catch(IllegalArgumentException e) {
			assertEquals(null, e.getMessage());
		}
		rollTest.drop(student1);
		assertEquals(48, rollTest.getOpenSeats());
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll#getOpenSeats()}.
	 */
	@Test
	public void testGetOpenSeats() {
		assertEquals(47, rollTest.getOpenSeats());
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll#canEnroll(edu.ncsu.csc216.pack_scheduler.user.Student)}.
	 */
	@Test
	public void testCanEnroll() {
		assertFalse(rollTest.canEnroll(student3));
		rollTest.drop(student2);
		rollTest.drop(student1);
		rollTest.drop(student3);
		assertFalse(rollTest.canEnroll(student2));
		
	}

}
