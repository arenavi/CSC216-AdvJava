package edu.ncsu.csc216.pack_scheduler.io;

import static org.junit.Assert.*;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.user.Student;

/**
 * Tests the different methods in the StudentRecordIO Class
 * @author Anderson, Udeh, Sam
 *
 */
public class StudentRecordIOTest {
	/** Valid course records */
	private final String validTestFile = "test-files/student_records.txt";
	/** hash password field */
	private String hashPW;
	/** Invalid Student Records */
	private final String invalidTestFile = "test-files/invalid_student_records.txt";
	/** HASH ALGORITHM */
	private static final String HASH_ALGORITHM = "SHA-256";
	private final String validStudent1 = "Zahir,King,zking,orci.Donec@ametmassaQuisque.com,pw,15";
	private final String validStudent2 = "Cassandra,Schwartz,cschwartz,semper@imperdietornare.co.uk,pw,4";
	private final String validStudent3 = "Shannon,Hansen,shansen,convallis.est.vitae@arcu.ca,pw,14";
	private final String validStudent4 = "Demetrius,Austin,daustin,Curabitur.egestas.nunc@placeratorcilacus.co.uk,pw,18";
	private final String validStudent5 = "Raymond,Brennan,rbrennan,litora.torquent@pellentesquemassalobortis.ca,pw,12";
	private final String validStudent6 = "Emerald,Frost,efrost,adipiscing@acipsumPhasellus.edu,pw,3";
	private final String validStudent7 = "Lane,Berg,lberg,sociis@non.org,pw,14";
	private final String validStudent8 = "Griffith,Stone,gstone,porta@magnamalesuadavel.net,pw,17";
	private final String validStudent9 = "Althea,Hicks,ahicks,Phasellus.dapibus@luctusfelis.com,pw,11";
	private final String validStudent10 = "Dylan,Nolan,dnolan,placerat.Cras.dictum@dictum.net,pw,5";
	private final String[] sortedStudents = {validStudent4, validStudent7, validStudent5, validStudent6, validStudent3, validStudent9, validStudent1, validStudent10, validStudent2, validStudent8};
	private final String[] validStudents = {validStudent1, validStudent2, validStudent3 , validStudent4, validStudent5, validStudent6, validStudent7, validStudent8, validStudent9, validStudent10};
	/**
	 * Tests the setUp method of the StudentRecordIO
	 * Creates hashPW's 
	 */
	@Before
	public void setUp() {
	    try {
	        String password = "pw";
	        MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
	        digest.update(password.getBytes());
	        hashPW = new String(digest.digest());
	        
			for (int i = 0; i < validStudents.length; i++) {
	            validStudents[i] = validStudents[i].replace(",pw,", "," + hashPW + ",");
	        }
	    } catch (NoSuchAlgorithmException e) {
	        fail("Unable to create hash during setup");
	    }
	}
	
	/**
	 * Compares two files to see if they are equal
	 * @param expFile Expected File
	 * @param actFile Actual File
	 */
	private void checkFiles(String expFile, String actFile) {
	    try {
	        Scanner expScanner = new Scanner(new FileInputStream(expFile));
	        Scanner actScanner = new Scanner(new FileInputStream(actFile));
	        
	        while (expScanner.hasNextLine()  && actScanner.hasNextLine()) {
	            String exp = expScanner.nextLine();
	            String act = actScanner.nextLine();
	            assertEquals("Expected: " + exp + " Actual: " + act, exp, act);
	        }
	        if (expScanner.hasNextLine()) {
	            fail("The expected results expect another line " + expScanner.nextLine());
	        }
	        if (actScanner.hasNextLine()) {
	            fail("The actual results has an extra, unexpected line: " + actScanner.nextLine());
	        }
	        
	        expScanner.close();
	        actScanner.close();
	    } 
	    catch (IOException e) {
	        fail("Error reading files.");
	    }
	}
	/**
	 * Checks that a student with no credit hours will be given Max_Credits
	 * @throws FileNotFoundException if file is not valid
	 */
	@Test
	public void processStudentNoCredits() throws FileNotFoundException{
		SortedList<Student> students = StudentRecordIO.readStudentRecords(validTestFile);
		students.add(new Student("Anderson", "Rowe", "warowe", "warowe@ncsu.edu", hashPW));
		assertEquals(11, students.size());
	}
	
	/**
	 * Checks to ensure that an invalid student cannot be added
	 * @throws FileNotFoundException if file is not valid
	 */
	@Test
	public void testReadInvalidCourseRecords() throws FileNotFoundException {
		SortedList<Student> students;
		students = StudentRecordIO.readStudentRecords(invalidTestFile);
		assertEquals(0, students.size());
	}
	
	/**
	 * Tests to ensure that Student Records are able to be read correctly
	 */
	@Test
	public void testReadStudentRecords() {
		try {
			SortedList<Student> students = StudentRecordIO.readStudentRecords(validTestFile);
			assertEquals(10, students.size());
			
			for (int i = 0; i < sortedStudents.length; i++) {
				assertEquals(sortedStudents[i].substring(0, 10), students.get(i).toString().substring(0, 10));
			}
		} catch (FileNotFoundException e) {
			fail("Unexpected error reading " + validTestFile);
		}
		
	}
	/**
	 * Tests to see if Student Records are able to be written without permissions
	 */
	@Test
	public void testWriteStudentRecordsNoPermissions() {
		SortedList<Student> students = new SortedList<Student>();
		students.add(new Student("Zahir", "King", "zking", "orci.Donec@ametmassaQuisque.com", hashPW, 15));

		try {
			StudentRecordIO.writeStudentRecords("/home/sesmith5/actual_student_records.txt", students);
			fail("Attempted to write to a directory location that doesn't exist or without the appropriate permissions and the write happened.");
		} catch (IOException e) {
			assertEquals("/home/sesmith5/actual_student_records.txt (Permission denied)", e.getMessage());
		}
			checkFiles("ts-test-files/expected_student_records.txt", "ts-test-files/actual_student_records.txt");
	}
}
