package edu.ncsu.csc216.pack_scheduler.user;

import static org.junit.Assert.*;


import org.junit.Test;

/**
 * Tests the different methods used in the Student Class
 * @author Anderson, Udeh, Sam
 *
 */
public class StudentTest {

	/**
	 * The String firstName of the Student
	 */
	private static final String FIRST_NAME = "John";
	/**
	 * The String lastName of the Student
	 */
	private static final String LAST_NAME = "Smith";
	/**
	 * The String id of the Student
	 */
	private static final String ID = "jsmith12";
	/**
	 * The String email of the Student
	 */
	private static final String EMAIL = "jsmith12@ncsu.edu";
	/**
	 * The String password of the Student
	 */
	private static final String PASSWORD = "hashedpassword";
	/**
	 * The maximum number of credits a student can take
	 */
	public static final int MAX_CREDITS = 18;
	
	
	/**
	 * Tests the hash code method for appropriate functionality
	 * Tests for equality in both directions 
	 * Tests for each of the fields
	 */
	@Test
	public void testHashCode() {
		User s0 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s2 = new Student("Joe", LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s3 = new Student(FIRST_NAME, "Ma", ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s4 = new Student(FIRST_NAME, LAST_NAME, "bjnewell", EMAIL, PASSWORD, MAX_CREDITS);
		User s5 = new Student(FIRST_NAME, LAST_NAME, ID, "bjnewell@ncsu.edu", PASSWORD, MAX_CREDITS);
		User s6 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, "drowssap", MAX_CREDITS);
		User s7 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, 17);
		
		
		assertEquals(s0.hashCode(), s1.hashCode());
		
		
		assertNotEquals(s0.hashCode(), s2.hashCode());
		assertNotEquals(s0.hashCode(), s3.hashCode());
		assertNotEquals(s0.hashCode(), s4.hashCode());
		assertNotEquals(s0.hashCode(), s5.hashCode());
		assertNotEquals(s0.hashCode(), s6.hashCode());
		assertNotEquals(s0.hashCode(), s7.hashCode());
	}

	/**
	 * Tests to ensure that the constructor works properly
	 * Testing for null setId
	 * Testing for empty string setId
	 * Testing for a valid construction
	 */
	@Test
	public void testStudentStringStringStringStringStringInt() {
		Student s = null;
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, null, EMAIL, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, "", EMAIL, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
			
		}
		catch(IllegalArgumentException e) {
			fail();
		}
	}	
	/**
	 * Tests to ensure that the constructor works properly
	 * Testing for the first and last name being null
	 * Testing for the first and last name being an empty string.
	 * Testing a valid construction 
	 * Checks for invalid emails such as no @ or .
	 * Checks for valid passwords
	 */
	@Test
	public void testStudentStringStringStringStringString() {
		
		Student s = null;
		try {
			s = new Student(null, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
	
		s = null;
		try {
			s = new Student("", LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		try {
			s = new Student(FIRST_NAME, LAST_NAME , ID, EMAIL, PASSWORD, MAX_CREDITS);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		} catch (IllegalArgumentException e) {
			fail();
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, null, ID, EMAIL, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, "", ID, EMAIL, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		try {
			s = new Student(FIRST_NAME, LAST_NAME , ID, EMAIL, PASSWORD, MAX_CREDITS);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		} catch (IllegalArgumentException e) {
			fail();
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, null, EMAIL, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, "", EMAIL, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		try {
			s = new Student(FIRST_NAME, LAST_NAME , ID, EMAIL, PASSWORD, MAX_CREDITS);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		} catch (IllegalArgumentException e) {
			fail();
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, null, PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, "", PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, "email.com", PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, "email@website", PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, "email.thing@websitecom", PASSWORD, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		try {
			s = new Student(FIRST_NAME, LAST_NAME , ID, EMAIL, PASSWORD, MAX_CREDITS);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		} catch (IllegalArgumentException e) {
			fail();
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, null, MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, "", MAX_CREDITS);
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}
		
		try {
			s = new Student(FIRST_NAME, LAST_NAME , ID, EMAIL, PASSWORD, MAX_CREDITS);
			assertEquals(FIRST_NAME, s.getFirstName()); 
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(PASSWORD, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		} catch (IllegalArgumentException e) {
			fail();
		}
		
	}

	/**
	 * Tests the ability to set a correct first name
	 * Testing for null setFirstName
	 * Testing for empty string setFirstName
	 * and fails if student is made and shouldn't have been
	 */
	@Test
	public void testSetFirstName() {
		User s = null;

		try{
			s = new Student(null, LAST_NAME, ID, EMAIL, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student("", LAST_NAME, ID, EMAIL, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
	}

	/**
	 * Tests the ability to set a correct last name
	 * Testing for null setLastName
	 * Testing for empty string setLastName
	 * and fails if student is made and shouldn't have been
	 */
	@Test
	public void testSetLastName() {
		User s = null;
		
		try{
			s = new Student(FIRST_NAME, null, ID, EMAIL, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student(FIRST_NAME, "", ID, EMAIL, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
	}

	/**
	 * Tests the ability to set a correct Email
	 * Testing for null setEmail
	 * Testing for empty string setEmail
	 * Testing for invalid emails
	 * and fails if student is made and shouldn't have been
	 */
	@Test
	public void testSetEmail() {
		User s = null;
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, null, PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, "", PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student("FIRST_NAME", LAST_NAME, ID, "email@ncsuedu", PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
	
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, "email.ncsu@edu", PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, "email.ncsu.edu", PASSWORD);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
	}

	/**
	 * Tests the ability to set a correct password
	 * Testing to see if setPassword is null 
	 * Testing to see if setPassword is an emptyString
	 * fails if student is made and shouldn't have been
	 */
	@Test
	public void testSetPassword() {
		User s = null;
		//Testing to see if setPassword is null
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, "email.ncsu.edu", null);
			fail(); //student made when shouldn't have been
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		//Testing to see if setPassword is empty string
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, "");
			fail(); //student made when shouldn't have been
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
	}

	/**
	 * Tests the ability to set the maxCredits
	 * Testing to see if maxCredits can be less than 3
	 * testing to see if maxCredits can be more than 18
	 * Fails if student is made and shouldn't have been
	 */
	@Test
	public void testSetMaxCredits() {
		User s = null;
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, 1);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
		
		try{
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, 20);
			fail(); 
		}
		catch(IllegalArgumentException e){
			assertNull(s);
		}
	}

	/**
	 * Tests to ensure that no objects are equal to each other
	 * Tests for equality in both directions 
	 * Tests for each of the fields 
	 */
	@Test
	public void testEqualsObject() {
		User s0 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s2 = new Student("Jane", LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s3 = new Student(FIRST_NAME, "Doe", ID, EMAIL, PASSWORD, MAX_CREDITS);
		User s4 = new Student(FIRST_NAME, LAST_NAME, "jnewelld", EMAIL, PASSWORD, MAX_CREDITS);
		User s5 = new Student(FIRST_NAME, LAST_NAME, ID, "jnewelld@ncsu.edu", PASSWORD, MAX_CREDITS);
		User s6 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, "fetmus", MAX_CREDITS);
		User s7 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, 17);
		
		
		assertTrue(s0.equals(s1));
		assertTrue(s1.equals(s0));
		
		
		assertFalse(s0.equals(s2));
		assertFalse(s0.equals(s3));
		assertFalse(s0.equals(s4));
		assertFalse(s0.equals(s5));
		assertFalse(s0.equals(s6));
		assertFalse(s0.equals(s7));
	}

	/**
	 * Tests to ensure that the toString method is outputting the correct information
	 */
	@Test
	public void testToString() {
		User s0 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		String t0 = "John,Smith,jsmith12,jsmith12@ncsu.edu,hashedpassword,18";
		
		assertEquals(t0, s0.toString());
		
		User s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD);
		String t1 = "John,Smith,jsmith12,jsmith12@ncsu.edu,hashedpassword,18";
		
		assertEquals(t1, s1.toString());
	}
	/**
	 * Test CompareTo method which should arrange the list s0--s4 in sorted order.
	 */
	@Test
	public void testCompareTo() {
		Student s0 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		Student s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		Student s2 = new Student("Aoe", LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		Student s3 = new Student("Zoe", LAST_NAME, ID, EMAIL, PASSWORD, MAX_CREDITS);
		Student s4 = new Student(FIRST_NAME, "Tmith", ID, EMAIL, PASSWORD, MAX_CREDITS);
		Student s5 = new Student(FIRST_NAME, LAST_NAME, "warowe1", EMAIL, PASSWORD, MAX_CREDITS);
		assertEquals(0, s0.compareTo(s1));
		if(s0.compareTo(s2) <= 0) {
			fail();
		}
		
		if(s0.compareTo(s3) >= 0) {
			fail();
		}
		
		if(s0.compareTo(s4) >= 0) {
			fail();
		}
		
		if(s0.compareTo(s5) >= 0) {
			fail();
		}
	}

}
