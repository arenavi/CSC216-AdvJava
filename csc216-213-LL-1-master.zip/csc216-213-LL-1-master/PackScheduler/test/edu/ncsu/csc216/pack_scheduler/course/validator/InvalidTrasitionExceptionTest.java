/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Tests the InvalidTransitionException class.
 * @author Liam, Amiya
 */
public class InvalidTrasitionExceptionTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.wolf_scheduler.course.InvalidTrasitionException#InvalidTrasitionException(java.lang.String)}.
	 */
	@Test
	public void testInvalidTrasitionString() {
		InvalidTransitionException ite = new InvalidTransitionException("Custom exception Message");
	    assertEquals("Custom exception Message", ite.getMessage());
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.wolf_scheduler.course.InvalidTrasitionException#InvalidTrasitionException()}.
	 */
	@Test
	public void testInvalidTrasitionException() {
		InvalidTransitionException ite = new InvalidTransitionException();
	    assertEquals("Invalid FSM Transition.", ite.getMessage());
	}

}
