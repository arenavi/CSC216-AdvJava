/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Checks that the activities scheduled do not conflict with each other by having 
 * courses or events scheduled on the same days during the same times. 
 * @author Anderson
 *
 */
public class ActivityTest {

	/**
	 * Test method for {@link edu.ncsu.csc216.wolf_scheduler.course.Activity#checkConflict(edu.ncsu.csc216.wolf_scheduler.course.Activity)}.
	 */
	@Test
	public void testCheckConflict() {
	    Activity a1 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 50, "MW", 1330, 1445);
	    Activity a2 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 50, "TH", 1330, 1445);
	    Activity c1 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 50, "W", 1400, 1430);
	    Activity c2 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 50, "MW", 1330, 1445);
	    /*Activity e1 = new Event("Lunch", "MTWHF", 1100, 1200, 1, "Lunch with classmates");
	    Activity e2 = new Event("Exercise", "MWF", 1600, 1800, 1, "Workout Time");
	    Activity e3 = new Event("Lunch", "W", 1400, 1430, 1, "Lunch with classmates");
	    Activity e4 = new Event("Exercise", "MW", 1330, 1445, 1, "Workout Time");*/
	    
	    try {
	        a1.checkConflict(a2);
	        assertEquals("Incorrect meeting string for this Activity.", "MW 1:30PM-2:45PM", a1.getMeetingString());
	        assertEquals("Incorrect meeting string for possibleConflictingActivity.", "TH 1:30PM-2:45PM", a2.getMeetingString());
	    } catch (ConflictException e) {
	        fail("A ConflictException was thrown when two Activities at the same time on completely distinct days were compared.");
	    }
	
	  //Update a1 with the same meeting days and a start time that overlaps the end time of a2
	    a1.setMeetingDays("TH");
	    a1.setActivityTime(1445, 1530);
	    try {
	        a1.checkConflict(a2);
	        fail(); //ConflictException should have been thrown, but was not.
	    } catch (ConflictException e) {
	        //Check that the internal state didn't change during method call.
	        assertEquals("TH 2:45PM-3:30PM", a1.getMeetingString());
	        assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    }
	    
	    //Update a1 with a single meeting day shared and a end time that overlaps
	    a1.setMeetingDays("T");
	    a1.setActivityTime(1100, 1400);
	    try{
	    	a1.checkConflict(a2);
	    	fail(); //ConflictException should have been thrown
	    }
	    catch(ConflictException e){
	    	//Check that the internal state didn't change during the method call.
	    	assertEquals("T 11:00AM-2:00PM", a1.getMeetingString());
	    	assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    }
	  
	    
	    
	    
	    
	    //Ensure that valid times not overlapping allowed
	    a1.setMeetingDays("MTWHF");
	    a1.setActivityTime(900, 1000);
	    try{
	    	a1.checkConflict(a2);
	    	assertEquals("MTWHF 9:00AM-10:00AM", a1.getMeetingString());
	    	assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    	
	    }
	    catch(ConflictException e){
	    	//Check that the internal state didn't change during the method call.
	    	fail("Should not have thrown an exception!");
	    }
	    
	    //Ensure that the process works when reversing the activities
	    try{
	    	a2.checkConflict(a1);
	    	assertEquals("MTWHF 9:00AM-10:00AM", a1.getMeetingString());
	    	assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    }
	    catch(ConflictException e){
	    	fail("Should have thrown an exception");
	    }
	    
	    //Ensure that the process works when overlapping times
	    try{
	    	c1.checkConflict(c2);
	    	fail();
	    }
	    catch(ConflictException e){
	    	assertEquals("W 2:00PM-2:30PM", c1.getMeetingString());
	    	assertEquals("MW 1:30PM-2:45PM", c2.getMeetingString());
	    }
	}
}
