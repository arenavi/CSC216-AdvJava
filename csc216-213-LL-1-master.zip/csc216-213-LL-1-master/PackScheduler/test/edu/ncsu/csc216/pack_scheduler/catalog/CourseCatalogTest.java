package edu.ncsu.csc216.pack_scheduler.catalog;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;


/** Tests the CourseCatalog class
 * @author Anderson Rowe 
 * @author Udeh Onwuka
 * @author Samuel Pruett
 */
public class CourseCatalogTest {

	/** Valid course records */
	private final String validTestFile = "test-files/course_records.txt";
	/** Invalid course records */
	private final String invalidTestFile = "test-files/nvalid_course_records.txt";
	/** Second valid course records */
	
	/** Course name */
	private static final String NAME = "CSC216";
	/** Course title */
	private static final String TITLE = "Programming Concepts - Java";
	/** Course section */
	private static final String SECTION = "001";
	/** Course credits */
	private static final int CREDITS = 4;
	/** Course instructor id */
	private static final String INSTRUCTOR_ID = "sesmith5";
	/** Course meeting days */
	private static final String MEETING_DAYS = "TH";
	/** Course start time */
	private static final int START_TIME = 1330;
	/** Course end time */
	private static final int END_TIME = 1445;
	/** enrollment cap */
	private static final int ECAP = 50;
	
	/**
	 * Resets the test files so they can be used for other tests
	 * @throws Exception if files cannot be read
	 */
	@Before
	public void setUp() throws Exception {
		//Reset course_records.txt so that it's fine for other needed tests
		Path sourcePath = FileSystems.getDefault().getPath("test-files", "starter_course_records.txt");
		Path destinationPath = FileSystems.getDefault().getPath("test-files", "course_records.txt");
		try {
			Files.deleteIfExists(destinationPath);
			Files.copy(sourcePath, destinationPath);
		} catch (IOException e) {
			fail("Unable to reset files");
		}
	}
	/**
	 * Tests the CourseCatalog constructor
	 */
	@Test
	public void testCourseCatalog() {
		CourseCatalog catalog = new CourseCatalog();
		assertEquals(0, catalog.getCourseCatalog().length);
	}
	/**
	 * Tests the loadCoursesFromFile method
	 */
	@Test
	public void testLoadCoursesFromFile() {
		CourseCatalog catalog = new CourseCatalog();
		//invalid test file
		try {
			catalog.loadCoursesFromFile(invalidTestFile);
		} catch (IllegalArgumentException e) {
			assertEquals(0, catalog.getCourseCatalog().length);
			assertEquals("Unable to read file " + "test-files/nvalid_course_records.txt", e.getMessage());
		}
		//valid test file
		catalog.loadCoursesFromFile(validTestFile);
		assertEquals(8, catalog.getCourseCatalog().length);
	}
	/**
	 * Tests the addCoursesToCatalog method
	 */
	@Test
	public void testAddCoursesToCatalog() {
		CourseCatalog catalog = new CourseCatalog();
		catalog.loadCoursesFromFile(validTestFile);
		assertFalse(catalog.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, ECAP, MEETING_DAYS, START_TIME, END_TIME));
		assertEquals(8, catalog.getCourseCatalog().length);
		
		CourseCatalog catalog2 = new CourseCatalog();
		assertTrue(catalog2.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, ECAP, MEETING_DAYS, START_TIME, END_TIME));
		assertEquals(1, catalog2.getCourseCatalog().length);
	}
	/**
	 * Tests the removeCourseFromCatalog method
	 */
	@Test
	public void testRemoveCourseFromCatalog() {
		CourseCatalog catalog2 = new CourseCatalog();
		assertTrue(catalog2.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, ECAP, MEETING_DAYS, START_TIME, END_TIME));
		assertEquals(1, catalog2.getCourseCatalog().length);
		assertTrue(catalog2.removeCourseFromCatalog(NAME, SECTION));
		assertEquals(0, catalog2.getCourseCatalog().length);
	}
	/**
	 * Tests the saveCourseCatalog method
	 */
	@Test
	public void testSaveCourseCatalog() {
		//Test that empty schedule exports correctly
		CourseCatalog ws = new CourseCatalog();
		assertEquals(0, ws.getCourseCatalog().length);
		ws.saveCourseCatalog("test-files/actual_empty_export.txt");
		checkFiles("test-files/expected_empty_export.txt", "test-files/actual_empty_export.txt");
		
	}
	
	/**
	 * Helper method to compare two files for the same contents
	 * @param expFile expected output
	 * @param actFile actual output
	 */
	private void checkFiles(String expFile, String actFile) {
		try {
			Scanner expScanner = new Scanner(new File (expFile));
			Scanner actScanner = new Scanner(new File(actFile));
			
			while (actScanner.hasNextLine()) {
				assertEquals(expScanner.nextLine(), actScanner.nextLine());
			}
			if (expScanner.hasNextLine()) {
				fail();
			}
			
			expScanner.close();
			actScanner.close();
		} catch (IOException e) {
			fail("Error reading files.");
		}
	}

}

