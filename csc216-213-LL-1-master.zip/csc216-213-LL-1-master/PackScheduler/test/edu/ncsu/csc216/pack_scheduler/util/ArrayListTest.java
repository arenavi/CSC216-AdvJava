/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.user.Student;

/**
 * Tests the ArrayList class.
 * @author Amiya, Liam, Anderson
 */
public class ArrayListTest {
	
	private Student student1;
	private Student student2;
	private Student student3;
	
	private ArrayList<Student> testList;

	/**
	 * Sets the testing environment.
	 * @throws Exception exception
	 */
	@Before
	public void setup() throws Exception {

	    testList = new ArrayList<Student>();
		student1 = new Student("Liam", "Hall", "lbhall2",  "lbhall2@ncsu.edu", "pw", 15);
		student2 = new Student("Piam", "Pall", "pbhall2", "pbhall2@ncsu.edu", "pw", 15);
		student3 = new Student("Miam", "Mall", "mbhall2", "mbhall2@ncsu.edu", "pw", 15);
		
	}

	/**
	 * Tests the constructor.
	 */
	@Test
	public void testArrayList() {

		assertNotNull(testList);
		assertEquals(0, testList.size());
		}

	/**
	 * Tests the add method.
	 */
	@Test
    public void testAdd() {
        
		try{
        	testList.add(-1, student1);
        	testList.add(12, student1);
        } catch(IndexOutOfBoundsException e) {
        	//catch block
        }
		
		try {
			testList.add(0, null);
		} catch(NullPointerException e) {
			//catch block
		}
		
		testList.add(0, student1);
    	assertEquals(1, testList.size());
    	assertEquals(student1, testList.get(0));
    	testList.add(1, student2);
    	assertEquals(2, testList.size());
    	assertEquals(student2, testList.get(1));
	}

	/**
	 * Tests the addAt() method.
	 */
	@Test
	public void testAddAt() {
		try{
        	testList.set(-1, student1);
        	testList.set(12, student1);
        } catch(IndexOutOfBoundsException e) {
        	//catch block
        }
		
		try {
			testList.set(0, null);
		} catch(NullPointerException e) {
			//catch block
		}
		
		testList.add(0, student1);
		testList.add(1, student2);
	    try {
	    	testList.set(0, student3);
	    	assertEquals(student3, testList.get(0));
	    	testList.set(1, student1);
	    	assertEquals(student1, testList.get(1));
	    } catch(IndexOutOfBoundsException e) {
	        
	        //catch block
	    }
		
	}

	/**
	 * Tests the remove() method.
	 */
	@Test
	public void testRemove() {
		
		testList.add(0, student1);
		testList.add(1, student2);
		assertEquals(student2, testList.remove(1));
		try {
			testList.remove(-1);
			testList.remove(20);
			
		} catch (IndexOutOfBoundsException e) {
			//catch block
		}
	}
	/**
	 * Tests the get method
	 */
	@Test
	public void testGet() {
		try{
			testList.get(-1);
		} catch(IndexOutOfBoundsException e) {
			assertEquals(null, e.getMessage());
		}
	}
}
