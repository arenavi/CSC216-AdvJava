package edu.ncsu.csc216.pack_scheduler.course.validator;

import static org.junit.Assert.*;


import org.junit.Test;

/**
 * Tests the CourseNameValidatorFSM class.
 * @author Dr. Heckman
 *
 */
public class CourseNameValidatorFSMTest {
	
	private CourseNameValidatorFSM fsm = new CourseNameValidatorFSM();
	/**
	 * Tests to ensure that the Initial State is Valid
	 */
	@Test
	public void testIsValidStateInitial() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid(""));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must start with a letter.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the L State is Valid
	 */
	@Test
	public void testIsValidStateL() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("1CS216"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must start with a letter.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the LL State is Valid
	 */
	@Test
	public void testIsValidStateLL() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("C1C216"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must have 3 digits.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the LLL State is Valid
	 */
	@Test
	public void testIsValidStateLLL() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("CS1216"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only have 3 digits.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the LLLL State is Valid
	 */
	@Test
	public void testIsValidStateLLLL() {
		try {
			assertTrue(fsm.isValid("CSCC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("CSC1216"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only have 3 digits.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the D State is Valid
	 */
	@Test
	public void testIsValidStateD() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("CSCCSC"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name cannot start with more than 4 letters.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the DD State is Valid
	 */
	@Test
	public void testIsValidStateDD() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("CSC2SC"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must have 3 digits.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the DDD State is Valid
	 */
	@Test
	public void testIsValidStateDDD() {
		try {
			assertTrue(fsm.isValid("CSC216"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("CSC21D"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name must have 3 digits.", e.getMessage());
		}
	}
	/**
	 * Tests to ensure that the Suffix State is Valid
	 */
	@Test
	public void testIsValidStateSUF() {
		try {
			assertTrue(fsm.isValid("CSC216L"));
		} catch (InvalidTransitionException e) {
			fail();
		}
		try {
			assertFalse(fsm.isValid("CSC2165"));
		} catch (InvalidTransitionException e) {
			assertEquals("Course name can only have 3 digits.", e.getMessage());
		}
	}
}

