/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.user.Student;

/**
 * Test class for the LinkedAbstractList Class
 * @author Anderson
 *
 */
public class LinkedAbstractListTest {
    private Student student1;
    private Student student2;
    private Student student3;
    
    private LinkedAbstractList<Student> testList;

    /**
     * Sets the testing environment.
     * @throws Exception exception
     */
    @Before
    public void setup() throws Exception {
    	try{
    		testList = new LinkedAbstractList<Student>(-1);
    	} catch(IllegalArgumentException e) {
    		assertEquals(null, e.getMessage());
    	}
    	testList = new LinkedAbstractList<Student>(3);
        student1 = new Student("Liam", "Hall", "lbhall2",  "lbhall2@ncsu.edu", "pw", 15);
        student2 = new Student("Piam", "Pall", "pbhall2", "pbhall2@ncsu.edu", "pw", 15);
        student3 = new Student("Miam", "Mall", "mbhall2", "mbhall2@ncsu.edu", "pw", 15);
    }

    /**
     * Tests the constructor.
     */
    @Test
    public void testLinkedAbstractList() {
        assertNotNull(testList);
        assertEquals(0, testList.size());
        }

    /**
     * Tests the add method.
     */
    @Test
    public void testAdd() {
        
        try{
            testList.add(-1, student1);
            testList.add(12, student3);
        } catch(IndexOutOfBoundsException e) {
            assertEquals(null, e.getMessage());
        }
        
        try {
            testList.add(0, null);
        } catch(NullPointerException e) {
            //catch block
        }
        
        testList.add(0, student1);
        assertEquals(student1, testList.get(0));
        testList.add(0, student2);
        assertEquals(student2, testList.get(1));
    }

    /**
     * Tests the remove() method.
     */
    @Test
    public void testRemove() {
    	try {
            testList.remove(-1);
            testList.remove(20);
            
        } catch (IndexOutOfBoundsException e) {
           assertEquals(null, e.getMessage());
        }
        testList = new LinkedAbstractList<Student>(3);
    	testList.add(0, student1);
        testList.add(1, student2);
        testList.add(2, student3);
        testList.remove(2);
         
    }
    /**
     * Tests the get method
     */
    @Test
    public void testGet() {
        try{
            testList.get(-1);
        } catch(IndexOutOfBoundsException e) {
            assertEquals(null, e.getMessage());
        }
        
        assertEquals(0, testList.size());
    }
    /**
     * Tests the set method of the LinkedAbstractList class
     */
    @Test
    public void testSet() {
    	 try {
             testList.set(0, null);
         } catch(NullPointerException e) {
             //catch block
         }
    	 
    	 try{
             testList.set(-1, student1);
         } catch(IndexOutOfBoundsException e) {
             assertEquals(null, e.getMessage());
         }
    		 testList.add(0, student1);
    	 try { 
    		 testList.set(0, student1);
    	 } catch(IllegalArgumentException e) {
    		 //Nothing here
    	 }
    	 testList.add(1, student2);
    	 testList.set(1, student2);
    }
}
