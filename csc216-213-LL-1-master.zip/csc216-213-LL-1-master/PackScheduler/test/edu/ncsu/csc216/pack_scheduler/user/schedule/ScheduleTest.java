/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user.schedule;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;

/**
 * Tests the ScheduleTest class.
 * @author Liam, Amiya
 */
public class ScheduleTest {
	
    /** ArrayList of Schedule */
	private Schedule testSchedule;
	/** Course name */
	private static final String NAME = "CSC216";
	/** Course title */
	private static final String TITLE = "Programming Concepts - Java";
	/** Course section */
	private static final String SECTION = "001";
	/** Course credits */
	private static final int CREDITS = 4;
	/** Course instructor id */
	private static final String INSTRUCTOR_ID = "sesmith5";
	/** Course meeting days */
	private static final String MEETING_DAYS = "MW";
	/** Course start time */
	private static final int START_TIME = 1330;
	/** Course end time */
	private static final int END_TIME = 1445;
	/** enrollment cap */
	private static final int ECAP = 50;
	
	Course a = new Course(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID,  ECAP, MEETING_DAYS, START_TIME, END_TIME);
	
	
	/**
	 * Sets the testing environment.
	 * @throws Exception exception
	 */
	@Before
    public void setup() throws Exception {
        
        testSchedule = new Schedule();
    }

	/**
	 * Tests the Schedule constructor.
	 */
	@Test 
	public void testSchedule() {
		assertNotNull(testSchedule);
		
	}
	
	/**
	 * Tests the addCourseToSchedule() method.
	 */
	@Test 
	public void testAddCourseToSchedule() {
		assertTrue(testSchedule.addCourseToSchedule(a));
		assertEquals("CSC216", testSchedule.getScheduledCourses()[0][0]);
		try{
			testSchedule.addCourseToSchedule(a);
		} catch (IllegalArgumentException e) {
			assertEquals("There is a conflict with the course.", e.getMessage());
		}
		
	}
	
	/**
	 * Tests the removeCourseFromSchedule() method.
	 */
	@Test 
	public void testRemoveCourseFromSchedule() {
		assertTrue(testSchedule.addCourseToSchedule(a));
		assertTrue(testSchedule.removeCourseFromSchedule(a));
		assertEquals(0, testSchedule.getScheduledCourses().length);
		assertFalse(testSchedule.removeCourseFromSchedule(a));
	}
	
	/**
	 * Tests the resetSchedule() method.
	 */
	@Test 
	public void testResetSchedule() {
		testSchedule.resetSchedule();
		assertNotNull(testSchedule);
		assertEquals(0, testSchedule.getScheduledCourses().length);
	}
	
	/**
	 * Tests the getScheduledCourses() method.
	 */
	@Test 
	public void testGetScheduledCourses() {
		testSchedule.addCourseToSchedule(a);
		testSchedule.getScheduledCourses();
		assertNotNull(testSchedule);
		
	}
	
	/**
	 * Tests the setTitle() method.
	 */
	@Test 
	public void testSetTitle() {
		testSchedule.setTitle("Lab 7");
		assertEquals("Lab 7", testSchedule.getTitle());
		try{
			testSchedule.setTitle(null);
		} catch(IllegalArgumentException e){
			assertEquals(null, e.getMessage());
		}
		
	}
	

}
