package edu.ncsu.csc216.collections.list;

import static org.junit.Assert.*;


import org.junit.Test;
/**
 * Tests to ensure that the sorted list is working correctly
 * @author Anderson, Udeh, Sam
 *
 */
public class SortedListTest {
	/**
	 * A String contains 11 elements
	 */
	public String[] testStrings = {"apple", "banana", "grape", "peach", "pear", "orange", "grapefruit", "lemon", "lime", "liche", "dragonfruit"}; 
	
	/**
	 * Test sorted list contains the right elements
	 */
	@Test
	public void testSortedList() {
		SortedList<String> list = new SortedList<String>();
		assertEquals(0, list.size());
		assertFalse(list.contains("apple"));
		//Test that the list grows by adding at least 11 elements
		//Remember the list's initial capacity is 10
		for(int i = 0; i <= 10; i++){
			list.add("This number is " + i);
		}
		assertEquals(11, list.size());
		
	}
	/**
	 * Tests that elements can be added at correct locations in the sorted list array
	 */	
	@Test
	public void testAdd() {
		SortedList<String> list = new SortedList<String>();
		
		list.add("banana");
		assertEquals(1, list.size());
		assertEquals("banana", list.get(0));
		
		// Test adding to the front, middle and back of the list
		list.add("apple");
		list.add("bakery");
		list.add("zebra");
		assertEquals("apple", list.get(0));
		assertEquals("bakery", list.get(1));
		assertEquals("zebra", list.get(3));
		assertEquals(4, list.size());
		// Test adding a null element
		try{
			list.add(null);
			fail("cannot add a null element");
		}
		catch(NullPointerException e){
			assertEquals(4, list.size());
		}
		
		// Test adding a duplicate element
		try{
			list.add("apple");
			fail("apple cannot be added");
		}
		catch(IllegalArgumentException e){
			assertEquals(4, list.size());
		}
	}
	/**
	 * Tests that you can retrieve elements for selected index
	 */
	@Test
	public void testGet() {
		SortedList<String> list = new SortedList<String>();
		
		//Since get() is used throughout the tests to check the
		//contents of the list, we don't need to test main flow functionality
		//here.  Instead this test method should focus on the error 
		//and boundary cases.
		
		// Test getting an element from an empty list
		try {
			list.get(0);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(0, list.size());
			assertFalse(list.contains("banana"));
		}
		
		// Add some elements to the list
		for (int i = 0; i < testStrings.length; i++) {
			list.add(testStrings[i]);
		}
		
		
		// Test getting an element at an index < 0
		try {
			list.get(-1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(11, list.size());
			assertTrue(list.contains("banana"));
		}
		
		// Test getting an element at size
		try {
			list.get(list.size());
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(11, list.size());
			assertTrue(list.contains("banana"));
		}
		
	}
	/**
	 * Tests that you can remove elements from the arraylist
	 */
	@Test
	public void testRemove() {
		SortedList<String> list = new SortedList<String>();
		
		try {
			list.remove(0);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(0, list.size());
			assertFalse(list.contains("banana"));
		}
		// Add some elements to the list - at least 4
		for (int i = 0; i < testStrings.length; i++) {
			list.add(testStrings[i]);
		}
		
		// Test removing an element at an index < 0
		try {
			list.remove(-1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(11, list.size());
			assertTrue(list.contains("banana"));
		}
		
		// Test removing an element at size
		try {
			list.remove(list.size());
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(11, list.size());
			assertTrue(list.contains("banana"));
		}
		
		// Test removing a middle element
			list.remove(1);
			assertEquals(10, list.size());
			assertFalse(list.contains("banana"));

		
		// Test removing the last element
			list.remove(9);
			assertEquals(9, list.size());
			assertFalse(list.contains("pear"));

		
		// Test removing the first element
			list.remove(0);
			assertEquals(8, list.size());
			assertFalse(list.contains("apple"));
		
		// Test removing the last element
			String removed = list.remove(list.size() - 1);
			assertEquals(7, list.size());
			assertFalse(list.contains(removed));
	}
	
	/**
	 * Tests various indexOf functions in the sorted List
	 */
	@Test
	public void testIndexOf() {
		SortedList<String> list = new SortedList<String>();
		
		// Test indexOf on an empty list
		assertEquals(-1, list.indexOf("banana"));
		// Add some elements
		for (int i = 0; i < testStrings.length; i++) {
			list.add(testStrings[i]);
		}
		// Test various calls to indexOf for elements in the list
		//and not in the list
		assertEquals(0, list.indexOf("apple"));
		assertEquals(-1, list.indexOf("cookie"));
		// Test checking the index of null
		try{
			list.indexOf(null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(11 , list.size());
		}
		
	}
	
	/**
	 * Tests clearing the elements from the list
	 */
	@Test
	public void testClear() {
		SortedList<String> list = new SortedList<String>();

		// Add some elements
		for (int i = 0; i < testStrings.length; i++) {
			list.add(testStrings[i]);
		}
		// Clear the list
		assertEquals(11, list.size());
		list.clear();
		// Test that the list is empty
		assertEquals(0, list.size());
	}

	/**
	 * Tests to see whether or not a list is empty or has elements added
	 */
	@Test
	public void testIsEmpty() {
		SortedList<String> list = new SortedList<String>();
		
		// Test that the list starts empty
		assertTrue(list.isEmpty());
		// Add at least one element
		list.add(testStrings[0]);
		// Check that the list is no longer empty
		assertFalse(list.isEmpty());
	}

	/**
	 * Tests to see if the list contains certain elements
	 */
	@Test
	public void testContains() {
		SortedList<String> list = new SortedList<String>();
		
		// Test the empty list case
				assertFalse(list.contains(testStrings[0]));
				// Add some elements
				for (int i = 0; i < testStrings.length; i++) {
					list.add(testStrings[i]);
				}
				// Test some true and false cases
				assertTrue(list.contains(testStrings[0]));
				assertFalse(list.contains("DOughnut"));
	}
	
	/**
	 * Tests to see if two elements are equal
	 */
	@Test
	public void testEquals() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();
		
		// Make two lists the same and one list different
		for (int i = 0; i < testStrings.length; i++) {
			list1.add(testStrings[i]);
		}
		for (int i = 0; i < testStrings.length; i++) {
			list2.add(testStrings[i]);
		}
		list3.add("Doughnut");
		// Test for equality and non-equality
		assertTrue(list1.equals(list2));
		assertTrue(list2.equals(list1));
		
		assertFalse(list1.equals(list3));
		assertFalse(list3.equals(list1));
	}
	
	/**
	 * Tests to see if the list contains hash code
	 */
	@Test
	public void testHashCode() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();
		
		// Make two lists the same and one list different
		for (int i = 0; i < testStrings.length; i++) {
			list1.add(testStrings[i]);
		}
		for (int i = 0; i < testStrings.length; i++) {
			list2.add(testStrings[i]);
		}
		list3.add("Doughnut");
		// Test for equality and non-equality
		assertTrue(list1.equals(list2));
		assertTrue(list2.equals(list1));
		
		assertFalse(list1.equals(list3));
		assertFalse(list3.equals(list1));
		// Test for the same and different hashCodes
		assertTrue(list1.hashCode() == list2.hashCode());
		assertTrue(list2.hashCode() == list1.hashCode());
		
		assertFalse(list1.hashCode() == list3.hashCode());
		assertFalse(list3.hashCode() == list1.hashCode());
	}

}