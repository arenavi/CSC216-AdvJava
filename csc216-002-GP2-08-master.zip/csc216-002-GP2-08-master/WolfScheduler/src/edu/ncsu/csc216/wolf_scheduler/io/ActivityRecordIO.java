/**
 * 
 */
package edu.ncsu.csc216.wolf_scheduler.io;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

import edu.ncsu.csc216.wolf_scheduler.course.Activity;


/**
 * Handles functionality for all activities.
 * @author Amiya Renavikar
 */
public class ActivityRecordIO {

	/**
	 * Writes the list of Courses to the file.
	 * @param fileName file name
	 * @param activity ArrayList of Activity
	 * @throws IOException to catch exception
	 */
	public static void writeActivityRecords(String fileName, ArrayList<Activity> activity) throws IOException {
	    
		PrintStream write = new PrintStream(new File(fileName));
	    
		for (int i = 0; i < activity.size(); i++) {
			
			write.println(activity.get(i).toString());
		}
		write.close();
	}

}
