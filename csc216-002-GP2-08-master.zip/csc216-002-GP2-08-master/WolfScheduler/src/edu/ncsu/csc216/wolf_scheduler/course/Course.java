 package edu.ncsu.csc216.wolf_scheduler.course;

/**
 * Handles the functionality of a Course in Course Records.
 * @author Amiya Renavikar
 */
public class Course extends Activity {

	/** Course's name. */
	private String name;
	/** Course's section. */
	private String section;
	/** Course's credit hours */
	private int credits;
	/** Course's instructor */
	private String instructorId;
	
	/**
	 * Creates a Course with the given name, title, section, credits,
	 * instructorId, meetingDays, start time and end time for courses that are
	 * arranged.
	 * 
	 * @param name
	 *            Course name
	 * @param title
	 *            Course title
	 * @param section
	 *            Course section
	 * @param credits
	 *            Course credits
	 * @param instructorId
	 *            Course instructor id
	 * @param meetingDays
	 *            Course meeting days
	 * @param startTime
	 *            Course start time
	 * @param endTime
	 *            Course end time
	 */
	public Course(String name, String title, String section, int credits, String instructorId, String meetingDays,
			int startTime, int endTime) {
		super(title, meetingDays, startTime, endTime);
		setName(name);
		setTitle(title);
		setSection(section);
		setCredits(credits);
		setInstructorId(instructorId);
		setMeetingDays(meetingDays);
		setActivityTime(startTime, endTime);
	}

	/**
	 * Creates a Course with the given name, title, section, credits,
	 * instructorId, and meetingDays for courses that are arranged.
	 * 
	 * @param name
	 *            name of Course
	 * @param title
	 *            title of Course
	 * @param section
	 *            section of Course
	 * @param credits
	 *            credit hours for Course
	 * @param instructorId
	 *            instructor's unity id
	 * @param meetingDays
	 *            meeting days for Course as series of chars
	 */
	public Course(String name, String title, String section, int credits, String instructorId, String meetingDays) {
		this(name, title, section, credits, instructorId, meetingDays, 0, 0);
	}

	/**
	 * Returns the Course's name.
	 * 
	 * @return name course name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the Course's name. If the name is null, has a length less than 4 or
	 * greater than 6, an IllegalArgumentException is thrown.
	 * 
	 * @param name
	 *            the name to set
	 * @throws IllegalArgumentException
	 *             if name is null or length is less than 4 or greater than 6
	 */
	private void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException();
		}
		if (name.length() < 4 || name.length() > 6) {
			throw new IllegalArgumentException();
		}
		this.name = name;
	}

	/**
	 * Returns the Course section
	 * 
	 * @return section course section
	 */
	public String getSection() {
		return section;
	}

	/**
	 * Sets the Course's section. If section is null or not exactly 3 digits, an
	 * IllegalArgumentException is thrown.
	 * 
	 * @param section
	 *            course section
	 * @throws IllegalArgumentException
	 *             if section is null or not 3 digits
	 */
	public void setSection(String section) {
		if (section == null) {
			throw new IllegalArgumentException();
		}
		if (section.length() != 3) {
			throw new IllegalArgumentException();
		}
		this.section = section;
	}

	/**
	 * Returns the number of credits
	 * 
	 * @return credits no. of credits
	 */
	public int getCredits() {
		return credits;
	}

	/**
	 * Sets the Course's credits. If credits are not a number or less than 1 or
	 * greater than 5, an IllegalArgumentException is thrown.
	 * 
	 * @param credits
	 *            no. of credits
	 * @throws IllegalArgumentException
	 *             if credits are not a number or less than 1 or greater than 5
	 */
	public void setCredits(int credits) {
		if (credits < 1 || credits > 5) {
			throw new IllegalArgumentException();
		}
		this.credits = credits;
	}

	/**
	 * Returns the Instructor Id
	 * 
	 * @return instructorId id
	 */
	public String getInstructorId() {
		return instructorId;
	}

	/**
	 * Sets the Course's Instructor Id. If instructor id is null or empty, an
	 * IllegalArgumentException is thrown.
	 * 
	 * @param instructorId
	 *            the instructorId
	 * @throws IllegalArgumentException
	 *             if instructor id is null or empty
	 */
	public void setInstructorId(String instructorId) {
		if (instructorId == null || instructorId.equals("")) {
			throw new IllegalArgumentException();
		}
		this.instructorId = instructorId;
	}

	/**
	 * Returns a comma separated value String of all Course fields.
	 * 
	 * @return String representation of Course
	 */
	@Override
	public String toString() {
		if (getMeetingDays().equals("A")) {
			return name + "," + getTitle() + "," + section + "," + credits + "," + instructorId + "," + getMeetingDays();
		}
		return name + "," + getTitle() + "," + section + "," + credits + "," + instructorId + "," + getMeetingDays() + ","
				+ getStartTime() + "," + getEndTime();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + credits;
		result = prime * result + ((instructorId == null) ? 0 : instructorId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (credits != other.credits)
			return false;
		if (instructorId == null) {
			if (other.instructorId != null)
				return false;
		} else if (!instructorId.equals(other.instructorId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} else if (!section.equals(other.section))
			return false;
		return true;
	}

	
	/* (non-Javadoc)
	 * @see edu.ncsu.csc216.wolf_scheduler.course.Activity#setMeetingDays(java.lang.String)
	 */
	@Override
	public void setMeetingDays(String meetingDays) {
		
		if (meetingDays == null || meetingDays.equals("")) {
			
			throw new IllegalArgumentException();
		}
	
		for (int i = 0; i < meetingDays.length(); i++) {
			if (!(meetingDays.charAt(i) == 'M' || meetingDays.charAt(i) == 'T' ||    
				  meetingDays.charAt(i) == 'W' || meetingDays.charAt(i) == 'H' ||
				  meetingDays.charAt(i) == 'F' || meetingDays.charAt(i) == 'A')) {
				
				throw new IllegalArgumentException();
			}
		}
		
		if (meetingDays.contains("A") && meetingDays.length() != 1) {
			
			throw new IllegalArgumentException();
		}
		
		super.setMeetingDays(meetingDays);
	}

	/**
	 * Returns short display array.
	 * @return shortDisplay short display array
	 */
	@Override
	public String[] getShortDisplayArray() {
		
		String[] shortDisplay = new String[4];
		
		shortDisplay[0] = name;
		shortDisplay[1] = section;
		shortDisplay[2] = getTitle();
		shortDisplay[3] = getMeetingString();
		
		return shortDisplay;
	}

	/**
	 * Returns long display array.
	 * @return longDisplay long display array
	 */
	@Override
	public String[] getLongDisplayArray() {
		
		String[] longDisplay = new String[7];
		
		longDisplay[0] = name;
		longDisplay[1] = section;
		longDisplay[2] = getTitle();
		longDisplay[3] = Integer.toString(credits);
		longDisplay[4] = instructorId;
		longDisplay[5] = getMeetingString();
		longDisplay[6] = "";
		
		return longDisplay;
	}

	/**
	 * Returns true if Course is duplicate, false otherwise.
	 * @return true if Course is duplicate, false otherwise
	 */
	@Override
	public boolean isDuplicate(Activity activity) {
		
		try {
			
			Course c = (Course) activity;
			
			if (c.getName().equals(this.getName())) {
				
				return true;
			}
		} catch(ClassCastException e) {
			
			return false;
		}
		return false;
		
	}

}
