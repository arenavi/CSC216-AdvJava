package edu.ncsu.csc216.wolf_scheduler.scheduler;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import edu.ncsu.csc216.wolf_scheduler.course.Activity;
import edu.ncsu.csc216.wolf_scheduler.course.Course;
import edu.ncsu.csc216.wolf_scheduler.course.Event;
import edu.ncsu.csc216.wolf_scheduler.io.ActivityRecordIO;

/**
 * Reads in and stores as a list all of the Course records stored in a file,
 * creates a schedule for the current user and provides functionality.
 * @author Amiya Renavikar
 */
public class WolfScheduler {
	
	/** Courses ArrayList */
	private ArrayList<Course> catalog;
	
	/** Schedule ArrayList */
	private ArrayList<Activity> schedule;
	
	/** Schedule title */
	private String title;
	

	/**
	 * Constructs the WolfScheduler class.
	 * @param validTestFile test file
	 */
	public WolfScheduler(String validTestFile) {
		
		catalog = new ArrayList<Course>();
		schedule = new ArrayList<Activity>();
		title = "My Schedule";
		
		try {
			catalog = edu.ncsu.csc216.wolf_scheduler.io.CourseRecordIO.readCourseRecords(validTestFile);
			
		} catch (FileNotFoundException e) {
			
			System.out.println("Cannot find file");
		}
	}

	/**
	 * Returns a 2D String array of catalog, returns an empty String array
	 * if there are no Courses in the catalog.
	 * @return catalogs 2D String catalog array
	 */
	public String[][] getCourseCatalog() {
		
		String[][] catalogs = new String[catalog.size()][4];
		
		if (catalog.size() == 0) {
			
			return catalogs;
		}
		
		for (int i = 0; i < catalog.size(); i++) {
			
			Course c1 = catalog.get(i);
			
			catalogs[i][0] = c1.getName();
			catalogs[i][1] = c1.getSection();
			catalogs[i][2] = c1.getTitle();
			catalogs[i][3] = c1.getMeetingString();
		}
		
		return catalogs;
	}

	/**
	 * Returns a 2D String array of schedule, returns an empty String array
	 * if there are no Courses in the schedule.
	 * @return courses 2D String schedule array
	 */
	public String[][] getScheduledActivities() {
		
		String[][] courses = new String[schedule.size()][3];
		
		if (schedule.size() == 0) {
			
			return courses;
		}
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Activity a1 = schedule.get(i);
			
			courses[i] = a1.getShortDisplayArray();
			
		}
		
		return courses;
	}

	/**
	 * Returns a 2D String array of the schedule with all information, or returns
	 * an empty String array if there are no Courses in the schedule.
	 * @return courses 2D String array
	 */
	public String[][] getFullScheduledActivities() {
		
        String[][] courses = new String[schedule.size()][6];
        
        if (schedule.size() == 0) {
			
			return courses;
		}
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Activity a2 = schedule.get(i);
			
			courses[i] = a2.getLongDisplayArray();
			
		}
		
		return courses;
	}

	/**
	 * Return the Course title.
	 * @return title Course title
	 */
	public String getTitle() {
		
		return title;
	}

	/**
	 * Receives a String parameter to save the student's schedule.
	 * @param fileName name of file
	 * @throws IllegalArgumentException if file not saved
	 */
	public void exportSchedule(String fileName) {
		
		try {
			
			ActivityRecordIO.writeActivityRecords(fileName, schedule);
			
		} catch (IOException e) {
			
			throw new IllegalArgumentException("The file cannot be saved.");
		}
		
	}

	/**
	 * Returns the Course from the catalog if found. Else returns null.
	 * @param name Course name
	 * @param section Course section
	 * @return Course if found, null otherwise
	 */
	public Course getCourseFromCatalog(String name, String section) {
		
		for (int i = 0; i < catalog.size(); i++) {
			
			Course d = null;
			Course c = catalog.get(i);
			
			if (c.getName().equals(name) && c.getSection().equals(section)) {
				
				d = c;
				
				return d;
			}
		}
		
		return null;
	}

	/**
	 * Returns true if the given Course can be added to the student's schedule, false if Course is not in the catalog.
	 * @param name Course name
	 * @param section Course section
	 * @throws IllegalArgumentException if student is already enrolled in the Course
	 * @return true if Course added, false otherwise
	 */
	public boolean addCourse(String name, String section) {
		
		Course fromCatalog = getCourseFromCatalog(name, section);
		
		if (fromCatalog == null) {
			
			return false;
		}
		/*try {
			for(int i = 0; i < schedule.size(); i++) {
				Activity c3 = schedule.get(i);
				Course c = catalog.get(0);
					if(c3.isDuplicate(c) && ((Course)c3).getName().equalsIgnoreCase(name)) {
						throw new IllegalArgumentException("You are already enrolled in " + ((Course)c3).getName());
					}
			}
		} catch (ClassCastException e) {
			
			throw new ClassCastException();
		}*/
		
		for(int i = 0; i < schedule.size(); i++) {
			Activity a = schedule.get(i);
			if(a.isDuplicate(fromCatalog)) {
				throw new IllegalArgumentException("You are already enrolled in " + fromCatalog.getName());
			}
		}
		
		schedule.add(fromCatalog);
		return true;
	}

	/**
	 * Returns true if the given Course can be removed to the student's schedule, false if Course not in schedule.
	 * @param idx TODO
	 * @return true if Course added, false otherwise
	 */
	public boolean removeActivity(int idx) {
		
		if (schedule == null) {
			
			return false;
		}
		
		if (idx < schedule.size()) {
			
			schedule.remove(idx);
			
			return true;
		}
		
		return false;
	}

	/**
	 * Creates an empty ArrayList.
	 */
	public void resetSchedule() {
		
		schedule = new ArrayList<Activity>();		
	}

	/**
	 * Sets the title.
	 * @param title Course title
	 * @throws IllegalArgumentException if the title is null
	 */
	public void setTitle(String title) {
		
		if (title == null) {
			
			throw new IllegalArgumentException("Title cannot be null");
		}
		
		this.title = title;
	}

	/**
	 * Adds an Event to the list.
	 * @param title Event title
	 * @param meetingDays Event meeting days
	 * @param startTime Event start time
	 * @param endTime Event end time
	 * @param weeklyRepeat Event weekly repeat
	 * @param eventDetails EVent details
	 * @return true if event is added to list
	 */
	public boolean addEvent(String title, String meetingDays, int startTime, int endTime,
			int weeklyRepeat, String eventDetails) {
		
		Activity a1 = new Event(title, meetingDays, startTime, endTime, weeklyRepeat, eventDetails);
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Activity a2 = schedule.get(i);
			
			if ((a2.isDuplicate(a1)) && (a2.getTitle().equals(a1.getTitle()))) {
				
				throw new IllegalArgumentException("You have already created an event called " + a1.getTitle());
			}
		}
		
		schedule.add(a1);
		
		return true;
	}
	


}
