package edu.ncsu.csc216.pack_scheduler.course.validator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Tests InvalidTransitionException
 * @author Andrew Hensley and Luke Hansen
 */
public class InvalidTransitionExceptionTest {
	/**
	 * Test method for Exception with custom message
	 */
	@Test
	public void testInvalidTransitionExceptionString() {
		InvalidTransitionException ce = new InvalidTransitionException("Custom exception message");
	    assertEquals("Custom exception message", ce.getMessage());
	}

	/**
	 * Test method for Exception with default message
	 */
	@Test
	public void testConflictException() {
		InvalidTransitionException ce = new InvalidTransitionException();
	    assertEquals("Invalid FSM Transition.", ce.getMessage());
	}
}
