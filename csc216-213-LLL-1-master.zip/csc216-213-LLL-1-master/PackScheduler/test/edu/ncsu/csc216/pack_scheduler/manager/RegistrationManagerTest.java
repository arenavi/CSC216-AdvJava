package edu.ncsu.csc216.pack_scheduler.manager;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.catalog.CourseCatalog;
import edu.ncsu.csc216.pack_scheduler.directory.FacultyDirectory;
import edu.ncsu.csc216.pack_scheduler.directory.StudentDirectory;
import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.user.schedule.Schedule;

/**
 * Tests RegistrationManager class
 * 
 * @author Andrew Hensley, Luke Hansen, Joshua Cowles
 */
public class RegistrationManagerTest {

    private RegistrationManager manager;

    /**
     * Sets up the CourseManager and clears the data.
     * 
     * @throws Exception
     *             if error
     */
    @Before
    public void setUp() throws Exception {
	manager = RegistrationManager.getInstance();
	manager.clearData();
	manager.logout();
    }

    /**
     * Tests getCourseCatalog
     */
    @Test
    public void testGetCourseCatalog() {
	assertEquals(manager.getCourseCatalog().getCourseCatalog().length, 0);
	manager.getCourseCatalog().loadCoursesFromFile("test-files/course_records.txt");
	assertEquals(manager.getCourseCatalog().getCourseCatalog().length, 8);
    }

    /**
     * Tests getStudentDirectory
     */
    @Test
    public void testGetStudentDirectory() {
	assertEquals(manager.getStudentDirectory().getStudentDirectory().length, 0);
	manager.getStudentDirectory().loadStudentsFromFile("test-files/student_records.txt");
	assertEquals(manager.getStudentDirectory().getStudentDirectory().length, 10);
    }

    /**
     * Tests getFacultyDirectory
     */
    @Test
    public void testGetFacultyDirectoryy() {
	manager.clearData();
	assertEquals(manager.getFacultyDirectory().getFacultyDirectory().length, 0);
	manager.getFacultyDirectory().loadFacultyFromFile("test-files/faculty_records.txt");
	assertEquals(manager.getFacultyDirectory().getFacultyDirectory().length, 8);
    }

    /**
     * Tests login for Student
     */
    @Test
    public void testLoginStudent() {
	manager.getStudentDirectory().loadStudentsFromFile("test-files/student_records.txt");
	String id = "zking";
	String password = "pw";
	assertEquals(true, manager.login(id, password));
    }

    /**
     * Tests login for faculty
     */
    @Test
    public void testLoginFaculty() {
	manager.getFacultyDirectory().loadFacultyFromFile("test-files/faculty_records.txt");
	String id = "awitt";
	String password = "pw";
	try {
	    manager.login("registrar", "Regi5tr@r");
	    assertFalse(manager.login(null, password));
	    fail();
	} catch (IllegalArgumentException e) {
	    assertEquals(manager.getCurrentUser().getId(), "registrar");
	}
	try {
	    assertTrue(manager.login(id, password));
	} catch (IllegalArgumentException e) {
	    fail();
	}

    }

    /**
     * Tests logout
     */
    @Test
    public void testLogout() {
	manager.getStudentDirectory().loadStudentsFromFile("test-files/student_records.txt");
	String id = "zking";
	String password = "pw";
	assertEquals(true, manager.login(id, password));
	assertEquals(manager.getCurrentUser().getFirstName(), "Zahir");
	manager.logout();
	assertEquals(manager.getCurrentUser(), null);
    }

    /**
     * Tests wrong ID, registrar password, and correct
     */
    @Test
    public void testBadLogin() {
	manager.getStudentDirectory().loadStudentsFromFile("test-files/student_records.txt");
	String id = "larryboy";
	String password = "pw";
	try {
	    manager.login(id, password);
	    fail();
	} catch (IllegalArgumentException e) {
	    // Should cause exception
	}
	assertEquals(manager.getCurrentUser(), null);
	id = "registrar";
	password = "badpw";
	manager = RegistrationManager.getInstance();
	assertEquals(manager.login(id, password), false);
	password = "Regi5tr@r";
	assertEquals(manager.login(id, password), true);
	manager.logout();

    }

    /**
     * Tests getCurrentUser
     */
    @Test
    public void testGetCurrentUser() {
	manager.getStudentDirectory().loadStudentsFromFile("test-files/student_records.txt");
	String id = "zking";
	String password = "pw";
	assertEquals(true, manager.login(id, password));
	assertEquals(manager.getCurrentUser().getFirstName(), "Zahir");
	manager.clearData();
    }

    /**
     * Tests RegistrationManager.enrollStudentInCourse()
     */
    @Test
    public void testEnrollStudentInCourse() {
	StudentDirectory directory = manager.getStudentDirectory();
	directory.loadStudentsFromFile("test-files/student_records.txt");

	CourseCatalog catalog = manager.getCourseCatalog();
	catalog.loadCoursesFromFile("test-files/course_records.txt");

	manager.logout(); // In case not handled elsewhere

	// test if not logged in
	try {
	    manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001"));
	    fail("RegistrationManager.enrollStudentInCourse() - If the current user is null, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertNull("RegistrationManager.enrollStudentInCourse() - currentUser is null, so cannot enroll in course.",
		    manager.getCurrentUser());
	}

	// test if registrar is logged in
	manager.login("registrar", "Regi5tr@r");
	try {
	    manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001"));
	    fail("RegistrationManager.enrollStudentInCourse() - If the current user is registrar, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertEquals(
		    "RegistrationManager.enrollStudentInCourse() - currentUser is registrar, so cannot enroll in course.",
		    "registrar", manager.getCurrentUser().getId());
	}
	manager.logout();

	manager.login("efrost", "pw");
	assertFalse(
		"Action: enroll\nUser: efrost\nCourse: CSC216-001\nResults: False - Student max credits are 3 and course has 4.",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: enroll\nUser: efrost\nCourse: CSC226-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: efrost\nCourse: CSC226-001, CSC230-001\nResults: False - cannot exceed max student credits.",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC230", "001")));

	// Check Student Schedule
	Student efrost = directory.getStudentById("efrost");
	Schedule scheduleFrost = efrost.getSchedule();
	assertEquals(3, scheduleFrost.getScheduleCredits());
	String[][] scheduleFrostArray = scheduleFrost.getScheduledCourses();
	assertEquals(1, scheduleFrostArray.length);
	assertEquals("CSC226", scheduleFrostArray[0][0]);
	assertEquals("001", scheduleFrostArray[0][1]);
	assertEquals("Discrete Mathematics for Computer Scientists", scheduleFrostArray[0][2]);
	assertEquals("MWF 9:35AM-10:25AM", scheduleFrostArray[0][3]);
	assertEquals("9", scheduleFrostArray[0][4]);

	manager.logout();

	manager.login("ahicks", "pw");
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC226-001\nResults: False - duplicate",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-001\nResults: False - time conflict",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC116", "001")));
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC116", "003")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003, CSC116-002\nResults: False - already in section of 116",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "601")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003, CSC230-001\nResults: False - exceeded max credits",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC230", "001")));

	// Check Student Schedule
	Student ahicks = directory.getStudentById("ahicks");
	Schedule scheduleHicks = ahicks.getSchedule();
	assertEquals(10, scheduleHicks.getScheduleCredits());
	String[][] scheduleHicksArray = scheduleHicks.getScheduledCourses();
	assertEquals(3, scheduleHicksArray.length);
	assertEquals("CSC216", scheduleHicksArray[0][0]);
	assertEquals("001", scheduleHicksArray[0][1]);
	assertEquals("Programming Concepts - Java", scheduleHicksArray[0][2]);
	assertEquals("TH 1:30PM-2:45PM", scheduleHicksArray[0][3]);
	assertEquals("9", scheduleHicksArray[0][4]);
	assertEquals("CSC226", scheduleHicksArray[1][0]);
	assertEquals("001", scheduleHicksArray[1][1]);
	assertEquals("Discrete Mathematics for Computer Scientists", scheduleHicksArray[1][2]);
	assertEquals("MWF 9:35AM-10:25AM", scheduleHicksArray[1][3]);
	assertEquals("8", scheduleHicksArray[1][4]);
	assertEquals("CSC116", scheduleHicksArray[2][0]);
	assertEquals("003", scheduleHicksArray[2][1]);
	assertEquals("Intro to Programming - Java", scheduleHicksArray[2][2]);
	assertEquals("TH 11:20AM-1:10PM", scheduleHicksArray[2][3]);
	assertEquals("9", scheduleHicksArray[2][4]);

	manager.logout();
    }

    /**
     * Tests RegistrationManager.dropStudentFromCourse()
     */
    @Test
    public void testDropStudentFromCourse() {
	StudentDirectory directory = manager.getStudentDirectory();
	directory.loadStudentsFromFile("test-files/student_records.txt");

	CourseCatalog catalog = manager.getCourseCatalog();
	catalog.loadCoursesFromFile("test-files/course_records.txt");

	manager.logout(); // In case not handled elsewhere

	// test if not logged in
	try {
	    manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC216", "001"));
	    fail("RegistrationManager.dropStudentFromCourse() - If the current user is null, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertNull("RegistrationManager.dropStudentFromCourse() - currentUser is null, so cannot enroll in course.",
		    manager.getCurrentUser());
	}

	// test if registrar is logged in
	manager.login("registrar", "Regi5tr@r");
	try {
	    manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC216", "001"));
	    fail("RegistrationManager.dropStudentFromCourse() - If the current user is registrar, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertEquals(
		    "RegistrationManager.dropStudentFromCourse() - currentUser is registrar, so cannot enroll in course.",
		    "registrar", manager.getCurrentUser().getId());
	}
	manager.logout();

	manager.login("efrost", "pw");
	assertFalse(
		"Action: enroll\nUser: efrost\nCourse: CSC216-001\nResults: False - Student max credits are 3 and course has 4.",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: enroll\nUser: efrost\nCourse: CSC226-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: efrost\nCourse: CSC226-001, CSC230-001\nResults: False - cannot exceed max student credits.",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC230", "001")));

	assertFalse(
		"Action: drop\nUser: efrost\nCourse: CSC216-001\nResults: False - student not enrolled in the course",
		manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: drop\nUser: efrost\nCourse: CSC226-001\nResults: True",
		manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC226", "001")));

	// Check Student Schedule
	Student efrost = directory.getStudentById("efrost");
	Schedule scheduleFrost = efrost.getSchedule();
	assertEquals(0, scheduleFrost.getScheduleCredits());
	String[][] scheduleFrostArray = scheduleFrost.getScheduledCourses();
	assertEquals(0, scheduleFrostArray.length);

	manager.logout();

	manager.login("ahicks", "pw");
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC226-001\nResults: False - duplicate",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-001\nResults: False - time conflict",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC116", "001")));
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC116", "003")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003, CSC116-002\nResults: False - already in section of 116",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "601")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003, CSC230-001\nResults: False - exceeded max credits",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC230", "001")));

	Student ahicks = directory.getStudentById("ahicks");
	Schedule scheduleHicks = ahicks.getSchedule();
	assertEquals(10, scheduleHicks.getScheduleCredits());
	String[][] scheduleHicksArray = scheduleHicks.getScheduledCourses();
	assertEquals(3, scheduleHicksArray.length);
	assertEquals("CSC216", scheduleHicksArray[0][0]);
	assertEquals("001", scheduleHicksArray[0][1]);
	assertEquals("Programming Concepts - Java", scheduleHicksArray[0][2]);
	assertEquals("TH 1:30PM-2:45PM", scheduleHicksArray[0][3]);
	assertEquals("9", scheduleHicksArray[0][4]);
	assertEquals("CSC226", scheduleHicksArray[1][0]);
	assertEquals("001", scheduleHicksArray[1][1]);
	assertEquals("Discrete Mathematics for Computer Scientists", scheduleHicksArray[1][2]);
	assertEquals("MWF 9:35AM-10:25AM", scheduleHicksArray[1][3]);
	assertEquals("9", scheduleHicksArray[1][4]);
	assertEquals("CSC116", scheduleHicksArray[2][0]);
	assertEquals("003", scheduleHicksArray[2][1]);
	assertEquals("Intro to Programming - Java", scheduleHicksArray[2][2]);
	assertEquals("TH 11:20AM-1:10PM", scheduleHicksArray[2][3]);
	assertEquals("9", scheduleHicksArray[2][4]);

	assertTrue("Action: drop\nUser: efrost\nCourse: CSC226-001\nResults: True",
		manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC226", "001")));

	// Check schedule
	ahicks = directory.getStudentById("ahicks");
	scheduleHicks = ahicks.getSchedule();
	assertEquals(7, scheduleHicks.getScheduleCredits());
	scheduleHicksArray = scheduleHicks.getScheduledCourses();
	assertEquals(2, scheduleHicksArray.length);
	assertEquals("CSC216", scheduleHicksArray[0][0]);
	assertEquals("001", scheduleHicksArray[0][1]);
	assertEquals("Programming Concepts - Java", scheduleHicksArray[0][2]);
	assertEquals("TH 1:30PM-2:45PM", scheduleHicksArray[0][3]);
	assertEquals("9", scheduleHicksArray[0][4]);
	assertEquals("CSC116", scheduleHicksArray[1][0]);
	assertEquals("003", scheduleHicksArray[1][1]);
	assertEquals("Intro to Programming - Java", scheduleHicksArray[1][2]);
	assertEquals("TH 11:20AM-1:10PM", scheduleHicksArray[1][3]);
	assertEquals("9", scheduleHicksArray[1][4]);

	assertFalse("Action: drop\nUser: efrost\nCourse: CSC226-001\nResults: False - already dropped",
		manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC226", "001")));

	assertTrue("Action: drop\nUser: efrost\nCourse: CSC216-001\nResults: True",
		manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC216", "001")));

	// Check schedule
	ahicks = directory.getStudentById("ahicks");
	scheduleHicks = ahicks.getSchedule();
	assertEquals(3, scheduleHicks.getScheduleCredits());
	scheduleHicksArray = scheduleHicks.getScheduledCourses();
	assertEquals(1, scheduleHicksArray.length);
	assertEquals("CSC116", scheduleHicksArray[0][0]);
	assertEquals("003", scheduleHicksArray[0][1]);
	assertEquals("Intro to Programming - Java", scheduleHicksArray[0][2]);
	assertEquals("TH 11:20AM-1:10PM", scheduleHicksArray[0][3]);
	assertEquals("9", scheduleHicksArray[0][4]);

	assertTrue("Action: drop\nUser: efrost\nCourse: CSC116-003\nResults: True",
		manager.dropStudentFromCourse(catalog.getCourseFromCatalog("CSC116", "003")));

	// Check schedule
	ahicks = directory.getStudentById("ahicks");
	scheduleHicks = ahicks.getSchedule();
	assertEquals(0, scheduleHicks.getScheduleCredits());
	scheduleHicksArray = scheduleHicks.getScheduledCourses();
	assertEquals(0, scheduleHicksArray.length);

	manager.logout();
    }

    /**
     * Tests RegistrationManager.resetSchedule()
     */
    @Test
    public void testResetSchedule() {
	StudentDirectory directory = manager.getStudentDirectory();
	directory.loadStudentsFromFile("test-files/student_records.txt");

	CourseCatalog catalog = manager.getCourseCatalog();
	catalog.loadCoursesFromFile("test-files/course_records.txt");

	manager.logout(); // In case not handled elsewhere

	// Test if not logged in
	try {
	    manager.resetSchedule();
	    fail("RegistrationManager.resetSchedule() - If the current user is null, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertNull("RegistrationManager.resetSchedule() - currentUser is null, so cannot enroll in course.",
		    manager.getCurrentUser());
	}

	// test if registrar is logged in
	manager.login("registrar", "Regi5tr@r");
	try {
	    manager.resetSchedule();
	    fail("RegistrationManager.resetSchedule() - If the current user is registrar, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertEquals("RegistrationManager.resetSchedule() - currentUser is registrar, so cannot enroll in course.",
		    "registrar", manager.getCurrentUser().getId());
	}
	manager.logout();

	manager.login("efrost", "pw");
	assertFalse(
		"Action: enroll\nUser: efrost\nCourse: CSC216-001\nResults: False - Student max credits are 3 and course has 4.",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: enroll\nUser: efrost\nCourse: CSC226-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: efrost\nCourse: CSC226-001, CSC230-001\nResults: False - cannot exceed max student credits.",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC230", "001")));

	manager.resetSchedule();
	// Check Student Schedule
	Student efrost = directory.getStudentById("efrost");
	Schedule scheduleFrost = efrost.getSchedule();
	assertEquals(0, scheduleFrost.getScheduleCredits());
	String[][] scheduleFrostArray = scheduleFrost.getScheduledCourses();
	assertEquals(0, scheduleFrostArray.length);

	manager.logout();

	manager.login("ahicks", "pw");
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "001")));
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC226-001\nResults: False - duplicate",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC226", "001")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-001\nResults: False - time conflict",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC116", "001")));
	assertTrue("Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003\nResults: True",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC116", "003")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003, CSC116-002\nResults: False - already in section of 116",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC216", "601")));
	assertFalse(
		"Action: enroll\nUser: ahicks\nCourse: CSC216-001, CSC226-001, CSC116-003, CSC230-001\nResults: False - exceeded max credits",
		manager.enrollStudentInCourse(catalog.getCourseFromCatalog("CSC230", "001")));

	manager.resetSchedule();
	// Check Student schedule
	Student ahicks = directory.getStudentById("ahicks");
	Schedule scheduleHicks = ahicks.getSchedule();
	assertEquals(0, scheduleHicks.getScheduleCredits());
	String[][] scheduleHicksArray = scheduleHicks.getScheduledCourses();
	assertEquals(0, scheduleHicksArray.length);

	manager.logout();
    }

    /**
     * Tests new Faculty functionality
     */
    @Test
    public void testFacultySchedule() {
	// Loading Directories
	CourseCatalog catalog = manager.getCourseCatalog();
	catalog.loadCoursesFromFile("test-files/course_records.txt");
	FacultyDirectory directory = manager.getFacultyDirectory();
	directory.loadFacultyFromFile("test-files/faculty_records.txt");

	// Attempt to add with no login
	try {
	    manager.addFacultyToCourse(catalog.getCourseFromCatalog("CSC216", "001"),
		    directory.getFacultyById("awitt"));
	    fail("RegistrationManager.addFacultyToCourse() - If the current user is null, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertNull(
		    "RegistrationManager.addFacultyToCourse() - currentUser is null, so cannot add Faculty member to course.",
		    manager.getCurrentUser());
	}

	// Attempt to add with registrar login
	manager.login("registrar", "Regi5tr@r");
	try {
	    manager.addFacultyToCourse(catalog.getCourseFromCatalog("CSC216", "001"),
		    directory.getFacultyById("awitt"));
	} catch (IllegalArgumentException e) {
	    assertEquals(
		    "RegistrationManager.addFacultyToCourse() - currentUser is registrar, so cannot add faculty to course.",
		    "registrar", manager.getCurrentUser().getId());
	}

	// Logout
	manager.logout();

	// Attempt to remove with no login
	try {
	    manager.removeFacultyFromCourse(manager.getCourseCatalog().getCourseFromCatalog("CSC116", "001"),
		    manager.getFacultyDirectory().getFacultyById("awitt"));
	    fail("RegistrationManager.removeFacultyFromCourse() - If the current user is null, an IllegalArgumentException should be thrown, but was not.");
	} catch (IllegalArgumentException e) {
	    assertNull(
		    "RegistrationManager.removeFacultyFromCourse() - current user is null, so cannot remove Faculty member from course.",
		    manager.getCurrentUser());
	}

	// Attempt to remove with registrar login
	manager.login("registrar", "Regi5tr@r");
	try {
	    manager.removeFacultyFromCourse(catalog.getCourseFromCatalog("CSC116", "001"),
		    directory.getFacultyById("awitt"));
	} catch (IllegalArgumentException e) {
	    assertEquals(
		    "RegistrationManager.removeFacultyFromCourse() - currentUser is registrar, so cannot remove faculty from course.",
		    "registrar", manager.getCurrentUser().getId());
	}
	
	manager.login("awitt", "pw");
	try {
	    manager.removeFacultyFromCourse(catalog.getCourseFromCatalog("CSC116", "001"),
		    directory.getFacultyById("awitt"));
	    assertEquals(manager.getFacultyDirectory().getFacultyById("awitt").getSchedule().getNumScheduledCourses(), 0);
	} catch (IllegalArgumentException e) {
	   //pass
	}

	// Logout
	manager.logout();

	// Re-add
	manager.login("awitt", "pw");
	// Testing reset schedule
    }
}
