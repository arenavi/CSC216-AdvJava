/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Tests Faculty
 * @author Andrew, Amiya, and Joshua
 */
public class FacultyTest {

	private static final String FIRST_NAME = "first";
	private static final String LAST_NAME = "last";
	private static final String ID = "id";
	private static final String EMAIL = "email@ncsu.edu";
	private static final String HASH_PW = "hashedpassword";
	private static final int MAX_COURSES = 3;
	/**
	 * Tests construction of Faculty Object with valid and invalid cases
	 */
	@Test
	public void testFacultyStringStringStringStringStringInt() {
		// test first name is null
		Faculty s = null;
		try {
			s = new Faculty(null, LAST_NAME, ID, EMAIL, HASH_PW, 1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test last name is null
		s = null;
		try {
			s = new Faculty(FIRST_NAME, null, ID, EMAIL, HASH_PW, 1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test id is null
		s = null;
		try {
			s = new Faculty(FIRST_NAME, LAST_NAME, null, EMAIL, HASH_PW, 1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test id is empty
		s = null;
		try {
			s = new Faculty(FIRST_NAME, LAST_NAME, "", EMAIL, HASH_PW, 1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test email is null
		s = null;
		try {
			s = new Faculty(FIRST_NAME, LAST_NAME, ID, null, HASH_PW, 1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test password is null
		s = null;
		try {
			s = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, null, 1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test invalid credits
		s = null;
		try {
			s = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, 0);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test valid construction
		s = null;
		try {
			s = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, 1);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(1, s.getMaxCourses());
		} catch (IllegalArgumentException e) {
			fail();
		}

	}

	/**
	 * Tests setMaxCourses in Student
	 */
	@Test
	public void testSetMaxCourses() {
		Faculty s = null;
		s = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_COURSES, s.getMaxCourses());

		// test invalid credits
		try {
			s.setMaxCourses(4);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_COURSES, s.getMaxCourses());
		}

		// test invalid credits
		try {
			s.setMaxCourses(0);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_COURSES, s.getMaxCourses());
		}

		// test valid credits
		s.setMaxCourses(2);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(2, s.getMaxCourses());
	}

	/**
	 * Tests equals method in Faculty
	 */
	@Test
	public void testEqualsObject() {
		User s1 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		User s2 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		User s3 = new Faculty("student", LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		User s4 = new Faculty(FIRST_NAME, "student", ID, EMAIL, HASH_PW, MAX_COURSES);
		User s5 = new Faculty(FIRST_NAME, LAST_NAME, "hdauidh", EMAIL, HASH_PW, MAX_COURSES);
		User s6 = new Faculty(FIRST_NAME, LAST_NAME, ID, "aaaaa@ncsu.edu", HASH_PW, MAX_COURSES);
		User s7 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, "dawhduia", MAX_COURSES);
		User s8 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, 1);
		User s9 = null;

		// Test for equality in both directions
		assertTrue(s1.equals(s2));
		assertTrue(s2.equals(s1));

		// Test for each of the fields
		assertFalse(s1.equals(s3));
		assertFalse(s1.equals(s4));
		assertFalse(s1.equals(s5));
		assertFalse(s1.equals(s6));
		assertFalse(s1.equals(s7));
		assertFalse(s1.equals(s8));
		assertFalse(s1.equals(s9));
	}

	/**
	 * Tests hashCode in Faculty
	 */
	@Test
	public void testHashCode() {
		User s1 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		User s2 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		User s3 = new Faculty("student", LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		User s4 = new Faculty(FIRST_NAME, "student", ID, EMAIL, HASH_PW, MAX_COURSES);
		User s5 = new Faculty(FIRST_NAME, LAST_NAME, "hdauidh", EMAIL, HASH_PW, MAX_COURSES);
		User s6 = new Faculty(FIRST_NAME, LAST_NAME, ID, "aaaaa@ncsu.edu", HASH_PW, MAX_COURSES);
		User s7 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, "dawhduia", MAX_COURSES);
		User s8 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, 1);

		// Test for the same hash code for the same values
		assertEquals(s1.hashCode(), s2.hashCode());
		assertEquals(s2.hashCode(), s1.hashCode());

		// Test for each of the fields
		assertNotEquals(s1.hashCode(), s3.hashCode());
		assertNotEquals(s1.hashCode(), s4.hashCode());
		assertNotEquals(s1.hashCode(), s5.hashCode());
		assertNotEquals(s1.hashCode(), s6.hashCode());
		assertNotEquals(s1.hashCode(), s7.hashCode());
		assertNotEquals(s1.hashCode(), s8.hashCode());
	}

	/**
	 * Tests toString in Faculty
	 */
	@Test
	public void testToString() {
		User s1 = new Faculty(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_COURSES);
		String str1 = "first,last,id,email@ncsu.edu,hashedpassword,3";
		assertEquals(str1, s1.toString());
	}

}
