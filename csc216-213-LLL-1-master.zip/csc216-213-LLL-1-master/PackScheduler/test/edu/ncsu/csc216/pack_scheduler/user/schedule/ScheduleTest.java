package edu.ncsu.csc216.pack_scheduler.user.schedule;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;

/**
 * Tests Schedule
 * @author Andrew Hensley and Luke Hansen
 *
 */
public class ScheduleTest {
	/** Instance of Schedule to be tested */
	private Schedule schedule;
	/** Test course for add and remove */
	private final Course course1 = new Course("CSC100", "Intro to Garbage", "999", 5, "lmhansen", 10, "M", 0, 15);
	
	/**
	 * Resets schedule for each test
	 */
	@Before
	public void setup() {
		schedule = new Schedule();
	}
	
	/**
	 * Tests getTitle
	 */
	@Test
	public void getTitleTest() {
		assertEquals(schedule.getTitle(), "My Schedule");
	}
	
	/**
	 * tests seTitle
	 */
	@Test
	public void setTitleTest() {
		schedule.setTitle("Your Schedule");
		assertEquals(schedule.getTitle(), "Your Schedule");
	}
	
	/**
	 * Tests addCourseToSchedule
	 */
	@Test
	public void addCourseToScheduleTest() {
		
		assertTrue(schedule.addCourseToSchedule(course1));
		try {
			assertFalse(schedule.addCourseToSchedule(new Course("CSC100", "Intro to Food", "998", 4, "lhhansen", 10, "M", 30, 45)));
		} catch (IllegalArgumentException e) {
			assertEquals(e.getMessage(), "You are already enrolled in CSC100");
		}
		assertEquals(schedule.getScheduledCourses()[0][0], "CSC100");
		assertEquals(schedule.getScheduledCourses()[0][1], "999");
		assertEquals(schedule.getScheduledCourses()[0][2], "Intro to Garbage");
		assertEquals(schedule.getScheduledCourses()[0][3], "M 12:00AM-12:15AM");
	}
	
	/**
	 * Tests removeCourseFromSchedule
	 */
	@Test
	public void removeCourseFromScheduleTest() {
		assertFalse(schedule.removeCourseFromSchedule(course1));
		assertTrue(schedule.addCourseToSchedule(course1));
		assertTrue(schedule.removeCourseFromSchedule(course1));
		schedule.resetSchedule();
	}
	
	/**
	 * Tests whether course can be added to schedule
	 */
	@Test
	public void canAddTest() {
		assertTrue(schedule.canAdd(course1));
		schedule.addCourseToSchedule(course1);
		assertFalse(schedule.canAdd(new Course("CSC100", "Intro to Food", "998", 4, "lhhansen", 10, "M", 30, 45)));
		assertFalse(schedule.canAdd(null));
		assertFalse(schedule.canAdd(new Course("CSC541", "Into to computer Magic", "990", 3, "cjhansen", 10, "M", 0, 100)));
	}

}
