/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests LinkedAbstractList
 * @author Andrew Hensley and Luke Hansen
 */
public class LinkedAbstractListTest {
	/** Capacity of list */
	private static final int CAPACITY = 5;
	/** Zero capacity of list */
	private static final int ZERO_CAPACITY = 0;
	
	
	/**
	 * Tests compiler
	 */
	@Test
	public void linkedAbstractListTest() {
		
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(CAPACITY);
		try {
			list = new LinkedAbstractList<String>(ZERO_CAPACITY);
		} catch (IllegalArgumentException e) {
			assertEquals(0, list.size());
		}
	}
	
	/**
	 * Tests add
	 */
	@Test
	public void addTest() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(CAPACITY);
		assertEquals(0, list.size());
		String s = "Blah";
		try {
			list.add(-1, s);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(0, list.size());
		}
		try {
			list.add(0, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals(0, list.size());
		}
		list.add(0, s);
		assertEquals(1, list.size());
		try{
			list.add(1, s);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(1, list.size());
		}
		try {
			list.add(s);
			fail();
		}
		catch (IllegalArgumentException e) {
			//pass
		}
	}
	
	/**
	 * Tests remove
	 */
	@Test
	public void removeTest() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(CAPACITY);
		assertEquals(0, list.size());
		String s = "Blah";
		String t = "Blahblah";
		list.add(0, s);
		assertEquals(1, list.size());
		list.add(1, t);
		assertEquals(2, list.size());
		try {
			list.remove(-1);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(2, list.size());
		}
		assertEquals(t, list.remove(1));
		assertEquals(list.remove(0), s);
	}

	/**
	 * Tests set
	 */
	@Test
	public void setTest() {
		LinkedAbstractList<String> list = new LinkedAbstractList<String>(CAPACITY);
		assertEquals(0, list.size());
		String s = "Blah";
		String t = "Blahblah";
		String r = "stuff";
		try {
			list.set(0, null);
			fail();
		}
		catch (NullPointerException e) {
			assertEquals(0, list.size());
		}
		try {
			list.set(-1, s);
			fail();
		}
		catch (IndexOutOfBoundsException e) {
			assertEquals(0, list.size());
		}
		list.add(0, t);
		assertEquals(1, list.size());
		assertEquals(t, list.get(0));
		try {
			list.set(0, t);
			fail();
		}
		catch (IllegalArgumentException e) {
			assertEquals(1, list.size());
			assertEquals(t, list.get(0));
		}
		list.set(0, s);
		assertEquals(1, list.size());
		assertEquals(s, list.get(0));
		list.add(0, r);
		assertEquals(2, list.size());
		assertEquals(r, list.get(0));
		assertEquals(s, list.get(1));
		list.set(1, t);
		assertEquals(2, list.size());
		assertEquals(r, list.get(0));
		assertEquals(t, list.get(1));
	}
}
