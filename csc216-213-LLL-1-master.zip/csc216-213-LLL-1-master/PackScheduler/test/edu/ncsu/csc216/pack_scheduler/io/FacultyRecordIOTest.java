/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.io;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.user.Faculty;
import edu.ncsu.csc216.pack_scheduler.util.LinkedList;

/**
 * Tests FacultyRecordIO
 * @author Andrew, Amiya, and Joshua
 */
public class FacultyRecordIOTest {
	
	private String validFaculty1 = "Ashely,Witt,awitt,mollis@Fuscealiquetmagna.net,pw,2";
	private String validFaculty2 = "Fiona,Meadows,fmeadow,pharetra.sed@et.org,pw,3";
	private String validFaculty3 = "Brent,Brewer,bbrewer,sem.semper@orcisem.co.uk,pw,1";
	private String validFaculty4 = "Halla,Aguirre,haguirr,Fusce.dolor.quam@amalesuadaid.net,pw,3";
	private String validFaculty5 = "Kevyn,Patel,kpatel,risus@pellentesque.ca,pw,1";
	private String validFaculty6 = "Elton,Briggs,ebriggs,arcu.ac@ipsumsodalespurus.edu,pw,3";
	private String validFaculty7 = "Norman,Brady,nbrady,pede.nonummy@elitfermentum.co.uk,pw,1";
	private String validFaculty8 = "Lacey,Walls,lwalls,nascetur.ridiculus.mus@fermentum.net,pw,2";

	/** Valid Faculty records */
	private final String validTestFile = "test-files/faculty_records.txt";
	/** Invalid Faculty records */
	private final String invalidTestFile = "test-files/invalid_faculty_records.txt";
	/** Hashed password */
	private String hashPW;
	/** Hash Algorithm */
	private static final String HASH_ALGORITHM = "SHA-256";
	
	private final String[] validFaculty = { validFaculty1, validFaculty2, validFaculty3, validFaculty4, validFaculty5,
			validFaculty6, validFaculty7, validFaculty8};

	/**
	 * Converts pw into hashed password
	 * @throws Exception if error occurs
	 */
	@Before
	public void setUp() throws Exception {
		try {
			String password = "pw";
			MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
			digest.update(password.getBytes());
			hashPW = new String(digest.digest());

			for (int i = 0; i < validFaculty.length; i++) {
				validFaculty[i] = validFaculty[i].replace(",pw,", "," + hashPW + ",");
			}
		} catch (NoSuchAlgorithmException e) {
			fail("Unable to create hash during setup");
		}
	}

	/**
	 * Tests readStudentRecords in FacultyRecordIO
	 */
	@Test
	public void testReadFacultyRecords() {
		// Tests valid cases with one duplicate
		try {
			LinkedList<Faculty> faculty = FacultyRecordIO.readFacultyRecords(validTestFile);
			assertEquals(8, faculty.size());

			for (int i = 0; i < validFaculty.length; i++) {
				assertEquals(validFaculty[i], faculty.get(i).toString());
			}
		} catch (FileNotFoundException e) {
			fail("Unexpected error reading " + validTestFile);
		}

		// Tests invalid cases
		try {
			LinkedList<Faculty> studentsb = FacultyRecordIO.readFacultyRecords(invalidTestFile);
			assertEquals(0, studentsb.size());
		} catch (FileNotFoundException e) {
			fail("Unexpected FileNotFoundException");
		}
		

	}

	/**
	 * Tests writeStudentRecords in FacultyRecordIO
	 */
	@Test
	public void testWriteFacultyRecords() {
		LinkedList<Faculty> students = new LinkedList<Faculty>();
		students.add(new Faculty("Andrew", "Hensley", "ahensle2", "ahensle2@ncsu.edu", "pw", 3));
		students.add(new Faculty("Shiyi", "Ding", "sding5", "sding5@ncsu.edu", "pw", 3));
		students.add(new Faculty("Liam", "Hall", "lbhall2", "lbhall2@ncsu.edu", "pw", 3));

		try {
			FacultyRecordIO.writeFacultyRecords("test-files/actual_faculty_records.txt", students);
			checkFiles("test-files/actual_faculty_records.txt", "test-files/new_expected_faculty_records.txt");
		} catch (IOException e) {
			fail();
		}
	}

	/**
	 * Compares expected results with written results
	 * 
	 * @param expFile
	 *            File containing expected results
	 * @param actFile
	 *            File containing actual results
	 */
	private void checkFiles(String expFile, String actFile) {
		try {
			Scanner expScanner = new Scanner(new FileInputStream(expFile));
			Scanner actScanner = new Scanner(new FileInputStream(actFile));

			while (expScanner.hasNextLine() && actScanner.hasNextLine()) {
				String exp = expScanner.nextLine();
				String act = actScanner.nextLine();
				assertEquals("Expected: " + exp + " Actual: " + act, exp, act);
			}
			if (expScanner.hasNextLine()) {
				fail("The expected results expect another line " + expScanner.nextLine());
			}
			if (actScanner.hasNextLine()) {
				fail("The actual results has an extra, unexpected line: " + actScanner.nextLine());
			}

			expScanner.close();
			actScanner.close();
		} catch (IOException e) {
			fail("Error reading files.");
		}
	}

}
