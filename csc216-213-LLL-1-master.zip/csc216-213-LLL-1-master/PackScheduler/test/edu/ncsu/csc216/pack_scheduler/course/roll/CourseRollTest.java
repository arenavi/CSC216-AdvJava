/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.roll;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.Student;

/**
 * Tests CourseRoll
 * @author Andrew Hensley and Luke Hansen
 */
public class CourseRollTest {
	
	Student s1 = new Student("First", "Last", "flast", "flast@ncsu.edu", "pw", 15);
	Student s2 = new Student("First1", "Last", "f1last", "flast@ncsu.edu", "pw", 15);
	Student s3 = new Student("First2", "Last", "f2last", "flast@ncsu.edu", "pw", 15);
	Student s4 = new Student("First3", "Last", "f3last", "flast@ncsu.edu", "pw", 15);
	Student s5 = new Student("First4", "Last", "f4last", "flast@ncsu.edu", "pw", 15);
	Student s6 = new Student("First5", "Last", "f5last", "flast@ncsu.edu", "pw", 15);
	Student s7 = new Student("First6", "Last", "f6last", "flast@ncsu.edu", "pw", 15);
	Student s8 = new Student("First7", "Last", "f7last", "flast@ncsu.edu", "pw", 15);
	Student s9 = new Student("First8", "Last", "f8last", "flast@ncsu.edu", "pw", 15);
	Student s10 = new Student("First9", "Last", "f9last", "flast@ncsu.edu", "pw", 15);
	Student s11 = new Student("First10", "Last", "f10last", "flast@ncsu.edu", "pw", 15);
	Student s12 = new Student("First11", "Last", "f11last", "flast@ncsu.edu", "pw", 15);
	Student s13 = new Student("First12", "Last", "f12last", "flast@ncsu.edu", "pw", 15);

	/**
	 * Tests setEnrollMentCap
	 */
	@Test
	public void testSetEnrollMentCap() {
		Course c = null;
		try {
			c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 1, "A");
			fail();
		}
		catch (IllegalArgumentException e) {
			//pass
		}
		c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		assertEquals(10, c.getCourseRoll().getEnrollmentCap());
		c.getCourseRoll().setEnrollmentCap(30);
		assertEquals(30, c.getCourseRoll().getEnrollmentCap());
	}
	
	/**
	 * Tests enroll
	 */
	@Test
	public void testEnroll() {
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		try {
			c.getCourseRoll().enroll(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			//pass
		}

		c.getCourseRoll().enroll(s1);
		try {
			c.getCourseRoll().enroll(s1);
			fail();
		}
		catch (IllegalArgumentException e) {
			//pass
		}
		c.getCourseRoll().enroll(s2);
		c.getCourseRoll().enroll(s3);
		c.getCourseRoll().enroll(s4);
		c.getCourseRoll().enroll(s5);
		c.getCourseRoll().enroll(s6);
		c.getCourseRoll().enroll(s7);
		c.getCourseRoll().enroll(s8);
		c.getCourseRoll().enroll(s9);
		c.getCourseRoll().enroll(s10);
		c.getCourseRoll().enroll(s11);
		assertEquals(0, c.getCourseRoll().getOpenSeats());
		assertEquals(1, c.getCourseRoll().getNumberOnWaitlist());
		
	}
	
	/**
	 * Tests drop
	 */
	@Test
	public void testDrop() {
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		
		try {
			c.getCourseRoll().drop(null);
			fail();
		}
		catch (IllegalArgumentException e) {
			//pass
		}
		c.getCourseRoll().enroll(s1);
		c.getCourseRoll().enroll(s2);
		c.getCourseRoll().drop(s2);
		c.getCourseRoll().drop(s1);
		
		s1 = new Student("First", "Last", "flast", "flast@ncsu.edu", "pw", 15);
		s2 = new Student("First1", "Last", "f1last", "flast@ncsu.edu", "pw", 15);
		
		c.getCourseRoll().enroll(s1);
		c.getCourseRoll().enroll(s2);
		c.getCourseRoll().enroll(s3);
		c.getCourseRoll().enroll(s4);
		c.getCourseRoll().enroll(s5);
		c.getCourseRoll().enroll(s6);
		c.getCourseRoll().enroll(s7);
		c.getCourseRoll().enroll(s8);
		c.getCourseRoll().enroll(s9);
		c.getCourseRoll().enroll(s10);
		c.getCourseRoll().enroll(s11);
		c.getCourseRoll().drop(s11);
		
		s1 = new Student("First10", "Last", "f10last", "flast@ncsu.edu", "pw", 15);
		c.getCourseRoll().enroll(s11);
		c.getCourseRoll().enroll(s12);
		c.getCourseRoll().enroll(s13);
		c.getCourseRoll().drop(s1);
		assertEquals(2, c.getCourseRoll().getNumberOnWaitlist());
		assertEquals(0, c.getCourseRoll().getOpenSeats());
	}
	
	/**
	 * Tests getOpenSeats
	 */
	@Test
	public void testGetOpenSeats() {
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		s1 = new Student("First", "Last", "flast", "flast@ncsu.edu", "pw", 15);
		assertEquals(10, c.getCourseRoll().getOpenSeats());
		c.getCourseRoll().enroll(s1);
		assertEquals(9, c.getCourseRoll().getOpenSeats());
	}
	
	/**
	 * Tests canEnroll
	 */
	@Test
	public void testCanEnroll() {
		Course c = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "A");
		s1 = new Student("First", "Last", "flast", "flast@ncsu.edu", "pw", 15);
		assertTrue(c.getCourseRoll().canEnroll(s1));
		c.getCourseRoll().enroll(s1);
		assertFalse(c.getCourseRoll().canEnroll(s1));
	}

}
