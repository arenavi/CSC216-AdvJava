/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.catalog;

import static org.junit.Assert.*;


import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;
/**
 * Tests CourseCatalog class
 * @author Andrew Hensley, Shiyi Ding, and Liam Hall
 */
public class CourseCatalogTest {
	
	/** Valid course records */
	private final String validTestFile = "test-files/course_records.txt";
	/** Invalid course records */
	private final String invalidTestFile = "test-files/invalid_course_records.txt";
	/** Invalid course records */
	private final String invalidTestFile2 = "test-files/I_DONT_EXSIT.txt";

	/** Course name */
	private static final String NAME = "CSC216";
	/** Course title */
	private static final String TITLE = "Programming Concepts - Java";
	/** Course section */
	private static final String SECTION = "001";
	/** Course credits */
	private static final int CREDITS = 4;
	/** Course instructor id */
	private static final String INSTRUCTOR_ID = "sesmith5";
	/** Course meeting days */
	private static final String MEETING_DAYS = "TH";
	/** Course start time */
	private static final int START_TIME = 1330;
	/** Course end time */
	private static final int END_TIME = 1445;
	
	/**
	 * Tests CourseCatalog constructor
	 */
	@Test
	public void testCourseCatalog(){
		CourseCatalog cc = new CourseCatalog();
		assertEquals(0, cc.getCourseCatalog().length);
	}
	
	/**
	 * Tests loadCoursesFromFile()
	 */
	@Test
	public void testLoadCoursesFromFile(){
		CourseCatalog cc = new CourseCatalog();
		//test Invalid file 
		cc.loadCoursesFromFile(invalidTestFile);
		assertEquals(0, cc.getCourseCatalog().length);
		//test valid file
		cc.loadCoursesFromFile(validTestFile);
		assertEquals(8, cc.getCourseCatalog().length);
		//test file never exsit
		try {
			cc.loadCoursesFromFile(invalidTestFile2);
			fail();
		} catch(IllegalArgumentException e){
			//catch the IllegalArgumentException
		}
	}
	
	/**
	 * Tests addCourseToCatalog()
	 */
	@Test
	public void testAddCoursesToCatalog(){
		CourseCatalog cc = new CourseCatalog();
		//test add a valid course
		cc.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, 10, MEETING_DAYS, START_TIME, END_TIME);

		assertEquals(1, cc.getCourseCatalog().length);
		//test add a invalid course which is duplicate
		cc.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, 10, MEETING_DAYS, START_TIME, END_TIME);
		assertEquals(1, cc.getCourseCatalog().length);
	}
	
	/**
	 * Tests removeCourseFromCatalog
	 */
	@Test
	public void testRemoveCourseFromCatalog(){
		CourseCatalog cc = new CourseCatalog();
		//test add a valid course and remove it
		cc.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, 10, MEETING_DAYS, START_TIME, END_TIME);
		assertEquals(1, cc.getCourseCatalog().length);
		cc.removeCourseFromCatalog(TITLE, INSTRUCTOR_ID);
		cc.removeCourseFromCatalog(NAME, TITLE);
		cc.removeCourseFromCatalog(NAME, SECTION);
		assertEquals(0, cc.getCourseCatalog().length);
	}
	
	/**
	 * Tests getCourseFromCatalog()
	 */
	@Test
	public void testGetCourseFromCatalog(){
		CourseCatalog cc = new CourseCatalog();
		//test add a valid course and remove it
		Course c = null;
		c = new Course(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, 10, MEETING_DAYS, START_TIME, END_TIME);
		cc.addCourseToCatalog(NAME, TITLE, SECTION, CREDITS, INSTRUCTOR_ID, 10, MEETING_DAYS, START_TIME, END_TIME);
		assertEquals(1, cc.getCourseCatalog().length);
		assertEquals(c, cc.getCourseFromCatalog(NAME, SECTION));
	}
}
