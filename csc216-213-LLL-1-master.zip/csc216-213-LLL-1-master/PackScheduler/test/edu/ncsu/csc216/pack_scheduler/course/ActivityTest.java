/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests Activity Class
 * @author Andrew Hensley
 *
 */
public class ActivityTest {

	/**
	 * Test method for checkConflict()
	 */
	@Test
	public void testCheckConflict() {
	    Activity a1 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1445);
	    Activity a2 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "TH", 1330, 1445);
	    
	    //Test with no conflict
	    try {
	        a1.checkConflict(a2);
	        assertEquals("Incorrect meeting string for this Activity.", "MW 1:30PM-2:45PM", a1.getMeetingString());
	        assertEquals("Incorrect meeting string for possibleConflictingActivity.", "TH 1:30PM-2:45PM", a2.getMeetingString());
	    } catch (ConflictException e) {
	        fail("A ConflictException was thrown when two Activities at the same time on completely distinct days were compared.");
	    }
	    
	    //Test for no conflict commutativity
	    try {
	        a2.checkConflict(a1);
	        assertEquals("Incorrect meeting string for this Activity.", "MW 1:30PM-2:45PM", a1.getMeetingString());
	        assertEquals("Incorrect meeting string for possibleConflictingActivity.", "TH 1:30PM-2:45PM", a2.getMeetingString());
	    } catch (ConflictException e) {
	        fail("A ConflictException was thrown when two Activities at the same time on completely distinct days were compared.");
	    }
	    
	    //Test for conflict on a single day
	    a1.setMeetingDays("TW");
	    try {
	        a1.checkConflict(a2);
	        fail();
	    } catch (ConflictException e) {
	        //Check that the internal state didn't change during method call.
	        assertEquals("TW 1:30PM-2:45PM", a1.getMeetingString());
	        assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    }
	    
	    //Test with conflict
	    a1.setMeetingDays("TH");
	    a1.setActivityTime(1445, 1530);
	    try {
	        a1.checkConflict(a2);
	        fail();
	    } catch (ConflictException e) {
	        //Check that the internal state didn't change during method call.
	        assertEquals("TH 2:45PM-3:30PM", a1.getMeetingString());
	        assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    }
	    
	    //Test for conflict commutativity
	    try {
	        a2.checkConflict(a1);
	        fail();
	    } catch (ConflictException e) {
	        //Check that the internal state didn't change during method call.
	        assertEquals("TH 2:45PM-3:30PM", a1.getMeetingString());
	        assertEquals("TH 1:30PM-2:45PM", a2.getMeetingString());
	    }
	    
	    //Test for this.endTime = other.startTime conflict
	    a2.setActivityTime(1530, 1600);
	    try {
	        a1.checkConflict(a2);
	        fail();
	    } catch (ConflictException e) {
	        //Check that the internal state didn't change during method call.
	        assertEquals("TH 2:45PM-3:30PM", a1.getMeetingString());
	        assertEquals("TH 3:30PM-4:00PM", a2.getMeetingString());
	    }
	    
	}
	
	/**
	 * Tests getMeetingString in Activity
	 */
	@Test
    public void testGetMeetingString() {
    	Activity a1 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 0, 0);
    	Activity a2 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 10, 11);
    	Activity a3 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 600, 650);
    	Activity a4 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 8, 201);
    	Activity a5 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1201, 1202);
    	Activity a6 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1701, 1702);
    	Activity a7 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1259, 1300);
    	Activity a8 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 2, 2);
    	assertEquals(a1.getMeetingString(), "MW 12:00AM-12:00AM");
    	assertEquals(a2.getMeetingString(), "MW 12:10AM-12:11AM");
    	assertEquals(a3.getMeetingString(), "MW 6:00AM-6:50AM");
    	assertEquals(a4.getMeetingString(), "MW 12:08AM-2:01AM");
    	assertEquals(a5.getMeetingString(), "MW 12:01PM-12:02PM");
    	assertEquals(a6.getMeetingString(), "MW 5:01PM-5:02PM");
    	assertEquals(a7.getMeetingString(), "MW 12:59PM-1:00PM");
    	assertEquals(a8.getMeetingString(), "MW 12:02AM-12:02AM");
    }

	/**
	 * Tests equals()
	 */
	@Test
	public void testEquals() {
		Activity a1 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1445);
	    Activity a2 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1445);
	    Activity a3 = new Course("BSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1445);
	    Activity a4 = new Course("CSC216", "Brogramming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1445);
	    Activity a5 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "TH", 1330, 1445);
	    Activity a6 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1331, 1445);
	    Activity a7 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1446);
	    assertEquals(true, a1.equals(a2));
	    assertEquals(false, a1.equals(a3));
	    assertEquals(false, a1.equals(a4));
	    assertEquals(false, a1.equals(a5));
	    assertEquals(false, a1.equals(a6));
	    assertEquals(false, a1.equals(a7));
	}
	
	/**
	 * Tests hashCode()
	 */
	@Test
	public void testHashCode() {
		Activity a1 = new Course("CSC216", "Programming Concepts - Java", "001", 4, "sesmith5", 10, "MW", 1330, 1445);
		assertEquals(-14750364, a1.hashCode());
	}
}
