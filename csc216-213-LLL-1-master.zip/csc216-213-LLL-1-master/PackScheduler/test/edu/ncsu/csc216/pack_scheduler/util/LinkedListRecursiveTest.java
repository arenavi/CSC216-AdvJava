/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Implementation of LinkedList with recursive methods
 * @author Andrew, Amiya, and Joshua
 *
 */
public class LinkedListRecursiveTest {

	/** Test LinkedListRecursive */
    private LinkedListRecursive<String> list;
    
    /**
     * Tests LinkedListRecursive.add
     */
    @Test
    public void addTest() {
        list = new LinkedListRecursive<String>();
        try {
            list.add(5, "Grape");
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(list.size(), 0);
        }
        try {
            list.add(0, null);
            fail();
        } catch (NullPointerException e) {
            assertEquals(list.size(), 0);
        }
        try {
            list.add(0, "Food");
            assertEquals(list.size(), 1);
        } catch (IllegalArgumentException e) {
            fail();
        }
        
        try {
            list.add(null);
            fail();
        } catch (NullPointerException e) {
            //do nothing
        }
    }
    
    /**
     * Tests LinkedListRecursive.get
     */
    @Test
    public void getTest() {
        list = new LinkedListRecursive<String>();
        try {
            list.add(0, "Food");
            assertEquals(list.size(), 1);
        } catch (IllegalArgumentException e) {
            fail();
        }
        assertEquals("Food", list.get(0));
        try {
            list.get(1);
            fail();
        } catch (IndexOutOfBoundsException e) {
            //pass
        }
    }
    
    /**
     * Tests LinkedListRecursive.set
     */
    @Test
    public void setTest() {
        list = new LinkedListRecursive<String>();
        try {
            list.set(5, "Grape");
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(list.size(), 0);
        }
        try {
            list.set(1, "Food");
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(list.size(), 0);
        }
       try {
            list.set(0, "Food");
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(list.size(), 0);
        }
        try {
            list.add(0, "Food");
            assertEquals(list.size(), 1);
        } catch (IllegalArgumentException e) {
            fail();
        }
        try {
            list.add(1, "Food2");
            assertEquals(list.size(), 2);
        } catch (IllegalArgumentException e) {
            fail();
        }
        try {
            list.set(1, "Food");
            fail();
        } catch (IllegalArgumentException e) {
            assertEquals(list.size(), 2);
        }
        try {
            list.set(1, "Grapes");
            assertEquals(list.size(), 2);
        } catch (IndexOutOfBoundsException e) {
            fail();
        }
        try {
            list.set(1, null);
            fail();
        } catch (NullPointerException e) {
            //do nothing
        }
        list.add("Test1");
        list.add("test2");
        list.set(1, "reset");
        assertEquals("reset", list.get(1));
        list.set(0, "reset2");
        assertEquals("reset2", list.get(0));
        assertTrue(list.remove("reset"));
        assertTrue(list.remove("reset2"));
        
    }
    
    /**
     * Tests LinkedListRecursive.remove
     */
    @Test
    public void removeTest() {
        list = new LinkedListRecursive<String>();
        list.add(0, "fire");
        list.add(1, "bubble");
        list.add(2, "cotton");
        assertEquals(list.size(), 3);
        assertEquals(list.get(0), "fire");
        assertEquals(list.get(1), "bubble");
        assertEquals(list.get(2), "cotton");
        try {
            list.remove(4);
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(list.size(), 3);
        }
        assertEquals(list.remove(2), "cotton");
        assertEquals(list.size(), 2);
        assertEquals(list.remove(1), "bubble");
        assertEquals(list.size(), 1);
        assertEquals(list.remove(0), "fire");
        assertEquals(list.size(), 0);
        
        list.add(0, "fire");
        list.add(1, "bubble");
        list.add(2, "cotton");
        assertEquals(list.size(), 3);
        assertEquals(list.get(0), "fire");
        assertEquals(list.get(1), "bubble");
        assertEquals(list.get(2), "cotton");
        assertFalse(list.remove("water"));
        assertTrue(list.remove("fire"));
        assertTrue(list.remove("bubble"));
        assertTrue(list.remove("cotton"));
        assertEquals(list.size(), 0);
    }


}
