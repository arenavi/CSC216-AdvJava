package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import java.util.EmptyStackException;

import org.junit.Test;

/**
 * Tests ArrayStack
 * @author Andrew, Amiya, and Joshua
 *
 */
public class ArrayStackTest {

	/** Test Integer 1 */
	Integer x1 = new Integer(1);
	/** Test Integer 2 */
	Integer x2 = new Integer(2);
	/** Test Integer 3 */
	Integer x3 = new Integer(3);
	/** Test Integer 4 */
	Integer x4 = new Integer(4);
	
	/**
	 * Tests core functionality of ArrayStack
	 */
	@Test
	public void testArrayStack() {
	    
	    ArrayStack<Integer> test = new ArrayStack<Integer>(3);
	    assertEquals(0, test.size()); 
	    
		
		
		
		//Test pushing
		test.push(x1);
		assertEquals(1, test.size());
		test.push(x2);
		test.push(x3);
		assertEquals(3, test.size());
		
		try {
			test.push(x4);
		} catch (IllegalArgumentException e) {
			//TODO Fix message
			assertEquals(e.getMessage(), null);
		}
		
		//Test popping
		assertEquals(3, test.pop().intValue());
		assertEquals(2, test.size());
		assertEquals(2, test.pop().intValue());
		assertEquals(1, test.pop().intValue());
		assertEquals(0, test.size());
		
		try {
			test.pop();
			fail();
		} catch (EmptyStackException e) {
			//TODO Fix message
			assertEquals(e.getMessage(), null);
		}
		
		assertTrue(test.isEmpty());
		
		test.push(x1);
		test.push(x2);
		assertEquals(2, test.size());
		assertEquals(2, test.pop().intValue());
		assertEquals(1, test.size());
		test.push(x3);
		assertEquals(2, test.size());
		assertEquals(3, test.pop().intValue());
		
	}
	
	/**
	 * Tests ArrayStack.setCapacity
	 */
	@Test
	public void testSetCapacity() {
		ArrayStack<Integer> test = new ArrayStack<Integer>(5);
		test.push(x1);
		test.push(x2);
		test.push(x3);
		test.setCapacity(3);
		try {
			test.push(x4);
		} catch(IllegalArgumentException e) {
			//TODO Fix message
			assertEquals(null, e.getMessage());
		}
		
		try {
			test.setCapacity(1);
		} catch(IllegalArgumentException e) {
			//TODO Fix message
			assertEquals(null, e.getMessage());
		}
	}
}
