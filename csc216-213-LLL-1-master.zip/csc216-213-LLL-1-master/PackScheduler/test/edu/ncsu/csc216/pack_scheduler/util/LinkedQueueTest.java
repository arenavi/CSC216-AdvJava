/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Tests LinkedQueue
 * @author Andrew, Amiya, and Joshua
 */
public class LinkedQueueTest {

	/** Test Integer 1 */
	Integer x1 = new Integer(1);
	/** Test Integer 2 */
	Integer x2 = new Integer(2);
	/** Test Integer 3 */
	Integer x3 = new Integer(3);
	/** Test Integer 4 */
	Integer x4 = new Integer(4);

	/**
	 * Tests core functionality of LinkedQueue
	 */
	@Test
	public void testLinkedQueue() {
		LinkedQueue<Integer> test = new LinkedQueue<Integer>(3);
		assertEquals(0, test.size());
		
		
		//Test pushing
		test.enqueue(x1);
		assertEquals(1, test.size());
		test.enqueue(x2);
		test.enqueue(x3);
		assertEquals(3, test.size());
		
		try {
			test.enqueue(x4);
		} catch (IllegalArgumentException e) {
			//TODO Fix message
			assertEquals(e.getMessage(), null);
		}
		
		//Test dequeuing
		assertEquals(1, test.dequeue().intValue());
		assertEquals(2, test.size());
		assertEquals(2, test.dequeue().intValue());
		assertEquals(3, test.dequeue().intValue());
		assertEquals(0, test.size());
		
		try {
			test.dequeue();
			fail();
		} catch (NoSuchElementException e) {
			//TODO Fix message
			assertEquals(e.getMessage(), null);
		}
		
		assertTrue(test.isEmpty());
		
		test.enqueue(x1);
		test.enqueue(x2);
		assertEquals(2, test.size());
		assertEquals(1, test.dequeue().intValue());
		assertEquals(1, test.size());
		test.enqueue(x3);
		assertEquals(2, test.size());
		assertEquals(2, test.dequeue().intValue());
		
	}
	
	/**
	 * Tests LinkedQueue.setCapacity
	 */
	@Test
	public void testSetCapacity() {
		LinkedQueue<Integer> test = new LinkedQueue<Integer>(5);
		test.enqueue(x1);
		test.enqueue(x2);
		test.enqueue(x3);
		test.setCapacity(6);
		try {
			test.enqueue(x4);
		} catch(IllegalArgumentException e) {
			//TODO Fix message
			assertEquals(null, e.getMessage());
		}
		
		try {
			test.setCapacity(1);
		} catch(IllegalArgumentException e) {
			//TODO Fix message
			assertEquals(null, e.getMessage());
		}
	}

}
