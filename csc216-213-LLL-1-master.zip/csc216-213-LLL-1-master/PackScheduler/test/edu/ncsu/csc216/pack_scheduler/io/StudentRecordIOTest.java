package edu.ncsu.csc216.pack_scheduler.io;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.io.StudentRecordIO;

/**
 * Tests StudentRecordIO
 * 
 * @author Andrew Hensley, Shiyi Ding, and Liam Hall
 */
public class StudentRecordIOTest {

	/** Valid Student records */
	private final String validTestFile = "test-files/student_records.txt";
	/** Invalid Student records */
	private final String invalidTestFile = "test-files/invalid_student_records.txt";
	/** Hashed password */
	private String hashPW;
	/** Algorithm used to hash password */
	private static final String HASH_ALGORITHM = "SHA-256";
	/** Test path with no permission */
	private static final String PATH_NAME = "/home/sesmith5/actual_student_records.txt";

	private final String validStudent7 = "Zahir,King,zking,orci.Donec@ametmassaQuisque.com,pw,15";
	private final String validStudent9 = "Cassandra,Schwartz,cschwartz,semper@imperdietornare.co.uk,pw,4";
	private final String validStudent5 = "Shannon,Hansen,shansen,convallis.est.vitae@arcu.ca,pw,14";
	private final String validStudent1 = "Demetrius,Austin,daustin,Curabitur.egestas.nunc@placeratorcilacus.co.uk,pw,18";
	private final String validStudent3 = "Raymond,Brennan,rbrennan,litora.torquent@pellentesquemassalobortis.ca,pw,12";
	private final String validStudent4 = "Emerald,Frost,efrost,adipiscing@acipsumPhasellus.edu,pw,3";
	private final String validStudent2 = "Lane,Berg,lberg,sociis@non.org,pw,14";
	private final String validStudent10 = "Griffith,Stone,gstone,porta@magnamalesuadavel.net,pw,17";
	private final String validStudent6 = "Althea,Hicks,ahicks,Phasellus.dapibus@luctusfelis.com,pw,11";
	private final String validStudent8 = "Dylan,Nolan,dnolan,placerat.Cras.dictum@dictum.net,pw,5";

	private final String[] validStudents = { validStudent1, validStudent2, validStudent3, validStudent4, validStudent5,
			validStudent6, validStudent7, validStudent8, validStudent9, validStudent10 };

	/**
	 * Converts pw into hashed password
	 * @throws Exception if error occurs
	 */
	@Before
	public void setUp() throws Exception {
		try {
			String password = "pw";
			MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
			digest.update(password.getBytes());
			hashPW = new String(digest.digest());

			for (int i = 0; i < validStudents.length; i++) {
				validStudents[i] = validStudents[i].replace(",pw,", "," + hashPW + ",");
			}
		} catch (NoSuchAlgorithmException e) {
			fail("Unable to create hash during setup");
		}
	}

	/**
	 * Tests readStudentRecords in StudentRecordIO
	 */
	@Test
	public void testReadStudentRecords() {
		// Tests valid cases with one duplicate
		try {
			SortedList<Student> students = StudentRecordIO.readStudentRecords(validTestFile);
			assertEquals(10, students.size());

			for (int i = 0; i < validStudents.length; i++) {
				assertEquals(validStudents[i], students.get(i).toString());
			}
		} catch (FileNotFoundException e) {
			fail("Unexpected error reading " + validTestFile);
		}

		// Tests invalid cases
		try {
			SortedList<Student> studentsb = StudentRecordIO.readStudentRecords(invalidTestFile);
			assertEquals(0, studentsb.size());
		} catch (FileNotFoundException e) {
			fail("Unexpected FileNotFoundException");
		}
		

	}

	/**
	 * Tests writeStudentRecords in StudentRecordIO
	 */
	@Test
	public void testWriteStudentRecords() {
		SortedList<Student> students = new SortedList<Student>();
		students.add(new Student("Andrew", "Hensley", "ahensle2", "ahensle2@ncsu.edu", "pw", 15));
		students.add(new Student("Shiyi", "Ding", "sding5", "sding5@ncsu.edu", "pw", 15));
		students.add(new Student("Liam", "Hall", "lbhall2", "lbhall2@ncsu.edu", "pw"));

		try {
			StudentRecordIO.writeStudentRecords("test-files/actual_student_records.txt", students);
			checkFiles("test-files/actual_student_records.txt", "test-files/new_expected_student_records.txt");
		} catch (IOException e) {
			fail();
		}
	}

	/**
	 * Compares expected results with written results
	 * 
	 * @param expFile
	 *            File containing expected results
	 * @param actFile
	 *            File containing actual results
	 */
	private void checkFiles(String expFile, String actFile) {
		try {
			Scanner expScanner = new Scanner(new FileInputStream(expFile));
			Scanner actScanner = new Scanner(new FileInputStream(actFile));

			while (expScanner.hasNextLine() && actScanner.hasNextLine()) {
				String exp = expScanner.nextLine();
				String act = actScanner.nextLine();
				assertEquals("Expected: " + exp + " Actual: " + act, exp, act);
			}
			if (expScanner.hasNextLine()) {
				fail("The expected results expect another line " + expScanner.nextLine());
			}
			if (actScanner.hasNextLine()) {
				fail("The actual results has an extra, unexpected line: " + actScanner.nextLine());
			}

			expScanner.close();
			actScanner.close();
		} catch (IOException e) {
			fail("Error reading files.");
		}
	}

	/**
	 * Tests case where writer does not have permission
	 */
	@Test
	public void testWriteStudentRecordsNoPermissions() {
		SortedList<Student> students = new SortedList<Student>();
		students.add(new Student("Zahir", "King", "zking", "orci.Donec@ametmassaQuisque.com", hashPW, 15));
		// Assumption that you are using a hash of "pw" stored in hashPW

		try {
			StudentRecordIO.writeStudentRecords(PATH_NAME, students);
			fail("Attempted to write to a directory location that doesn't exist or without the appropriate permissions and the write happened.");
		} catch (IOException e) {
			assertEquals("/home/sesmith5/actual_student_records.txt (Permission denied)", e.getMessage());
			// The actual error message on Jenkins!
		}

	}

}
