package edu.ncsu.csc216.pack_scheduler.course.validator;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.validator.CourseNameValidator.SuffixState;

/**
 * Tests CourseNameValidator
 * @author Andrew Hensley and Luke Hansen
 *
 */
public class CourseNameValidatorTest {
	
	/** Validator */
	private CourseNameValidator validator;
	
	/**
	 * Sets up constants for testing
	 */
	@Before
	public void setUp() {
		validator = new CourseNameValidator();
	}
	
	/**
	 * Tests CourseNameValidator
	 */
	@Test
	public void testCourseNameValidator() {
		//Valid Test Cases
		try {
			assertTrue(validator.isValid("C116"));
			assertTrue(validator.isValid("C116A"));
			assertTrue(validator.isValid("CS116"));
			assertTrue(validator.isValid("CS116A"));
			assertTrue(validator.isValid("CSC116"));
			assertTrue(validator.isValid("CSC116A"));
			assertTrue(validator.isValid("CSCA116"));
			assertTrue(validator.isValid("CSCA116A"));
		}
		catch (InvalidTransitionException e) {
			fail("Valid Names");
		}
		
		//Invalid Test Cases
		try {
			assertFalse(validator.isValid("CCCC"));
			assertFalse(validator.isValid("CSC21"));
		}
		catch (InvalidTransitionException e) {
			fail();
		}
		
		//Exception Cases
		try {
			assertFalse(validator.isValid("!"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CCCCC"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CCC2166"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CCC216A1"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CCC216AA"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CCC2A"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CCC21A"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("9"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("99"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CSC2AA"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("CSC9999"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
		try {
			assertFalse(validator.isValid("C999AA"));
		}
		catch (InvalidTransitionException e) {
			//Should throw Exception
		}
	}
	
	/**
	 * Tests SuffixState specifically
	 */
	@Test
	public void testOnSuffix() {
		SuffixState s = validator.new SuffixState();
		try {
			s.onDigit();
			fail();
		}
		catch (InvalidTransitionException e) {
			//Should throw Excpetion
		}
		try {
			s.onLetter();
			fail();
		}
		catch (InvalidTransitionException e) {
			//Should throw Excpetion
		}
	}
}
