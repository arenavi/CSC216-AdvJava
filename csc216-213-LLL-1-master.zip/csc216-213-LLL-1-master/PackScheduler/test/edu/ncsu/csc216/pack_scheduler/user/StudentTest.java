package edu.ncsu.csc216.pack_scheduler.user;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.course.Course;

/**
 * Tests Student
 * @author Andrew Hensley, Shiyi Ding, and Liam Hall
 */
public class StudentTest {

	private static final String FIRST_NAME = "first";
	private static final String LAST_NAME = "last";
	private static final String ID = "id";
	private static final String EMAIL = "email@ncsu.edu";
	private static final String HASH_PW = "hashedpassword";
	private static final int CREDITS_TEST1 = 15;
	private static final int MAX_CREDITS = 18;
	private static final int CREDITS_TEST2 = 19;
	private static final int CREDITS_TEST3 = 2;
	/** Test course for add and remove */
	private final Course course1 = new Course("CSC100", "Intro to Garbage", "999", 5, "lmhansen", 10, "M", 0, 15);
	/**
	 * Tests construction of Student Object with valid and invalid cases
	 */
	@Test
	public void testStudentStringStringStringStringStringInt() {
		// test first name is null
		Student s = null;
		try {
			s = new Student(null, LAST_NAME, ID, EMAIL, HASH_PW, CREDITS_TEST1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test last name is null
		s = null;
		try {
			s = new Student(FIRST_NAME, null, ID, EMAIL, HASH_PW, CREDITS_TEST1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test id is null
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, null, EMAIL, HASH_PW, CREDITS_TEST1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test id is empty
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, "", EMAIL, HASH_PW, CREDITS_TEST1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test email is null
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, null, HASH_PW, CREDITS_TEST1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test password is null
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, null, CREDITS_TEST1);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test invalid credits
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, CREDITS_TEST2);
			fail();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}

		// test valid construction
		s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, CREDITS_TEST1);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(CREDITS_TEST1, s.getMaxCredits());
		} catch (IllegalArgumentException e) {
			fail();
		}

	}

	/**
	 * Tests construction of Student Object without maxCredits (valid)
	 */
	@Test
	public void testStudentStringStringStringStringString() {
		User s = null;
		try {
			s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW);
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
		} catch (IllegalArgumentException e) {
			fail();
		}
	}

	/**
	 * Tests setFirstName in Student
	 */
	@Test
	public void testSetFirstName() {
		Student s = null;
		s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());

		// test setting first name empty which is invalid
		try {
			s.setFirstName("");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test setting first name null which is invalid
		try {
			s.setFirstName(null);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test setting a valid first name
		s.setFirstName("Student");
		assertEquals("Student", s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());
	}

	/**
	 * Tests setLastName in Student
	 */
	@Test
	public void testSetLastName() {
		Student s = null;
		s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());

		// test setting last name empty which is invalid
		try {
			s.setLastName("");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test setting last name null which is invalid
		try {
			s.setLastName(null);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test setting a valid last name
		s.setLastName("Student");
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals("Student", s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());
	}

	/**
	 * Tests setEmail in Student
	 */
	@Test
	public void testSetEmail() {
		Student s = null;
		s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());

		// test invalid email
		try {
			s.setEmail("");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test invalid email
		try {
			s.setEmail(null);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test invalid email
		try {
			s.setEmail("email@ncsuedu");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test invalid email
		try {
			s.setEmail("emailncsu.edu");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test invalid email
		try {
			s.setEmail("emailncsu.ed@u");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test setting a valid first name
		s.setEmail("student@ncsu.edu");
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals("student@ncsu.edu", s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());
	}

	/**
	 * Tests setPassword in Student
	 */
	@Test
	public void testSetPassword() {
		Student s = null;
		s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());

		// test invalid password
		try {
			s.setPassword("");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test invalid password
		try {
			s.setPassword(null);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test valid password
		s.setPassword("pw");
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals("pw", s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());
	}

	/**
	 * Tests setMaxCredits in Student
	 */
	@Test
	public void testSetMaxCredits() {
		Student s = null;
		s = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(MAX_CREDITS, s.getMaxCredits());

		// test invalid credits
		try {
			s.setMaxCredits(CREDITS_TEST3);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test invalid credits
		try {
			s.setMaxCredits(CREDITS_TEST2);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(FIRST_NAME, s.getFirstName());
			assertEquals(LAST_NAME, s.getLastName());
			assertEquals(ID, s.getId());
			assertEquals(EMAIL, s.getEmail());
			assertEquals(HASH_PW, s.getPassword());
			assertEquals(MAX_CREDITS, s.getMaxCredits());
		}

		// test valid credits
		s.setMaxCredits(CREDITS_TEST1);
		assertEquals(FIRST_NAME, s.getFirstName());
		assertEquals(LAST_NAME, s.getLastName());
		assertEquals(ID, s.getId());
		assertEquals(EMAIL, s.getEmail());
		assertEquals(HASH_PW, s.getPassword());
		assertEquals(CREDITS_TEST1, s.getMaxCredits());
	}

	/**
	 * Tests equals method in Student
	 */
	@Test
	public void testEqualsObject() {
		User s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s2 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s3 = new Student("student", LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s4 = new Student(FIRST_NAME, "student", ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s5 = new Student(FIRST_NAME, LAST_NAME, "hdauidh", EMAIL, HASH_PW, MAX_CREDITS);
		User s6 = new Student(FIRST_NAME, LAST_NAME, ID, "aaaaa@ncsu.edu", HASH_PW, MAX_CREDITS);
		User s7 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, "dawhduia", MAX_CREDITS);
		User s8 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, CREDITS_TEST1);
		User s9 = null;

		// Test for equality in both directions
		assertTrue(s1.equals(s2));
		assertTrue(s2.equals(s1));

		// Test for each of the fields
		assertFalse(s1.equals(s3));
		assertFalse(s1.equals(s4));
		assertFalse(s1.equals(s5));
		assertFalse(s1.equals(s6));
		assertFalse(s1.equals(s7));
		assertFalse(s1.equals(s8));
		assertFalse(s1.equals(s9));
	}

	/**
	 * Tests hashCode in Student
	 */
	@Test
	public void testHashCode() {
		User s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s2 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s3 = new Student("student", LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s4 = new Student(FIRST_NAME, "student", ID, EMAIL, HASH_PW, MAX_CREDITS);
		User s5 = new Student(FIRST_NAME, LAST_NAME, "hdauidh", EMAIL, HASH_PW, MAX_CREDITS);
		User s6 = new Student(FIRST_NAME, LAST_NAME, ID, "aaaaa@ncsu.edu", HASH_PW, MAX_CREDITS);
		User s7 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, "dawhduia", MAX_CREDITS);
		User s8 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, CREDITS_TEST1);

		// Test for the same hash code for the same values
		assertEquals(s1.hashCode(), s2.hashCode());
		assertEquals(s2.hashCode(), s1.hashCode());

		// Test for each of the fields
		assertNotEquals(s1.hashCode(), s3.hashCode());
		assertNotEquals(s1.hashCode(), s4.hashCode());
		assertNotEquals(s1.hashCode(), s5.hashCode());
		assertNotEquals(s1.hashCode(), s6.hashCode());
		assertNotEquals(s1.hashCode(), s7.hashCode());
		assertNotEquals(s1.hashCode(), s8.hashCode());
	}

	/**
	 * Tests toString in Student
	 */
	@Test
	public void testToString() {
		User s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		String str1 = "first,last,id,email@ncsu.edu,hashedpassword,18";
		assertEquals(str1, s1.toString());
	}
	
	/**
	 * Tests compareTo in Student.java
	 */
	@Test
	public void testCompareTo() {
		//Adds Students
	    Student studenta = new Student("First", "Last", "id", "id@ncsu.edu", "pw", 15);
	    Student studentb = new Student("First", "Aast", "id", "id@ncsu.edu", "pw", 15);
	    Student studentc = new Student("First", "Zast", "id", "id@ncsu.edu", "pw", 15);
	    Student studentd = new Student("Airst", "Last", "id", "id@ncsu.edu", "pw", 15);
	    Student studente = new Student("Zirst", "Last", "id", "id@ncsu.edu", "pw", 15);
	    Student studentf = new Student("First", "Last", "ad", "id@ncsu.edu", "pw", 15);
	    Student studentg = new Student("First", "Last", "zd", "id@ncsu.edu", "pw", 15);
	    
	    //Tests if identical Students are equal
	    assertEquals(studenta.compareTo(studenta), 0);
	    
	    //Tests last name sorting
	    assertEquals(studenta.compareTo(studentb), 1);
	    assertEquals(studenta.compareTo(studentc), -1);
	    
	    //Tests first name sorting
	    assertEquals(studenta.compareTo(studentd), 1);
	    assertEquals(studenta.compareTo(studente), -1);
	    
	    //Tests id sorting
	    assertEquals(studenta.compareTo(studentf), 1);
	    assertEquals(studenta.compareTo(studentg), -1);
	}
	
	/**
	 * Tests canAdd() method
	 */
	public void canAddTest() {
		Student s1 = new Student(FIRST_NAME, LAST_NAME, ID, EMAIL, HASH_PW, MAX_CREDITS);
		assertTrue(s1.canAdd(course1));
		s1.getSchedule().addCourseToSchedule(course1);
		assertFalse(s1.canAdd(new Course("CSC100", "Intro to Food", "998", 4, "lhhansen", 10, "M", 30, 45)));
		assertFalse(s1.canAdd(new Course("CSC541", "Into to computer Magic", "990", 3, "cjhansen", 10, "M", 0, 100)));
	}

}
