package edu.ncsu.csc216.pack_scheduler.util;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.pack_scheduler.util.ArrayList;

/**
 * Tests ArrayList
 * @author Andrew Hensley and Luke Hansen
 */
public class ArrayListTest {
	/** Test ArrayList */
	private ArrayList<String> list;
	
	/**
	 * Tests ArrayList.add
	 */
	@Test
	public void addTest() {
		list = new ArrayList<String>();
		try {
			list.add(5, "Grape");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(list.size(), 0);
		}
		try {
			list.add(0, null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(list.size(), 0);
		}
		try {
			list.add(0, "Food");
			assertEquals(list.size(), 1);
		} catch (IllegalArgumentException e) {
			fail();
		}
	}
	
	/**
	 * Tests ArrayList.get
	 */
	@Test
	public void getTest() {
		list = new ArrayList<String>();
		try {
			list.add(0, "Food");
			assertEquals(list.size(), 1);
		} catch (IllegalArgumentException e) {
			fail();
		}
		assertEquals("Food", list.get(0));
		try {
			list.get(1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			//pass
		}
	}
	
	/**
	 * Tests ArrayList.set
	 */
	@Test
	public void setTest() {
		list = new ArrayList<String>();
		try {
			list.set(5, "Grape");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(list.size(), 0);
		}
		try {
			list.set(1, null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(list.size(), 0);
		}
		try {
			list.set(0, "Food");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(list.size(), 0);
		}
		try {
			list.add(0, "Food");
			assertEquals(list.size(), 1);
		} catch (IllegalArgumentException e) {
			fail();
		}
		try {
			list.set(1, "Food");
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(list.size(), 1);
		}
		try {
			list.set(1, "Grapes");
			assertEquals(list.size(), 2);
		} catch (IllegalArgumentException e) {
			fail();
		}
		
	}
	
	/**
	 * Tests ArrayList.remove
	 */
	@Test
	public void removeTest() {
		list = new ArrayList<String>();
		list.add(0, "fire");
		list.add(1, "bubble");
		list.add(2, "cotton");
		assertEquals(list.size(), 3);
		assertEquals(list.get(0), "fire");
		assertEquals(list.get(1), "bubble");
		assertEquals(list.get(2), "cotton");
		try {
			list.remove(4);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(list.size(), 3);
		}
		assertEquals(list.remove(2), "cotton");
		assertEquals(list.size(), 2);
		assertEquals(list.remove(1), "bubble");
		assertEquals(list.size(), 1);
		assertEquals(list.remove(0), "fire");
		assertEquals(list.size(), 0);
	}
	

}
