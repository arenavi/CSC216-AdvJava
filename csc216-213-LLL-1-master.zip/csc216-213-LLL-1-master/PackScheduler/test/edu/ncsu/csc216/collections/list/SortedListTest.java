package edu.ncsu.csc216.collections.list;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Use this meaningful class to test the Sorted List library
 * 
 * @author Shiyi Ding, Andrew Hensley, Liam Hall
 *
 */
public class SortedListTest {

	/**
	 * Test the Sorted List is first empty and test growing by adding things to
	 * the list
	 */
	@Test
	public void testSortedList() {
		SortedList<String> list = new SortedList<String>();
		assertEquals(0, list.size());
		assertFalse(list.contains("apple"));
		// add the apple to the SortedList
		list.add("apple");
		assertEquals(1, list.size());
		// add the pear to the SortedList
		list.add("pear");
		assertEquals(2, list.size());
		// add the banana to the SortedList
		list.add("banana");
		assertEquals(3, list.size());
		// add the dog to the SortedList
		list.add("dog");
		assertEquals(4, list.size());
		// add the cat to the SortedList
		list.add("cat");
		assertEquals(5, list.size());
		// add the lion to the SortedList
		list.add("lion");
		assertEquals(6, list.size());
		// add the pineapple to the SortedList
		list.add("pineapple");
		assertEquals(7, list.size());
		// add the ginger to the SortedList
		list.add("ginger");
		assertEquals(8, list.size());
		// add the water to the SortedList
		list.add("water");
		assertEquals(9, list.size());
		// add the chips to the SortedList
		list.add("chips");
		assertEquals(10, list.size());
		// add the nothing to the SortedList to test the list is growing
		list.add("nothing");
		assertEquals(11, list.size());
	}

	/**
	 * Tests the adding elements will keep list sorted and invalid elements
	 * cannot be added
	 */
	@Test
	public void testAdd() {
		SortedList<String> list = new SortedList<String>();

		list.add("banana");
		assertEquals(1, list.size());
		assertEquals("banana", list.get(0));

		// Adding to the front, middle and back of the list
		list.add("apple");
		list.add("zebra");
		list.add("melon");
		assertEquals(list.get(0), "apple");
		assertEquals(list.get(1), "banana");
		assertEquals(list.get(2), "melon");
		assertEquals(list.get(3), "zebra");
		assertEquals(4, list.size());

		// Adding a null element
		try {
			list.add(null);
			fail();
		} catch (NullPointerException e) {
			// Should not be able to add a null
		}
		assertEquals(list.get(0), "apple");
		assertEquals(list.get(1), "banana");
		assertEquals(list.get(2), "melon");
		assertEquals(list.get(3), "zebra");
		assertEquals(4, list.size());

		// Adding a duplicate element
		try {
			list.add("banana");
		} catch (IllegalArgumentException e) {
			// Should create error since element already exists
		}
		assertEquals(list.get(0), "apple");
		assertEquals(list.get(1), "banana");
		assertEquals(list.get(2), "melon");
		assertEquals(list.get(3), "zebra");
		assertEquals(4, list.size());
	}

	/**
	 * Tests error and boundary cases of SortedList's get() method
	 */
	@Test
	public void testGet() {
		SortedList<String> list = new SortedList<String>();

		assertEquals(list.size(), 0);

		// Tests getting an element from an empty list
		try {
			list.get(0);
		} catch (IndexOutOfBoundsException e) {
			//throw any exception found
		}

		// Adding some elements to the list
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");

		// Tests getting an element at an index < 0
		try {
			list.get(-1);
		} catch (IndexOutOfBoundsException e) {
			//throw any exception found
		}

		// Tests getting an element at size
		try {
			list.get(list.size());
		} catch (IndexOutOfBoundsException e) {
			//throw any exception found
		}

	}
	
	/**
	* Test the remove method of the sorted list
	*/
	@Test
	public void testRemove() {
		SortedList<String> list = new SortedList<String>();

		// Test removing from an empty list
		try {
			list.remove(0);
		} catch (IndexOutOfBoundsException e) {
			// should not remove from an empty list
		}

		// Add some elements to the list - at least 4
		list.add("chips");
		list.add("water");
		list.add("apple");
		list.add("pears");
		list.add("cars");

		// TODO Test removing an element at an index < 0
		try {
			list.remove(-1);
		} catch (IndexOutOfBoundsException e) {
			// should enter a valid array index for removing
		}

		// Test removing an element at size 3
		list.remove(3);
		assertEquals(4, list.size());

		// Test removing a middle element
		list.remove(1);
		assertEquals(3, list.size());

		// Test removing the last element
		list.remove(2);
		assertEquals(2, list.size());

		// Test removing the first element
		list.remove(0);
		assertEquals(1, list.size());

		// Test removing the last element
		list.remove(0);
		assertEquals(0, list.size());

	}

	/**
	 * Tests indexOf method in SortedList
	 */
	@Test
	public void testIndexOf() {
		SortedList<String> list = new SortedList<String>();

		// Test indexOf on an empty list
		assertEquals(-1, list.indexOf("apple"));

		// Adding some elements
		list.add("apple");
		list.add("banana");
		list.add("carrot");

		// Testing Indices for elements in and not in the list
		assertEquals(0, list.indexOf("apple"));
		assertEquals(1, list.indexOf("banana"));
		assertEquals(2, list.indexOf("carrot"));

		// Checking the index of null
		try {
			list.indexOf(null);
			fail();
		} catch (NullPointerException e) {
			// Null should not be a valid call
		}
	}

	/**
	 * Tests clearing the SortedList with clear() method
	 */
	@Test
	public void testClear() {
		SortedList<String> list = new SortedList<String>();

		// Adding some elements to the list
		list.add("one");
		list.add("two");
		list.add("three");

		// Check the list has elements
		assertEquals(list.size(), 3);

		// Clearing list with clear() method
		list.clear();

		// Checking to see that the list is empty
		assertEquals(list.size(), 0);
	}

	/**
	* Test the sorted list is empty 
	*/
	@Test
	public void testIsEmpty() {
		SortedList<String> list = new SortedList<String>();

		// Test that the list starts empty
		assertEquals(0, list.size());

		// Add one element
		list.add("water");

		// Check that the list is no longer empty
		assertEquals(1, list.size());
	}

	/**
	 * Tests contains method in SortedList
	 */
	@Test
	public void testContains() {
		SortedList<String> list = new SortedList<String>();

		// Testing a null Sorted List
		assert (!list.contains("apple"));
		assert (!list.contains("banana"));
		assert (!list.contains("carrot"));

		// Adding some elements
		list.add("apple");
		list.add("banana");
		list.add("carrot");

		// Testing true and false cases
		assertTrue(list.contains("apple"));
		assertTrue (list.contains("banana"));
		assertTrue (list.contains("carrot"));
		assertFalse (list.contains("zebra"));
		assertFalse (list.contains("melon"));
	}

	/** Tests if two SortedLists are equal using the equals() method */
	@Test
	public void testEquals() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();

		// Make two lists the same and one list different
		list1.add("one");
		list2.add("one");
		list3.add("two");

		// Test for equality and non-equality
		assertEquals(list1.equals(list2), true);
		assertEquals(list1.equals(list3), false);
		assertEquals(list3.equals(list2), false);
	}

	/**
	* Test the hash code method of the sorted list
	*/
	@Test
	public void testHashCode() {
		SortedList<String> list1 = new SortedList<String>();
		SortedList<String> list2 = new SortedList<String>();
		SortedList<String> list3 = new SortedList<String>();

		// Make two lists the same and one list different
		list1.add("chips");
		list1.add("water");
		list1.add("apple");
		list1.add("pears");
		list1.add("cars");
		list2.add("chips");
		list2.add("water");
		list2.add("apple");
		list2.add("pears");
		list2.add("cars");
		list3.add("cheqips");
		list3.add("watwdaer");
		list3.add("appdale");
		list3.add("pearsdas");
		list3.add("cadawrs");

		// Test for the same and different hashCodes
		assertEquals(list1.hashCode(), list2.hashCode());
		assertNotEquals(list2.hashCode(), list3.hashCode());
		assertNotEquals(list1.hashCode(), list3.hashCode());

	}

}