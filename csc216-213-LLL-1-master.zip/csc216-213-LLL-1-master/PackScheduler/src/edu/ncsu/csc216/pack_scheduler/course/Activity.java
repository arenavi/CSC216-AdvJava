package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Contains state and methods for Activity superclass.
 * @author Andrew Hensley
 */
public abstract class Activity implements Conflict {

	/** Course's title. */
	private String title;
	/** Course's meeting days */
	private String meetingDays;
	/** Course's starting time */
	private int startTime;
	/** Course's ending time */
	private int endTime;
	/** max time in 24 hour cycle */
	private static final int UPPER_TIME = 2359; 
	/** max credit hours */
	private static final int UPPER_HOUR = 59; 

	/**
	 * Constructs activity Object with title, meeting days, start time, and end time
	 * @param title title to be set
	 * @param meetingDays meeting days to be set
	 * @param startTime start time to be set
	 * @param endTime end time to be set
	 */
	public Activity(String title, String meetingDays, int startTime, int endTime) {
		setTitle(title);
		setMeetingDays(meetingDays);
		setActivityTime(startTime, endTime);
	}

	/**
	 * Generates hash code on start time, end time, meeting days and title
	 * @return integer representing hash code
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + endTime;
		result = prime * result + ((meetingDays == null) ? 0 : meetingDays.hashCode());
		result = prime * result + startTime;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	/**
	 * Tests activities for equality on start time, end time, meeting days, and title
	 * @return true if equal, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Activity other = (Activity) obj;
		if (endTime != other.endTime)
			return false;
		if (meetingDays == null) {
			if (other.meetingDays != null)
				return false;
		} else if (!meetingDays.equals(other.meetingDays))
			return false;
		if (startTime != other.startTime)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	/**
	 * Gets the Activity's title.
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the Activity's title. If the title is null or empty, an
	 * IllegalArgumentException is thrown.
	 * @param title the title to be set
	 * @throws IllegalArgumentException
	 *             if title is null or empty.
	 */
	public void setTitle(String title) {
		if (title == null) {
			throw new IllegalArgumentException("Invalid title");
		}
		if (title.equals("")) {
			throw new IllegalArgumentException("Invalid title");
		}
		this.title = title;
	}

	/**
	 * Gets the Activity's meeting days
	 * 
	 * @return the meetingDays
	 */
	public String getMeetingDays() {
		return meetingDays;
	}

	/**
	 * Sets Activity's meeting days
	 * @param meetingDays meeting days to be set
	 * @throws IllegalArgumentException if meeting days are null
	 * @throws IllegalArgumentException if meeting days are empty
	 */
	public void setMeetingDays(String meetingDays) {
		if (meetingDays == null) {
			throw new IllegalArgumentException("Invalid meeting days");
		}
		if (meetingDays.equals("")) {
			throw new IllegalArgumentException("Invalid meeting days");
		}
		this.meetingDays = meetingDays;
	}

	/**
	 * Gets the Actvity's start time
	 * 
	 * @return the startTime
	 */
	public int getStartTime() {
		return startTime;
	}

	/**
	 * Gets the Activity's end time
	 * 
	 * @return the endTime
	 */
	public int getEndTime() {
		return endTime;
	}

	/**
	 * Sets the Activity's start and end times. If an invalid military time is
	 * given, the class ends before it begins, or if the class meeting is A and
	 * either time is nonzero, an IllegalArgumentException is thrown
	 * 
	 * @param startTime the startTime to set
	 * @param endTime the endTime to set
	 * @throws IllegalArgumentException if an non 24-hour time is given
	 * @throws IllegalArgumentException if minutes are greater than 59
	 * @throws IllegalArgumentException if endTime is less than startTime
	 * @throws IllegalArgumentException if meetingDays = "A" and nonzero times are given
	 */
	public void setActivityTime(int startTime, int endTime) {
		if (startTime < 0 || endTime < 0 || startTime > UPPER_TIME || endTime > UPPER_TIME) {
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if (startTime % 100 > UPPER_HOUR || endTime % 100 > UPPER_HOUR) {
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if (endTime < startTime) {
			throw new IllegalArgumentException("Invalid meeting times");
		}
		if (meetingDays.equals("A") && (startTime != 0 || endTime != 0)) {
				throw new IllegalArgumentException("Invalid meeting times");
		}
		this.startTime = startTime;
		this.endTime = endTime;
	}

	/**
	 * Gives meeting days and time as string
	 * @return string of meeting days and time
	 */
	public String getMeetingString() {
		String s = "";
		if (meetingDays.equalsIgnoreCase("A")) {
			s += "Arranged";
		} else {
			s += meetingDays + " ";
			if (startTime >= 100) {
				int sTemp = startTime / 100;
				if (startTime % 100 == 0) {
					if (sTemp % 12 == 0) {
						s += "12:00";
					}
					else {
						s += sTemp % 12 + ":00";
					}
				} else if (startTime % 100 < 10) {
					if (sTemp % 12 == 0) {
						s += "12:0" + (startTime % 100);
					}
					else {
						s += sTemp % 12 + ":0" + (startTime % 100);
					}
				} else {
					if (sTemp % 12 == 0) {
						s += "12:" + (startTime % 100);
					}
					else {
						s += sTemp % 12 + ":" + (startTime % 100);
					}
				}
				if (startTime < 1200) {
					s += "AM";
				} else {
					s += "PM";
				}
				s += "-";
				int eTemp = endTime / 100;
				if (endTime % 100 == 0) {
					if (eTemp % 12 == 0) {
						s += "12:00";
					}
					else {
						s += eTemp % 12 + ":00";
					}
				} else if (endTime % 100 < 10) {
					if (eTemp % 12 == 0) {
						s += "12:0" + (endTime % 100);
					}
					else {
						s += eTemp % 12 + ":0" + (endTime % 100);
					}
				} else {
					if (eTemp % 12 == 0) {
						s += "12:" + (endTime % 100);
					}
					else {
						s += eTemp % 12 + ":" + (endTime % 100);
					}
				}
				if (endTime < 1200) {
					s += "AM";
				} else {
					s += "PM";
				}
			} else {
				if (startTime == 0) {
					s += "12:00AM-";
				} else if (startTime < 10) {
					s += "12:0" + startTime + "AM-";
				} else {
					s += "12:" + startTime + "AM-";
				}
				if (endTime > 100) {
					int eTemp = endTime / 100;
					if (endTime % 100 == 0) {
						if (eTemp % 12 == 0) {
							s += "12:00";
						}
						else {
							s += eTemp % 12 + ":00";
						}
					} else if (endTime % 100 < 10) {
						if (eTemp % 12 == 0) {
							s += "12:0" + (endTime % 100);
						}
						s += eTemp % 12 + ":0" + (endTime % 100);
					} else {
						if (eTemp % 12 == 0) {
							s += "12:" + (endTime % 100);
						}
						else {
							s += eTemp % 12 + ":" + (endTime % 100);
						}
					}
					if (endTime < 1200) {
						s += "AM";
					} else {
						s += "PM";
					}
				} else {
					if (endTime == 0) {
						s += "12:00AM";
					} else if (endTime < 10) {
						s += "12:0" + endTime + "AM";
					} else {
						s += "12:" + endTime + "AM";
					}
				}
			}
		}
		return s;
	}
	
	/**
	 * Returns short array containing state variables for Event or Course (implementation
	 * in those classes).
	 * @return the array to be returned
	 */
	public abstract String[] getShortDisplayArray();
	/**
	 * Returns long array containing state variables for Event or Course (implementation
	 * in those classes).
	 * @return the array to be returned 
	 */
	public abstract String[] getLongDisplayArray();
	/**
	 * Tests Activity for duplication (implementation in Event and Course classes).
	 * @param activity activity to be compared for duplication
	 * @return true if duplicate, false otherwise
	 */
	public abstract boolean isDuplicate(Activity activity);

	/**
	 * Checks for time conflict between this and another activity
	 * @param possibleConflictingActivity activity that may conflict
	 * @throws ConflictException if times overlap on the same day
	 */
	@Override
	public void checkConflict(Activity possibleConflictingActivity) throws ConflictException {
		boolean common = false;
		for (int i = 0; i < this.meetingDays.length(); i++) {
		    char c = this.meetingDays.charAt(i);
		    if (possibleConflictingActivity.getMeetingDays().indexOf(c) != -1) {
		        common = true;
		    }
		}
		if (common && !this.meetingDays.contains("A") &&
				!possibleConflictingActivity.getMeetingDays().contains("A")) {
			int t1 = possibleConflictingActivity.getStartTime();
			int t2 = possibleConflictingActivity.getEndTime();
			if (t1 >= this.startTime && t1 <= this.endTime) {
				throw new ConflictException();
			}
			if (this.startTime >= t1 && this.startTime <= t2) {
				throw new ConflictException();
			}
		}
		
	}

}