/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;


import java.util.AbstractList;
import java.util.Arrays;

/**
 * Custom ArrayList
 * @author Andrew Hensley and Luke Hansen
 * @param <E> arbitrary object
 */
public class ArrayList<E> extends AbstractList<E> {

	/** Default size */
	private static final int INIT_SIZE = 2;
	/** Array of objects */
	private E[] list;
	/** Size of ArrayList */
	private int size;

	/**
	 * Generates ArrayList with default capacity of 2
	 */
	@SuppressWarnings("unchecked")
	public ArrayList() {
		list = (E[]) (new Object[INIT_SIZE]);
		size = 0;
	}

	/**
	 * Returns object at index idx
	 * @param idx index to get from
	 * @return the object
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 */
	public E get(int idx) {
		if (idx >= size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		return list[idx];
	}

	/**
	 * Returns number of objects in ArraList
	 * @return the number
	 */
	public int size() {
		return size;
	}

	
	/**
	 * Adds object at index idx
	 * @param idx the index
	 * @param object the object to be added
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is duplicate
	 */
	public void add(int idx, E object) {
		if (object == null) {
			throw new NullPointerException();
		}
		if (idx > size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		for (int i = 0; i < size; i++) {
			if (object.equals(list[i])) {
				throw new IllegalArgumentException();
			}
		}
		if (list.length == size) {
			growArray();
		}
		
		for (int i = size - 1; i >= idx; i--) {
			list[i + 1] = list[i];
		}
		list[idx] = object;
		size++;
	}
	
	/**
	 * Sets the element at index idx to Object object
	 * @param idx index to be set
	 * @param object object to be set
	 * @return the old object
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is duplicate
	 */
	public E set(int idx, E object) {
		if (object == null) {
			throw new NullPointerException();
		}
		if (idx > size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		if (idx == 0 && size == 0) {
			throw new IndexOutOfBoundsException();
		}
		for (int i = 0; i < size; i++) {
			if (object.equals(list[i])) {
				throw new IllegalArgumentException();
			}
		}
		if (idx == size) {
			add(idx, object);
		}
		E ret = list[idx];
		list[idx] = object;
		return ret;
		
	}

	/**
	 * Removes object at index idx
	 * @param idx the index
	 * @return the object removed
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 */
	public E remove(int idx) {
		if (idx >= size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		E ret = list[idx];
		for(int i = idx; i < size - 1; i++) {
			list[i] = list[i + 1];
		}
		size--;
		return ret;
	}
	
	/**
	 * Doubles the size of the array
	 */
	private void growArray() {
		int newCapacity = list.length * 2 + 1;
		list = Arrays.copyOf(list, newCapacity);
	}
}