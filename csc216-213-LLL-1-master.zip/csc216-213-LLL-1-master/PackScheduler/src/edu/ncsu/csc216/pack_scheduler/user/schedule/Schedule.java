package edu.ncsu.csc216.pack_scheduler.user.schedule;

import edu.ncsu.csc216.pack_scheduler.course.ConflictException;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.util.ArrayList;

/**
 * Schedule for Course objects
 * @author Andrew Hensley
 */
public class Schedule {
	/** Title of Schedule */
	private String title;
	/** Courses in Schedule */
	private ArrayList<Course> schedule;
	
	/**
	 * Constructs empty schedule with default name
	 */
	public Schedule() {
		setTitle("My Schedule");
		schedule = new ArrayList<Course>();
	}
	
	/**
	 * Add Course to schedule
	 * @param course course to be added
	 * @return true if it's added, false otherwise
	 * @throws IllegalArgumentException if course is a duplicate, or causes conflict
	 */
	public boolean addCourseToSchedule(Course course) {
		try {
			for (int i = 0; i < schedule.size(); i++) {
				if (course.isDuplicate(schedule.get(i)) || course.equals(schedule.get(i))) {
					throw new IllegalArgumentException("You are already enrolled in " + course.getName());
				}
				course.checkConflict(schedule.get(i));
				
			}
			
			schedule.add(schedule.size(), course);
			return true;
		}
		catch (ConflictException e) {
			throw new IllegalArgumentException("The course cannot be added due to a conflict.");
		}
		
	}
	
	/**
	 * Removes course from schedule
	 * @param course course to be removed
	 * @return true if it's removed, false otherwise
	 */
	public boolean removeCourseFromSchedule(Course course) {
		if (course == null) {
			return false;
		}
		for (int i = 0; i < schedule.size(); i++) {
			if (course.equals(schedule.get(i))) {
				schedule.remove(i);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Resets schedule
	 */
	public void resetSchedule() {
		schedule = new ArrayList<Course>();
	}
	
	/**
	 * Returns array of scheduled courses containing name, section,
	 * time, and meeting days string
	 * @return the array
	 */
	public String[][] getScheduledCourses() {
		String[][] ret = new String [schedule.size()][4];
		for (int i = 0; i < schedule.size(); i++) {
			ret[i] = schedule.get(i).getShortDisplayArray();
		}
		return ret;
	}
	
	/**
	 * Sets title
	 * @param title the title
	 * @throws IllegalArgumentException if title is null or empty
	 */
	public void setTitle(String title) {
		if (title == null || title.equals("")) {
			throw new IllegalArgumentException("Invalid title.");
		}
		this.title = title;
	}
	
	/**
	 * Returns title
	 * @return title to be returned
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * Sums credits in schedule
	 * @return credits total scheduled credits
	 */
	public int getScheduleCredits() {
		int sum = 0;
		for (int i = 0; i < schedule.size(); i++) {
			sum += schedule.get(i).getCredits();
		}
		return sum;
	}
	
	/**
	 * Checks whether a course can be added to schedule
	 * @param course course to be added
	 * @return whether given course can be added
	 */
	public boolean canAdd(Course course) {
		if (course == null) {
			return false;
		}
		try {
			for (int i = 0; i < schedule.size(); i++) {
				if (course.isDuplicate(schedule.get(i)) || course.equals(schedule.get(i))) {
					throw new IllegalArgumentException("You are already enrolled in " + course.getName());
				}
				course.checkConflict(schedule.get(i));
				
				
			}
			return true;
		}
		catch (ConflictException e) {
			return false;
		} catch (IllegalArgumentException x) {
			return false;
		}
	}
	
}
