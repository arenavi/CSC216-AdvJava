/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractSequentialList;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Linked List for the PackScheduler.
 * @author Amiya
 * @param <E> arbitrary object
 */
public class LinkedList<E> extends AbstractSequentialList<E> {

    /** Front */
    private ListNode front;
    
    /** Back */
    private ListNode back;
    
    /** Size */
    private int size;
    
    /**
     * Constructs the LinkedList class.
     */
    public LinkedList() {
        front = new ListNode(null);
        back = new ListNode(null, front, null);
        front.next = back;
        size = 0;
    }
    
    /**
     * Creates ListIterator at given index
     * @param index index of ListIterator
     */
    @Override
    public ListIterator<E> listIterator(int index) {
        LinkedListIterator it = new LinkedListIterator(index);
        return it;
    }

    /* (non-Javadoc)
     * @see java.util.AbstractSequentialList#add(int, java.lang.Object)
     */
    @Override
    public void add(int index, E element) {
    	if(index > size || index < 0) {
    		throw new IndexOutOfBoundsException();
    	}
        ListIterator<E> list = listIterator(0);
        for(int i = 0; i < size; i++) {
        	if(list.next().equals(element)) {
        		throw new IllegalArgumentException();
        	}
        }
        list = listIterator(0);
        for(int i = 0; i < index; i++) {
        	list.next();
        }
        list.add(element);
    }

    /* (non-Javadoc)
     * @see java.util.AbstractSequentialList#set(int, java.lang.Object)
     */
    @Override
    public E set(int index, E element) {
    	if(index >= size) {
    		throw new IndexOutOfBoundsException();
    	}
    	ListIterator<E> list = listIterator(0);
        for(int i = 0; i < size; i++) {
        	if(list.next().equals(element)) {
        		throw new IllegalArgumentException();
        	}
        }
        return super.set(index, element);
    }

    /* (non-Javadoc)
     * @see java.util.AbstractCollection#size()
     */
    @Override
    public int size() {
        return size;
    }
    
    @Override
    public E get(int idx) {
    	ListIterator<E> list = listIterator(idx);
    	if(!list.hasNext()) {
    		throw new IndexOutOfBoundsException();
    	}
    	E data = list.next();
    	list.previous();
    	return data;
    }
    

    /**
     * Serves as a private inner class.
     * @author Amiya, Andrew, Joshua
     */
    private class ListNode {
       
        /** Data in the node */
        private E data;
        
        /** Next node in the list */
        private ListNode next;
        
        /** Previous node in the list */
        private ListNode prev;
        
        public ListNode (E data) {
            this(data, null, null);    
        }
        
        public ListNode (E data, ListNode prev, ListNode next) {
            this.data = data;
            this.prev = prev;
            this.next = next;
        }
        
        
    }
    
    /**
     * LinkedlistIterator class.
     * @author Andrew, Amiya, and Joshua
     *
     */
    private class LinkedListIterator implements ListIterator<E> {

        public ListNode previous;
        
        public ListNode next;
        
        public int previousIndex;
        
        public int nextIndex;
        
        private ListNode lastRetrieved; 
        
        public LinkedListIterator(int index) { 
            if (index < 0 || index > size) {
                throw new IndexOutOfBoundsException();    
            }
            previous = front;
            next = previous.next;
            for (int i = 0; i < index; i++) {
                previous = next;
                next = next.next;
            }
            
            previousIndex = index - 1;
            nextIndex = index;
            
            lastRetrieved = null;
         }
        
        @Override
        public boolean hasNext() { 
        	if(next == null) {
        		return false;
        	}
            return next.data != null;
        }

        @Override
        public E next() {
        	if(next.data == null) {
        		throw new NoSuchElementException();
        	}
            lastRetrieved = next;
            E data = next.data;
            next = next.next;
            previous = previous.next;
            return data;
        }

        @Override
        public boolean hasPrevious() {
            return previous != null;
        }

        @Override
        public E previous() {
        	if(previous.data == null) {
        		throw new NoSuchElementException();
        	}
            lastRetrieved = previous;
            E data = previous.data;
            previous = previous.prev;
            next = next.prev;
            return data;
        }

        @Override
        public int nextIndex() {
            return nextIndex;
        }

        @Override
        public int previousIndex() {
            return previousIndex;
        }

        @Override
        public void remove() {
            if (lastRetrieved == null) {
                throw new IllegalStateException();
            }
            
            lastRetrieved.prev.next = lastRetrieved.next;
            size--;
        }

        @Override
        public void set(E e) {
            if (lastRetrieved == null) {
                throw new IllegalStateException();
            }
            
            if (e == null) {
                throw new NullPointerException();
            }
            
            lastRetrieved.data = e;
        }

        @Override
        public void add(E e) {
        	if (front == null) {
        		front = new ListNode(e, null, null);
        	}
            if (e == null) {
                throw new NullPointerException();
            }
            ListNode temp = new ListNode(e, previous, next);
            previous.next = temp;
            next = temp;
            size++;
            lastRetrieved = null;
        }
        
    
    
    }

    
   
}
