/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;


/**
 * Implementation of LinkedList with recursive methods
 * @author Andrew, Amiya, and Joushua
 * @param E data
 */
public class LinkedListRecursive<E> {
	
    /** Front listnode */
	private ListNode front;
	
	/** Size */
	private int size;
	
	/**
	 * Sets front to null and size to 0.
	 */
	public LinkedListRecursive() {
		front = null;
		size = 0;
	}
	
	/**
	 * Returns the size of the list.
	 * @return size size of the list
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Returns size equal to 0.
	 * @return size equal to 0
	 */
	public boolean isEmpty() {
		return size == 0;
	}
	
	/**
	 * Returns whether or not list contains certain data
	 * @param data the data
	 * @return true if it does, false otherwise
	 */
	public boolean contains(E data) {
		if (isEmpty()) {
			return false;
		}
		return front.contains(data);
	}
	
	/**
	 * Adds an an element with given data to the list
	 * @param data the data
	 * @return tru if added, false otherwise
	 */
	public boolean add(E data) {
		if(contains(data)) {
			throw new IllegalArgumentException();
		}
		if(data == null) {
			throw new NullPointerException();
		}
		if (front == null) {
			front = new ListNode(data, null);
			size++;
			return true;
		} else {
			return front.add(data);
		}
	}
	
	/**
	 * Adds data at a given index
	 * @param idx the index
	 * @param data the data
	 */
	public void add(int idx, E data) {
		if(contains(data)) {
			throw new IllegalArgumentException();
		}
		if(data == null) {
			throw new NullPointerException();
		}
		if (idx == 0) {
			front = new ListNode(data, front);
			size++;
		} else if (idx > size || idx < 0) {
			throw new IndexOutOfBoundsException();
		} else {
			front.add(idx - 1, data);
		}
	}
	
	/**
	 * Returns data at given index
	 * @param idx the index
	 * @return the data
	 */
	public E get(int idx) {
		if(idx < 0 || idx >= size) {
			throw new IndexOutOfBoundsException();
		}
		if (idx == 0) {
			return front.data;
		} else if (front == null) {
			return null;
		} else {
			return front.get(idx - 1);
		}
	}
	
	/**
	 * Removes element at given index
	 * @param idx the index
	 * @return the removed element
	 */
	public E remove(int idx) {
		if(idx >= size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		if (idx == 0) {
			E data = front.data;
			front = front.next;
			size--;
			return data;
		} else if (front == null) {
			throw new IllegalArgumentException();
		} else {
			return front.remove(idx - 1);
		}
	}
	
	/**
	 * Removes element with given data
	 * @param data the data
	 * @return true if removed, false otherwise
	 */
	public boolean remove(E data) {
		if(data == null) {
			return false;
		}
		if(isEmpty()) {
			return false;
		}
		if(front.data.equals(data)) {
			front = front.next;
			size--;
			return true;
		}
		
		return front.remove(data);
	}
	
	/**
	 * Sets the data of an element at given index
	 * @param idx the index
	 * @param data data to be set
	 * @return replaced data
	 */
	public E set (int idx, E data) {
		if(contains(data)) {
			throw new IllegalArgumentException();
		}
		if(data == null) {
			throw new NullPointerException();
		}
		if(idx >= size || idx < 0) {
    		throw new IndexOutOfBoundsException();
    	}
		if (idx == 0) {
			E ret = front.data;
			front.data = data;
			return ret;
		} else if (front == null) {
			throw new IllegalArgumentException();
		} else {
			return front.set(idx - 1, data);
		}
	}
	
	
	/**
	 * Individual node in LinkedList
	 * @author Andrew, Amiya, and Joshua
	 *
	 */
	public class ListNode {
		/** Data in the node */
        private E data;
        
        /** Next node in the list */
        private ListNode next;

        /**
         * Constructs ListNode on data and next node
         * @param data the data
         * @param next the next node
         */
        public ListNode (E data, ListNode next) {
            this.data = data;
            this.next = next;
        }
        
        private boolean contains(E data) {

        	ListNode current = this;
        	if(current.next == null) {
        		return false;
        	}
    		if (current.data == data) {
    			return true;
    		}
    		current = current.next;
    		return current.contains(data);
    	}
        
        private boolean add(E data) {
        	if (next == null) {
        		next = new ListNode(data, null);
        		size++;
        		return true;
        	}
        	else {
        		return next.add(data);
        	}
        }
        
        private void add(int idx, E data) {
        	if (idx < 0) {
        		throw new IllegalArgumentException();
        	} else if (idx == 0) {
        		size++;
        		next = new ListNode(data, next);
        	} else {
        		if (next == null) {
        			throw new IllegalArgumentException();
        		} else {
        			next.add(idx - 1, data);
        		}
        	}
        }
        
        private E get(int idx) {
        	if (next == null) {
    			throw new IndexOutOfBoundsException();
    		}
        	if (idx < 0) {
        		throw new IllegalArgumentException();
        	} else if (idx == 0) {
        		return next.data;
        	} else {
    			return next.get(idx - 1);
        	}
        }
        
        private E remove (int idx) {
        	if (idx < 0) {
        		throw new IllegalArgumentException();
        	} else if (idx == 0) {
        		E ret = next.data;
        		next = next.next;
        		size--;
        		return ret;
        	} else {
        		if (next == null) {
        			throw new IllegalArgumentException();
        		} else {
        			return next.remove(idx - 1);
        		}
        	}
        }
        
        private boolean remove(E data) {
        	if(next.data.equals(data)) {
        		next = next.next;
        		size--;
        		return true;
        	} else {
        		if(next.next == null) {
        			return false;
        		} else {
        			return next.remove(data);
        		}
        	}
        }
        
        private E set(int idx, E data) {
        	if (idx < 0) {
        		throw new IllegalArgumentException();
        	} else if (idx == 0) {
        		E ret = next.data;
        		next.data = data;
        		return ret;
        	} else {
        		if (next == null) {
        			throw new IllegalArgumentException();
        		} else {
        			return next.set(idx - 1, data);
        		}
        	}
        }
	}
}
