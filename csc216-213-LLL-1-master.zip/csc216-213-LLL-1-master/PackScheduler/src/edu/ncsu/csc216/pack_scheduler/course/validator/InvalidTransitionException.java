/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

/**
 * Class for transition exceptions in FSM class
 * @author Andrew Hensley, Luke Hansen
 */
public class InvalidTransitionException extends Exception {
	/** ID used for serialization. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructs ConflictException with message
	 * @param message the message to be displayed
	 */
	public InvalidTransitionException(String message) {
		super(message);
	}
	
	/**
	 * Constructs ConflictException with default message
	 */
	public InvalidTransitionException() {
		super("Invalid FSM Transition.");
	}
}