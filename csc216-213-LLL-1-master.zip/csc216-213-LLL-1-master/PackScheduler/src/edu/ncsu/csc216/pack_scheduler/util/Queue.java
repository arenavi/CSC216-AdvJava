/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

/**
 * Implements Queue data structure
 * @author Andrew, Amiya, and Joshua
 * @param <E> arbitrary object
 */
public interface Queue<E> {

	/**
	 * Adds element to back of queue
	 * @param element element to be added
	 */
	void enqueue(E element);
	
	/**
	 * Returns value from front of queue
	 * @return the value
	 */
	E dequeue();
	
	/**
	 * returns whether or not queue is empty
	 * @return true if empty, false otherwise
	 */
	boolean isEmpty();
	
	/**
	 * Returns size of queue
	 * @return the size
	 */
	int size();
	
	/**
	 * Sets capacity of the queue
	 * @param capacity capacity to be set
	 */
	void setCapacity(int capacity);
}
