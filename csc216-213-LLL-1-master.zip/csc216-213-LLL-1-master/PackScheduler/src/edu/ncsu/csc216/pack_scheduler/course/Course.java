/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

import edu.ncsu.csc216.pack_scheduler.course.roll.CourseRoll;
import edu.ncsu.csc216.pack_scheduler.course.validator.CourseNameValidator;
import edu.ncsu.csc216.pack_scheduler.course.validator.InvalidTransitionException;

/**
 * Class generating Course objects
 * 
 * @author Andrew Hensley
 */
public class Course extends Activity implements Comparable<Course> {

	/** Course's name. */
	private String name;
	/** Course's section. */
	private String section;
	/** Course's credit hours */
	private int credits;
	/** Course's instructor */
	private String instructorId;
	/** Proper length of course section */
	private static final int SECTION_LENGTH = 3;
	/** Maximum name length */
	private static final int MAX_NAME_LENGTH = 6;
	/** Minimum name length */
	private static final int MIN_NAME_LENGTH = 4;
	/** Maximum allowed credit hours */
	private static final int MAX_CREDITS = 5;
	/** Minimum allowed credits hours */
	private static final int MIN_CREDITS = 1;
	/** Course Validator */
	private CourseNameValidator validator = new CourseNameValidator();
	/** Course roll */
	private CourseRoll roll;

	/**
	 * Returns the Course's name
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the Course's name. If the name is null, has a length less than 4 or
	 * greater than 6, an IllegalArgumentException is thrown.
	 * 
	 * @param name
	 *            the name to set
	 * @throws InvalidTransitionException
	 * @throws IllegalArgumentException
	 *             if name is null or length is less than 4 or greater than 6
	 */
	private void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (name.length() < MIN_NAME_LENGTH
				|| name.length() > MAX_NAME_LENGTH) {
			throw new IllegalArgumentException("Invalid name");
		}
		try {
			if (!validator.isValid(name)) {
				throw new IllegalArgumentException("Invalid name");
			}
		}
		catch (InvalidTransitionException e) {
			throw new IllegalArgumentException();
		}
		this.name = name;

	}

	/**
	 * Gets the Course's section
	 * 
	 * @return the section
	 */
	public String getSection() {
		return section;
	}

	/**
	 * Sets the Course's section. If the section is not of length 3, an
	 * IllegalArgumentException is thrown.
	 * 
	 * @param section
	 *            the section to set
	 * @throws IllegalArgumentException
	 *             if section is null
	 * @throws IllegalArgumentException
	 *             if section length is not 3
	 */
	public void setSection(String section) {
		if (section == null) {
			throw new IllegalArgumentException("Invalid section");
		}
		if (section.length() != SECTION_LENGTH) {
			throw new IllegalArgumentException("Invalid section");
		}
		this.section = section;
	}

	/**
	 * Gets the Course's credits
	 * 
	 * @return the credits
	 */
	public int getCredits() {
		return credits;
	}

	/**
	 * Sets the Course's credits. If less than one credit hour or more than 5
	 * credit hours, an IllegalArgumentException is thrown.
	 * 
	 * @param credits
	 *            the credits to set
	 * @throws IllegalArgumentException
	 *             if credits is less than one or more than 5
	 */
	public void setCredits(int credits) {
		if (credits < MIN_CREDITS || credits > MAX_CREDITS) {
			throw new IllegalArgumentException();
		}
		this.credits = credits;
	}

	/**
	 * Gets the Course's instructor ID
	 * 
	 * @return the instructorId
	 */
	public String getInstructorId() {
		return instructorId;
	}

	/**
	 * Sets the Course's instructor ID. If instructor id is null or empty, an
	 * IllegalArgumentException is thrown
	 * 
	 * @param instructorId
	 *            the instructorId to set
	 * @throws IllegalArgumentException
	 *             is instructorId is null or empty
	 */
	public void setInstructorId(String instructorId) {
		if (instructorId != null && instructorId.equals("")) {
			throw new IllegalArgumentException("Invalid instructor id");
		}
		this.instructorId = instructorId;
	}

	/**
	 * Constructs a Course object with values for all fields
	 * 
	 * @param name
	 *            name of Course
	 * @param title
	 *            title of Course
	 * @param section
	 *            section of Course
	 * @param credits
	 *            credit hours of Course
	 * @param instructorId
	 *            instructor's unity id
	 * @param enrollmentCap enrollment cap for the Course
	 * @param meetingDays
	 *            meeting days for course as series of chars
	 * @param startTime
	 *            start time for the course
	 * @param endTime
	 *            end time for the course
	 */
	public Course(String name, String title, String section, int credits,
			String instructorId, int enrollmentCap, String meetingDays, int startTime, int endTime) {
		super(title, meetingDays, startTime, endTime);
		setName(name);
		setSection(section);
		setCredits(credits);
		setInstructorId(instructorId);
		roll = new CourseRoll(this, enrollmentCap);
	}

	/**
	 * Creates a Course with the given name, title, section, credits,
	 * instructorId, and meetingDays for courses that are arranged.
	 * 
	 * @param name
	 *            name of Course
	 * @param title
	 *            title of Course
	 * @param section
	 *            section of Course
	 * @param credits
	 *            credit hours of Course
	 * @param instructorId
	 *            instructor's unity id
	 * @param enrollmentCap enrollment cap for the Course
	 * @param meetingDays
	 *            meeting days for course as series of chars
	 */
	public Course(String name, String title, String section, int credits,
			String instructorId, int enrollmentCap, String meetingDays) {
		this(name, title, section, credits, instructorId, enrollmentCap,
				meetingDays, 0, 0);
		roll = new CourseRoll(this, enrollmentCap);
	}

	/**
	 * Sets the Course's meeting days. If meeting days are null or empty,
	 * contain A in addition to another character, or contains something other
	 * than, M, T, W, H, or F, an IllegalArgumentException is thrown.
	 * 
	 * @param meetingDays
	 *            the meetingDays to set
	 * @throws IllegalArgumentException
	 *             if meetingDays are null
	 * @throws IllegalArgumentException
	 *             if meetingDays is empty
	 * @throws IllegalArgumentException
	 *             if meetingDays contain A in addition to another character
	 * @throws IllegalArgumentException
	 *             if meetingDays contains no A and something other than, M, T,
	 *             W, H, or F
	 */
	@Override
	public void setMeetingDays(String meetingDays) {
		if (meetingDays == null) {
			throw new IllegalArgumentException("Invalid meeting days");
		}
		if (meetingDays.equals("")) {
			throw new IllegalArgumentException("Invalid meeting days");
		}
		if (meetingDays.contains("A") && meetingDays.length() > 1) {
			throw new IllegalArgumentException();
		} else if (!meetingDays.contains("A")) {
			for (int i = 0; i < meetingDays.length(); i++) {
				if (meetingDays.charAt(i) != 'M' && meetingDays.charAt(i) != 'T'
						&& meetingDays.charAt(i) != 'W'
						&& meetingDays.charAt(i) != 'H'
						&& meetingDays.charAt(i) != 'F') {
					throw new IllegalArgumentException();
				}
			}
		}
		super.setMeetingDays(meetingDays);
	}

	/**
	 * Returns a comma separated value String of all Course fields.
	 * 
	 * @return String representation of Course
	 */
	@Override
	public String toString() {
		if (getMeetingDays().equals("A")) {
			return name + "," + getTitle() + "," + section + "," + credits + ","
					+ instructorId + "," + roll.getEnrollmentCap() + "," + getMeetingDays();
		}
		return name + "," + getTitle() + "," + section + "," + credits + ","
				+ instructorId + "," + roll.getEnrollmentCap() + "," + getMeetingDays() + "," + getStartTime()
				+ "," + getEndTime();
	}

	/**
	 * Generates hash code on all fields
	 * 
	 * @return integer representing hash code
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + credits;
		result = prime * result
				+ ((instructorId == null) ? 0 : instructorId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		return result;
	}

	/**
	 * Tests to see if Courses are equivalent on all fields
	 * 
	 * @return true if equal, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (credits != other.credits)
			return false;
		if (instructorId == null) {
			if (other.instructorId != null)
				return false;
		} else if (!instructorId.equals(other.instructorId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} 
		else if (!section.equals(other.section))
			return false;
		return true;
	}

	/**
	 * Returns a String array containing name, section, title, and meeting days
	 * String
	 * 
	 * @return the array to be returned
	 */
	@Override
	public String[] getShortDisplayArray() {
		String open = Integer.toString(roll.getOpenSeats());
		String[] s = { name, section, getTitle(), getMeetingString(), open };
		return s;
	}

	/**
	 * Returns a String array containing all fields as well as a empty String
	 * 
	 * @return the array to be returned
	 */
	@Override
	public String[] getLongDisplayArray() {
		String[] s = { name, section, getTitle(), Integer.toString(credits),
				instructorId, getMeetingString(), "" };
		return s;
	}

	/**
	 * Determines if activity is duplicate
	 * 
	 * @return true if duplicate, false otherwise
	 */
	@Override
	public boolean isDuplicate(Activity activity) {
		if (!(activity instanceof Course)) {
			return false;
		}
		Course compare = (Course) activity;
		if (name.equals(compare.getName())) {
			return true;
		}
		return false;
	}

	/**
	 * Compares the ranking of Student objects
	 * 
	 * @return 1 if greater, -1 if less than, 0 otherwise
	 */
	@Override
	public int compareTo(Course course) {
		if (this.getName().compareTo(course.getName()) != 0) {
			if (this.getName().compareTo(course.getName()) > 0) {
				return 1;
			} else {
				return -1;
			}
		} else if (this.section.compareTo(course.section) != 0) {
			if (this.section.compareTo(course.section) > 0) {
				return 1;
			} else {
				return -1;
			}
		} else {
			return 0;
		}
	}

	/**
	 * Returns CourseRoll
	 * @return the roll
	 */
	public CourseRoll getCourseRoll() {
		return roll;
	}

}
