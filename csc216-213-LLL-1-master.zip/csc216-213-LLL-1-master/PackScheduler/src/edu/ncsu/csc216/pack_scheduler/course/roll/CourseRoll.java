/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.roll;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.Student;
import edu.ncsu.csc216.pack_scheduler.util.LinkedAbstractList;
import edu.ncsu.csc216.pack_scheduler.util.LinkedQueue;

/**
 * Course roll that holds the list of students enrolled in a course
 * @author Andrew Hensley and Luke Hansen
 */
public class CourseRoll {

	/** Roll of Students */
	private LinkedAbstractList<Student> roll;
	/** Enrollment Cap */
	private int enrollmentCap;
	/** Minimum class size */
	private static final int MIN_ENROLLMENT = 10;
	/** Maximum class size */
	private static final int MAX_ENROLLMENT = 250;
	/** Waitlist for the Course */
	private LinkedQueue<Student> waitlist;
	/**The Course the roll is for*/
	private Course course;
	
	/**
	 * Generates CourseRoll on enrollment cap
	 * @param c Course
	 * @param enrollmentCap the enrollment cap
	 */
	public CourseRoll(Course c, int enrollmentCap) {
		if (c == null) {
			throw new IllegalArgumentException();
		}
		roll = new LinkedAbstractList<Student>(1);
		waitlist = new LinkedQueue<Student>(10);
		setEnrollmentCap(enrollmentCap);
		course = c;
	}

	/**
	 * Sets enrollment cap
	 * @param enrollmentCap cap to be set
	 * @throws IllegalArgumentException if enrollment cap is out of bounds
	 * @throws IllegalArgumentException if enrollment cap smaller than roll
	 */
	public void setEnrollmentCap(int enrollmentCap) {
		if (enrollmentCap < MIN_ENROLLMENT || enrollmentCap > MAX_ENROLLMENT) {
			throw new IllegalArgumentException();
		}
		if (enrollmentCap < roll.size()) {
			throw new IllegalArgumentException();
		}
		this.enrollmentCap = enrollmentCap;
		roll.setCapacity(enrollmentCap);
	}

	/**
	 * Returns enrollment Cap
	 * @return the cap to be returned
	 */
	public int getEnrollmentCap() {
		return enrollmentCap;
	}
	
	/**
	 * Enrolls Student in course
	 * @param student the student to be enrolled
	 * @throws IllegalArgumentException if student is null
	 * @throws IllegalArgumentException if class is full
	 * @throws IllegalArgumentException if student is already in class
	 * @throws IllegalArgumentException if roll.add throws an Exception
	 */
	public void enroll(Student student) {
		if (student == null) {
			throw new IllegalArgumentException();
		}
		if (roll.size() == enrollmentCap && waitlist.size() == 10) {
			throw new IllegalArgumentException();
		}
		for (int i = 0; i < roll.size(); i++) {
			if (roll.get(i).equals(student)) {
				throw new IllegalArgumentException();
			}
		}
		try {
			if (roll.size() != enrollmentCap) {
				roll.add(roll.size(), student);
				student.getSchedule().addCourseToSchedule(course);
			}
			else {
				waitlist.enqueue(student);
				//student.getSchedule().addCourseToSchedule(course);
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 * Drops Student from roll
	 * @param student student to be dropped
	 * @throws IllegalArgumentException if student is null
	 * @throws IllegalArgumentException if roll.remove throws an exception
	 */
	public void drop(Student student) {
		if (student == null) {
			throw new IllegalArgumentException();
		}
		try {
			for(int i = 0; i < roll.size(); i++) {
				if(roll.get(i).equals(student)) {
					roll.remove(i);
				}
			}
			for(int i = 0; i < waitlist.size(); i++) {
				Student temp = waitlist.dequeue();
				if(!temp.equals(student)) {
					waitlist.enqueue(student);
				}
			}
			//student.getSchedule().removeCourseFromSchedule(course);
		}
		catch (IndexOutOfBoundsException e) {
			throw new IllegalArgumentException();
		}
		enrollWaitList();
	}
	
	private void enrollWaitList() {
		if(!waitlist.isEmpty()) {
			Student s = waitlist.dequeue();
			if(s.getSchedule().canAdd(course)) {
				enroll(s);
			}
		}
	}
	
	/**
	 * Returns open seats
	 * @return number of open seats to be returned
	 */
	public int getOpenSeats() {
		return enrollmentCap - roll.size();
	}
	
	/**
	 * Returns whether or not student can enroll
	 * @param student student to check for
	 * @return true if student can, false otherwise
	 */
	public boolean canEnroll(Student student) {
		if (!roll.contains(student) && getNumberOnWaitlist() < 10) {
			return true;
		}
		return false;
	}
	
	/**
	 * Returns number of students on wait list
	 * @return the number
	 */
	public int getNumberOnWaitlist() {
		return waitlist.size();
	}
	
}
