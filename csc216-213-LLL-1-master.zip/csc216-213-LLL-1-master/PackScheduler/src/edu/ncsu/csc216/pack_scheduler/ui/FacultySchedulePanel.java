package edu.ncsu.csc216.pack_scheduler.ui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.table.AbstractTableModel;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.manager.RegistrationManager;
import edu.ncsu.csc216.pack_scheduler.user.schedule.FacultySchedule;

/**
 * Displays information for Faculty in Registration system
 * @author Andrew, Amiya, Joshua, and Ben
 */
public class FacultySchedulePanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTable tableSchedule;
    private JTable tableRoll;
    private CourseTableModel scheduleTableModel;
    private StudentTableModel rollTableModel;
    private Border lowerEtched;
    private JScrollPane scrollSchedule;
    private JScrollPane scrollRoll;
    private JPanel pnlCourseDetails;
    private JLabel lblNameTitle;
    private JLabel lblSectionTitle;
    private JLabel lblTitleTitle;
    private JLabel lblInstructorTitle;
    private JLabel lblCreditsTitle;
    private JLabel lblMeetingTitle;
    private JLabel lblEnrollmentCapTitle;
    private JLabel lblOpenSeatsTitle;
    private JLabel lblWaitlistTitle;
    private JLabel lblName;
    private JLabel lblSection;
    private JLabel lblTitle;
    private JLabel lblInstructor;
    private JLabel lblCredits;
    private JLabel lblMeeting;
    private JLabel lblEnrollmentCap;
    private JLabel lblOpenSeats;
    private JLabel lblWaitlist;
    private FacultySchedule schedule;
    
    /**
     * Constructs a FacultySchedulePanel on no parameters
     */
    public FacultySchedulePanel() {
    	super(new GridBagLayout());
    	setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		setBorder(BorderFactory.createLineBorder(Color.black));
		//Used to set borders; don't know why it says unused
		@SuppressWarnings("unused")
		Border lowerEtched = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
		//Can't get a FacultySchedule without an ID
		//schedule = RegistrationManager.getInstance().getFacultyDirectory();
		initFacultySchedule();
		initCourseDetails();
		initCourseRoll();
    	
    	
    }
    
    /**
     * Initializes FacultySchedule component
     */
    private void initFacultySchedule() {
    	scheduleTableModel = new CourseTableModel();
    	tableSchedule = new JTable(scheduleTableModel);
    	scrollSchedule = new JScrollPane();
    	tableSchedule.add(scrollSchedule);
    	tableSchedule.setBorder(BorderFactory.createTitledBorder(lowerEtched, "Faculty Schedule"));
    	this.add(tableSchedule);
    }
    
    /**
     * Initializes Course Details component
     */
    private void initCourseDetails() {
    	pnlCourseDetails = new JPanel(new FlowLayout(FlowLayout.LEADING));
    	JPanel p = new JPanel(new FlowLayout(FlowLayout.LEADING));
    	lblNameTitle = new JLabel("Name:	", SwingConstants.LEFT);
    	lblName = new JLabel("", SwingConstants.LEFT);
    	lblSectionTitle = new JLabel("Section:	", SwingConstants.LEFT);
    	lblSection = new JLabel("", SwingConstants.LEFT);
    	p.add(lblNameTitle);
    	p.add(lblName);
    	p.add(lblSectionTitle);
    	p.add(lblSection);
    	pnlCourseDetails.add(p);
    	
    	p = new JPanel(new FlowLayout(FlowLayout.LEADING));
    	lblTitleTitle = new JLabel("Title:	", SwingConstants.LEFT);
    	lblTitle = new JLabel("", SwingConstants.LEFT);
    	p.add(lblTitleTitle);
    	p.add(lblTitle);
    	pnlCourseDetails.add(p);
    	
    	p = new JPanel(new FlowLayout(FlowLayout.LEADING));
    	lblInstructorTitle = new JLabel("Instructor:	", SwingConstants.LEFT);
    	lblInstructor = new JLabel("", SwingConstants.LEFT);
    	lblCreditsTitle = new JLabel("Credits:	", SwingConstants.LEFT);
    	lblCredits = new JLabel("", SwingConstants.LEFT);
    	p.add(lblInstructorTitle);
    	p.add(lblInstructor);
    	p.add(lblCreditsTitle);
    	p.add(lblCredits);
    	pnlCourseDetails.add(p);
    	
    	p = new JPanel(new FlowLayout(FlowLayout.LEADING));
    	lblMeetingTitle = new JLabel("Meeting:	", SwingConstants.LEFT);
    	lblMeeting = new JLabel("", SwingConstants.LEFT);
    	p.add(lblMeetingTitle);
    	p.add(lblMeeting);
    	pnlCourseDetails.add(p);
    	
    	p = new JPanel(new FlowLayout(FlowLayout.LEADING));
    	lblEnrollmentCapTitle = new JLabel("Enrollment Cap:	", SwingConstants.LEFT);
    	lblEnrollmentCap = new JLabel("", SwingConstants.LEFT);
    	lblOpenSeatsTitle = new JLabel("Open Seats:	", SwingConstants.LEFT);
    	lblOpenSeats = new JLabel("", SwingConstants.LEFT);
    	lblWaitlistTitle = new JLabel("Waitlist:	", SwingConstants.LEFT);
    	lblWaitlist = new JLabel("", SwingConstants.LEFT);
    	p.add(lblEnrollmentCapTitle);
    	p.add(lblEnrollmentCap);
    	p.add(lblOpenSeatsTitle);
    	p.add(lblOpenSeats);
    	p.add(lblWaitlistTitle);
    	p.add(lblWaitlist);
    	pnlCourseDetails.add(p);
    	pnlCourseDetails.setBorder(BorderFactory.createTitledBorder(lowerEtched, "Faculty Schedule"));
    	this.add(pnlCourseDetails);
    }
    
    /**
     * Initializes CourseRoll component
     */
    private void initCourseRoll() {
    	rollTableModel = new StudentTableModel(null);
    	tableRoll = new JTable(rollTableModel);
    	scrollRoll = new JScrollPane();
    	tableRoll.add(scrollRoll);
    	tableRoll.setBorder(BorderFactory.createTitledBorder(lowerEtched, "Course Roll"));
    	this.add(tableRoll);
    }
    
    /**
     * Updates tables
     */
    public void updateTables() {
    	
    }
    
    /**
     * Updates Course Details information with selected Course
     * @param c the selected Course
     */
    public void updateCourseDetails(Course c) {
    	lblName.setText(c.getName());
    	lblSection.setText(c.getSection());
    	lblTitle.setText(c.getTitle());
    	lblInstructor.setText(c.getInstructorId());
    	lblCredits.setText(Integer.toString(c.getCredits()));
    	lblMeeting.setText(c.getMeetingString());
    	lblEnrollmentCap.setText(Integer.toString(c.getCourseRoll().getEnrollmentCap()));
    	lblOpenSeats.setText(Integer.toString(c.getCourseRoll().getOpenSeats()));
    	lblWaitlist.setText(Integer.toString(c.getCourseRoll().getNumberOnWaitlist()));
    	rollTableModel = new StudentTableModel(c);
    	tableRoll = new JTable(rollTableModel);
    }

    /**
     * Component for Faculty's schedule
     * @author Andrew, Amiya, Joshua, and Ben
     */
    private class CourseTableModel extends AbstractTableModel {
    	
    	private String[][] data;

    	private static final long serialVersionUID = 1L;
    	
    	public CourseTableModel() {
    		super();
    		updateData();
    	}

    	@Override
    	public int getColumnCount() {
    		return 5;
    	}

    	@Override
    	public int getRowCount() {
    		return data.length;
    	}

    	@Override
    	public Object getValueAt(int row, int column) {
    		return data[row][column];
    	}
    	
    	public void updateData() {
    		this.data = schedule.getScheduledCourses();
    	}
	
    }
    
    /**
     * Component for selected Course's CourseRoll
     * @author Andrew, Amiya, Joshua, and Ben
     */
    private class StudentTableModel extends AbstractTableModel {
    	
    	private String[][] data;

    	private static final long serialVersionUID = 1L;
    	
    	public StudentTableModel(Course c) {
    		//TODO
    		super();
    		data = RegistrationManager.getInstance().getStudentDirectory().getStudentDirectory();
    		
    	}

    	@Override
    	public int getColumnCount() {
    		return 3;
    	}

    	@Override
    	public int getRowCount() {
    		return data.length;
    	}

    	@Override
    	public Object getValueAt(int rowIndex, int columnIndex) {
    		return data[rowIndex][columnIndex];
    	}
	
    }
    
}
