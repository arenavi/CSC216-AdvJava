package edu.ncsu.csc216.pack_scheduler.user;

/**
 * Superclass of objects used in registration system
 * @author Andrew Hensley, Luke Hansen
 */
public abstract class User {

	/** Student's first name. */
	private String firstName;
	/** Student's last name. */
	private String lastName;
	/** Student's id. */
	private String id;
	/** Student's email. */
	private String email;
	/** Student's password (hash). */
	private String hashPW;

	/**
	 * Generates User object on all variables
	 * @param firstName first name of user
	 * @param lastName last name of user
	 * @param id id of user
	 * @param email email of user
	 * @param hashPW password of user
	 */
	public User(String firstName, String lastName, String id, String email, String hashPW) {
		setFirstName(firstName);
		setLastName(lastName);
		setId(id);
		setEmail(email);
		setPassword(hashPW);
	}

	/**
	 * Returns the User's first name
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the User's first name. If name is null or empty, an IllegalArgumentException is thrown.
	 * @param firstName the first name to be set
	 * @throws IllegalArgumentException if firstName is null
	 * @throws IllegalArgumentException if firstName is empty
	 */
	public void setFirstName(String firstName) {
		if (firstName == null) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if (firstName.equals("")) {
			throw new IllegalArgumentException("Invalid first name");
		}
		this.firstName = firstName;
	}

	/**
	 * Returns User's last name.
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the User's last name. If name is null or empty, an IllegalArgumentException is thrown.
	 * @param lastName last name to be set
	 * @throws IllegalArgumentException if lastName is null
	 * @throws IllegalArgumentException if lastName is empty String
	 */
	public void setLastName(String lastName) {
		if (lastName == null) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if (lastName.equals("")) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}

	/**
	 * Returns User's ID
	 * @return the ID
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the User's ID. If ID is null or empty, an IllegalArgumentException is thrown.
	 * @param id the ID to be set
	 * @throws IllegalArgumentException if id is null
	 * @throws IllegalArgumentException if id is empty String
	 */
	protected void setId(String id) {
		if (id == null) {
			throw new IllegalArgumentException("Invalid id");
		}
		if (id.equals("")) {
			throw new IllegalArgumentException("Invalid id");
		}
		this.id = id;
	}

	/**
	 * Returns the User's email address
	 * @return the email address
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the User's email address. If the address is empty String, null, contains no '@',
	 * contains no '.', or if last '.' precedes '@', an IllegalArgumentException is thrown.
	 * @param email email to be set
	 * @throws IllegalArgumentException if email is null
	 * @throws IllegalArgumentException if email is empty String
	 * @throws IllegalArgumentException if email does not contain '@'
	 * @throws IllegalArgumentException if email does not contain '.'
	 * @throws IllegalArgumentException if last '.' precedes '@'
	 */
	public void setEmail(String email) {
		if (email == null) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (email.equals("")) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (!email.contains("@")) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (!email.contains(".")) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (email.lastIndexOf('.') < email.indexOf('@')) {
			throw new IllegalArgumentException("Invalid email");
		}
		this.email = email;
	}

	/**
	 * Returns User's password
	 * @return the password
	 */
	public String getPassword() {
		return hashPW;
	}

	/**
	 * Sets the User's password. If password is null or empty, an IllegalArgumentException is thrown.
	 * @param hashPW is the password need to set
	 * @throws IllegalArgumentException if hashPW is null
	 * @throws IllegalArgumentException if hashPW is empty String
	 */
	public void setPassword(String hashPW) {
		if (hashPW == null) {
			throw new IllegalArgumentException("Invalid password");
		}
		if (hashPW.equals("")) {
			throw new IllegalArgumentException("Invalid password");
		}
		this.hashPW = hashPW;
	}

	/**
	 * Generates hashCode for User objects
	 * @return integer representation of hashCode
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((hashPW == null) ? 0 : hashPW.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		return result;
	}

	/**
	 * Compares objects for equality on all variables
	 * @return true if equal, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (hashPW == null) {
			if (other.hashPW != null)
				return false;
		} else if (!hashPW.equals(other.hashPW))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		return true;
	}

	
}