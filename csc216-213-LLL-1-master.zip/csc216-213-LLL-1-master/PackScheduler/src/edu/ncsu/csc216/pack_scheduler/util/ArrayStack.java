/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.EmptyStackException;

/**
 * Implements a stack with ArrayList.
 * @author Andrew, Amiya, and Joshua
 * @param <E> arbitrary object
 */
public class ArrayStack<E> implements Stack<E> {
    
    /** ArrayList of generic type */
    private ArrayList<E> list;
    
    /** Capacity of ArrayList */
    private int capacity;

    /**
     * Constructs an ArrayList and delegates to it.
     * @param capacity ArrayList capacity
     */
    public ArrayStack(int capacity) {
        list = new ArrayList<E>();
        setCapacity(capacity);
    }
    
    /**
     * Adds the element to the back of the list.
     * @param element E
     */
	@Override
	public void push(E element) {
		if(list.size() >= this.capacity) {
			throw new IllegalArgumentException();
		}
		list.add(0, element);
	    
	    
		
	}

	/**
	 * Removes the element from the back of the list.
	 */
	@Override
	public E pop() {
		if(list.isEmpty()) {
			throw new EmptyStackException();
		}
		return list.remove(0);
	}

	/**
	 * Returns true if the list is empty, false otherwise.
	 * @return true if the list is empty, false otherwise
	 */
	@Override
	public boolean isEmpty() {
		
	    if (list.size() == 0) {
	        
	        return true;
	    }
		return false;
	}

	/**
	 * Returns the size of the list.
	 * @return list.size() size of the list
	 */
	@Override
	public int size() {
		
		return list.size();
	}

	/**
	 * Sets the capacity of the list.
	 * @param capacity List's capacity
	 */
	@Override
	public void setCapacity(int capacity) {
		if (capacity < 0 || capacity < list.size()) {
		    
		    throw new IllegalArgumentException();
		}
        this.capacity = capacity;
	}

}
