/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.AbstractList;

/**
 * Implementation of custom LinkedList
 * @author Andrew Hensley, Luke Hansen, Joshua Cowles
 * @param <E> data type
 */
public class LinkedAbstractList<E> extends AbstractList<E> {
	
	/** Front of the list */
	private ListNode front;
	/** Size of the list */
	private int size;
	/** Capacity of the list */
	private int capacity;
	/** Back of the list */
	@SuppressWarnings("unused")
    private ListNode back;
	
	/**
	 * Generates LinkedAbstractList on capacity
	 * @param capacity capacity of the LinkedAbstractList
	 * @throws IllegalArgumentException if capacity is not greater than 0
	 */
	public LinkedAbstractList(int capacity) {
		front = new ListNode(null);
		back = null;
		size = 0;
		setCapacity(capacity);
	}
	
	/**
	 * Sets capacity of list
	 * @param capacity capacity to be set
	 * @throws IllegalArgumentException if capacity is less than zero or less than the current size of the LinkedAbstractList
	 */
	public void setCapacity(int capacity) {
		if (capacity < 0 || capacity < size) {
			
		    throw new IllegalArgumentException();
		}
		this.capacity = capacity;
		
	}
	
	/**
	 * Adds value at a given index
	 * @param index index to be added at
	 * @param value value to be added
	 * @throws NullPointerException if value is null
	 * @throws IndexOutOfBoundsException if index is less than 0 or greater than size
	 * @throws IllegalArgumentException if size equals capacity
	 * @throws IllegalArgumentException if value is a duplicate
	 */
	@Override
	public void add(int index, E value) {
		if (value == null) {
			throw new NullPointerException();
		}
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		if (this.size >= capacity) {
			throw new IllegalArgumentException();
		}
		ListNode current = front;
		while (current != null) {
			if (value.equals(current.data)) {
				throw new IllegalArgumentException();
			}
			current = current.next;
		}
		current = front;
		if (index == 0) {
			front = new ListNode(value, front);
			back = front;
		} else {
			for (int i = 0; i < index - 1; i++) {
				current = current.next;
			}
			current.next = new ListNode(value, current.next);
			back = current.next;
		}
		size++;
	}
	
	/**
	 * Removes element at given index
	 * @param index index to be removed
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 */
	@Override
	public E remove(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		ListNode ret = null;
		if (index == 0) {
			ret = front;
			front = front.next;
		} else {
			ListNode current = front;
			for (int i = 0; i < index - 1; i++) {
				current = current.next;
			}
			ret = current.next;
			current.next = current.next.next;
			if(index == (size - 1)) {
				back = current.next;
			}
		}
		size--;
		return ret.data;
	}
	
	
	/**
	 * Nodes used in LinkedAbstractList
	 * @author Andrew Hensley and Luke Hansen
	 */
	protected class ListNode {
		
		/** Data of the node */
		protected E data;
		/** Next node in the LinkedAbstractList */
		protected ListNode next;
		
		/**
		 * Generates ListNode on data only
		 * @param data data to be stored
		 */
		public ListNode(E data) {
			this(data, null);
		}
		
		/**
		 * Generates ListNode on data and next node
		 * @param data data to be stored
		 * @param next next node
		 */
		public ListNode(E data, ListNode next) {
			this.data = data;
			this.next = next;
		}
	}

	/**
	 * Sets values at given index
	 * @param index index to be set
	 * @param value data to be set
	 * @return old value
	 * @throws NullPointerException if data is null
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws IllegalArgumentException if data is duplicate
	 */
	@Override
	public E set(int index, E value) {
		if (value == null) {
			throw new NullPointerException();
		}
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		ListNode current = front;
		while (current != null) {
			if (value.equals(current.data)) {
				throw new IllegalArgumentException();
			}
			current = current.next;
		}
		ListNode ret = null;
		if (index == 0) {
			ret = front;
			ListNode replace = new ListNode(value, front.next);
			front = replace;
		}
		else {
			current = front;
			for (int i = 0; i < index - 1; i++) {
				current = current.next;
			}
			ret = current.next;
			ListNode replace = new ListNode(value, current.next.next);
			current.next = replace;
		}
		return ret.data;
	}
	
	/**
	 * Returns data at a given index
	 * @param index index to get data from
	 * @return the data
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 */
	@Override
	public E get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		}
		
		ListNode current = front;
		for (int i = 0; i < index; i++) {
			current = current.next;
		}
		return current.data;
	}
	
	/**
	 * Returns size
	 * @return size to be returned
	 */
	public int size() {
		return size;
	}
}
