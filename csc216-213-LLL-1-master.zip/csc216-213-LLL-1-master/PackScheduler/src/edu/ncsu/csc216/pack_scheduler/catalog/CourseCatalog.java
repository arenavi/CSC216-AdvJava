/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.catalog;

import java.io.FileNotFoundException;
import java.io.IOException;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.io.CourseRecordIO;

/**
 * Implements states and methods for course catalog
 * @author Andrew Hensley, Shiyi Ding, and Liam Hall
 */
public class CourseCatalog {

	private SortedList<Course> catalog;
	
	/**
	 * Creates an empty student directory.
	 */
	public CourseCatalog() {
		newCourseCatalog();
	}

	/**
	 * Creates an empty student directory. All students in the previous list are
	 * list unless saved by the user.
	 */
	public void newCourseCatalog() {
		catalog = new SortedList<Course>();
	}
	
	/**
	 * Constructs the student directory by reading in student information from
	 * the given file. Throws an IllegalArgumentException if the file cannot be
	 * found.
	 * 
	 * @param fileName
	 *            file containing list of students
	 */
	public void loadCoursesFromFile(String fileName) {
		try {
			catalog = CourseRecordIO.readCourseRecords(fileName);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to read file " + fileName);
		}
	}
	
	/**
	 * Adds Course to catalog
	 * @param name name of Course to be added
	 * @param section section of Course to be added
	 * @param meetingDays meeting days of course to be added
	 * @param title title of course to be added
	 * @param startTime start time of Course to be added
	 * @param endTime end time of course to be added
	 * @param credits credits of Course to be added
	 * @param instructorId ID of instructor for Course to be added
	 * @param cap enrollment cap of the Course
	 * @return true if course added, false otherwise
	 */
	public boolean addCourseToCatalog(String name, String title, String section, int credits, 
			String instructorId, int cap, String meetingDays, int startTime, int endTime) {
		boolean added = true;
		Course c = null;
		if (!meetingDays.equals("A")) {
			c = new Course(name, title, section, credits, instructorId, cap, 
					meetingDays, startTime, endTime);
		}
		else {
			c = new Course(name, title, section, credits, instructorId, cap,
					meetingDays);
		}
		for (int j = 0; j < catalog.size(); j++) {
			if (c.isDuplicate(catalog.get(j)) && c.getSection().equals(catalog.get(j).getSection())) {
				added = false;
			}
		}
		if (added) {
			catalog.add(c);
		}
		return added;
	}
	
	/**
	 * Removes Course from catalog
	 * @param name name of Course to be removed
	 * @param section section of Course to be removed
	 * @return true if removed, false otherwise
	 */
	public boolean removeCourseFromCatalog(String name, String section) {
		boolean removed = false;
		for (int i = 0; i < catalog.size(); i++) {
			if (catalog.get(i).getName().equals(name) && catalog.get(i).getSection().equals(section)) {
				catalog.remove(i);
				removed = true;
			}
		}
		return removed;
	}
	
	/**
	 * Retrieves course from catalog
	 * @param name name of course to be retrieved
	 * @param section section of course to be retrieved
	 * @return Course if found or null if Course isn't found
	 */
	public Course getCourseFromCatalog(String name, String section) {
		Course c = null;
		for (int i = 0; i < catalog.size(); i++) {
			if (catalog.get(i).getName().equals(name) && catalog.get(i).getSection().equals(section)) {
				c = catalog.get(i);
			}
		}
		return c;
	}
	
	/**
	 * Retrieves course catalog with name, section and title.
	 * @return Course catalog if it exists, empty array otherwise
	 */
	public String[][] getCourseCatalog() {
		String[][] courseCatalog = new String[catalog.size()][5];
		for (int i = 0; i < catalog.size(); i++) {
			courseCatalog[i][0] = catalog.get(i).getName();
			courseCatalog[i][1] = catalog.get(i).getSection();
			courseCatalog[i][2] = catalog.get(i).getTitle();
			courseCatalog[i][3] = catalog.get(i).getMeetingString();
			courseCatalog[i][4] = Integer.toString(catalog.get(i).getCourseRoll().getOpenSeats());
		}
		return courseCatalog;
	}
	
	/**
	 * Outputs catalog to a file.
	 * @param fileName name of output target
	 * @throws IllegalArgumentException if an error occurs writing schedule
	 */
	public void saveCourseCatalog(String fileName) {
		try {
			CourseRecordIO.writeCourseRecords(fileName, catalog);
		}
		catch (IOException e) {
			throw new IllegalArgumentException("The file cannot be saved.");
		}
		
	}
}
