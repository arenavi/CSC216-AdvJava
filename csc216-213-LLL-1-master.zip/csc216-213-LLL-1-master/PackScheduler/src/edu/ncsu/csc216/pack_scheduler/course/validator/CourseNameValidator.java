/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course.validator;

/**
 * Tests if Course names are valid
 * @author Andrew Hensley, Luke Hansen
 */
public class CourseNameValidator {
	private boolean validEndState;
	private int letterCount;
	private int digitCount;
	private State currentState;
	private final State stateInitial = new InitialState();
	private final State stateLetter = new LetterState();
	private final State stateNumber = new NumberState();
	private final State stateSuffix = new SuffixState();
	
	/**
	 * Constructs CourseNameValidator (no parameters)
	 */
	public CourseNameValidator() {
		currentState = stateInitial;
		letterCount = 0;
		digitCount = 0;
		validEndState = false;
	}
	
	/**
	 * Tests to see if Course name is valid
	 * @param name name to check
	 * @return true if name is valid, false otherwise
	 * @throws InvalidTransitionException if invalid transitions between
	 * 				characters are made
	 */
	public boolean isValid(String name) throws InvalidTransitionException {
		for (int i = 0; i < name.length(); i++) {
			if (Character.isLetter(name.charAt(i))) {
				currentState.onLetter();
			} else if (Character.isDigit(name.charAt(i))) {
				currentState.onDigit();
			} else {
				currentState.onOther();
			}
		}
		boolean returnState = validEndState;
		letterCount = 0;
		digitCount = 0;
		validEndState = false;
		currentState = new InitialState();
		return returnState;
	}
	
	/**
	 * Represents states in CourseNameValidator's FSM
	 * @author Andrew Hensley and Luke Hansen
	 */
	public abstract class State {
		/**
		 * Constructs State object (no parameters)
		 */
		State() {
			//Constructs State (unused)
		}
		/**
		 * Defines behavior when letter is reached
		 * @throws InvalidTransitionException if letter should not be reached
		 */
		abstract void onLetter() throws InvalidTransitionException;
		/**
		 * Defines behavior when digit is reached
		 * @throws InvalidTransitionException if digit should not be reached
		 */
		abstract void onDigit() throws InvalidTransitionException;
		/**
		 * Defines behavior when invalid character is reached
		 * @throws InvalidTransitionException always
		 */
		public void onOther() throws InvalidTransitionException  {
			throw new InvalidTransitionException();
		}
	}
	
	/**
	 * State class representing first state in FSM
	 * @author Andrew Hensley and Luke Hansen
	 */
	public class InitialState extends State {

		/**
		 * Defines behavior when letter is reached
		 */
		@Override
		void onLetter() {
			currentState = stateLetter;
			letterCount++;
			
		}

		/**
		 * Defines behavior when digit is reached
		 * @throws InvalidTransitionException always
		 */
		@Override
		void onDigit() throws InvalidTransitionException {
			throw new InvalidTransitionException();
			
		}
		
	}
	
	/**
	 * State class representing letter state in FSM
	 * @author Andrew Hensley and Luke Hansen
	 */
	public class LetterState extends State {

		/**
		 * Defines behavior when letter is reaches
		 * @throws InvalidTransitionException if too many letters present
		 */
		@Override
		void onLetter() throws InvalidTransitionException {
			if (letterCount < 4) {
				letterCount++;
			}
			else {
				throw new InvalidTransitionException();
			}
			
		}

		/**
		 * Defines behavior when number is reached
		 */
		@Override
		void onDigit() {
			currentState = stateNumber;
			digitCount++;
			
		}
		
	}
	
	/**
	 * State class representing number state in FSM
	 * @author Andrew Hensley and Luke Hansen
	 */
	public class NumberState extends State {

		/**
		 * Defines behavior when letter is reached
		 * @throws InvalidTransitionException if there aren't three numbers
		 * 			preceding the letter
		 */
		@Override
		void onLetter() throws InvalidTransitionException {
			if (digitCount != 3) {
				throw new InvalidTransitionException();
			}
			else {
				currentState = stateSuffix;
			}
			
		}

		/**
		 * Defines behavior when number is reached
		 * @throws InvalidTransitionException if there are more than three numbers
		 */
		@Override
		void onDigit() throws InvalidTransitionException {
			if (digitCount < 3) {
				digitCount++;
				if (digitCount == 3) {
					validEndState = true;
				}
			} else {
				throw new InvalidTransitionException();
			}
			
		}
		
	}
	
	/**
	 * State class representing suffix state in FSM
	 * @author Andrew Hensley and Luke Hansen
	 */
	public class SuffixState extends State {

		/**
		 * Defines behavior when letter is reached
		 * @throws InvalidTransitionException always
		 */
		@Override
		void onLetter() throws InvalidTransitionException {
			throw new InvalidTransitionException();
			
		}

		/**
		 * Defines behavior when digit is reached
		 * @throws InvalidTransitionException always
		 */
		@Override
		void onDigit() throws InvalidTransitionException {
			throw new InvalidTransitionException();
			
		}
		
	}
}
