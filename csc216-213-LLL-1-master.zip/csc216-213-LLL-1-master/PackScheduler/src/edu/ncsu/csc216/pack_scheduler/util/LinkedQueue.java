/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.NoSuchElementException;

/**
 * Implements Queue with LinkedList
 * @author Joshua, Amiya, Andrew
 * @param <E> arbitrary object
 */
public class LinkedQueue<E> implements Queue<E> {
	
	/** List of elements */
	private LinkedAbstractList<E> list;

	/**
	 * Constructs LinkedQueue on capacity
	 * @param capacity the capacity to be set
	 */
	public LinkedQueue(int capacity) {
		list = new LinkedAbstractList<E>(capacity);
	}

	/**
	 * Adds element to back of Queue
	 * @param element the element
	 * @throws IllegalArgumentException if enqueue is full
	 */
	@Override
	public void enqueue(E element) {
		try {
			list.add(list.size(), element);
		} catch(IllegalArgumentException e) {
			//TODO add a message
			throw new IllegalArgumentException();
		}
		
		
		
	}

	/**
	 * Removes element from front of list
	 * @return the element
	 * @throws NoSuchElementException if queue is empty
	 */
	@Override
	public E dequeue() {
		if(list.isEmpty()) {
			throw new NoSuchElementException();
		}
		return list.remove(0);
	}

	/**
	 * Returns whether or not queue is empty
	 * @return true if empty, false otherwise
	 */
	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * Returns size of queue
	 * @return the size
	 */
	@Override
	public int size() {
		return list.size();
	}

	/**
	 * Sets capacity of queue
	 * @param capacity capacity to be set
	 */
	@Override
	public void setCapacity(int capacity) {
		list.setCapacity(capacity);
		
	}

}
