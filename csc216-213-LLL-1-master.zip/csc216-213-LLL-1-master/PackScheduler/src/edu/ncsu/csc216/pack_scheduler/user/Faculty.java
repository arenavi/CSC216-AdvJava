/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.user;

import edu.ncsu.csc216.pack_scheduler.user.schedule.FacultySchedule;

/**
 * Class representing university faculty
 * @author Andrew, Amiya, and Joshua
 */
public class Faculty extends User {
	/** Faculty's maximum courses. */
	private int maxCourses;
	
	private FacultySchedule schedule;
	/** Maximum courses allowed.*/
	public static final int MAX_COURSES = 3;
	/** Minimum courses allowed. */
	public static final int MIN_COURSES = 1;
	
	
	/**
	 * Constructs a faculty with given first name, last name, id, email, password, and maximum courses
	 * @param firstName first name of faculty
	 * @param lastName last name of faculty
	 * @param id id of faculty
	 * @param email email address of faculty
	 * @param hashPW password of faculty
	 * @param maxCourses maximum courses of faculty
	 */
	public Faculty(String firstName, String lastName, String id, String email, String hashPW, int maxCourses) {
		super(firstName, lastName, id, email, hashPW);
		setMaxCourses(maxCourses);
		schedule = new FacultySchedule(id);
	}
	
	/**
	 * Returns the Faculty Schedule.
	 * @return schedule Faculty schedule
	 */
	public FacultySchedule getSchedule() {    
	    return schedule;
	}
	
	/**
	 * Returns true if the number of scheduled courses is greater than the Faculty's maxCourses.
	 * @return true if the number of scheduled courses is greater than the Faculty's maxCourses, false otherwise
	 */
	public boolean isOverloaded() {
	    if(schedule.getScheduledCourses().length > maxCourses) {
	        return true;
	    }
	    return false;
	}
	
	/**
	 * Returns Faculty's maximum courses
	 * @return the credits
	 */
	public int getMaxCourses() {
		return maxCourses;
	}
	
	/**
	 * Sets Faculty's maximum courses. If less than 1 or more than 3, an IllegalArgumentException is thrown.
	 * @param maxCourses is the max courses of the Faculty
	 * @throws IllegalArgumentException if maxCourses is not between 1 and 3 inclusive
	 */
	public void setMaxCourses(int maxCourses) {
		if (maxCourses < MIN_COURSES || maxCourses > MAX_COURSES) {
			throw new IllegalArgumentException("Invalid max courses");
		}
		this.maxCourses = maxCourses;
	}

	/**
	 * Returns a comma separated value String of all Faculty fields.
	 * @return String representation of Faculty
	 */
	@Override
	public String toString() {
		String s = "";
		s += getFirstName() + ",";
		s += getLastName() + ",";
		s += getId() + ",";
		s += getEmail() + ",";
		s += getPassword() + ",";
		s += maxCourses;
		return s;
	}


	/**
	 * Generates hashCode for Faculty
	 * @return numerical value of hashCode
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + maxCourses;
		return result;
	}

	/**
	 * Compares objects for equality one User states and max courses
	 * @return true if equal, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Faculty other = (Faculty) obj;
		if (maxCourses != other.maxCourses)
			return false;
		return true;
	}

	
}
