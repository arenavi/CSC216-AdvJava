/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.pack_scheduler.user.Faculty;
import edu.ncsu.csc216.pack_scheduler.util.LinkedList;

/**
 * Reads and writes Faculty records from files.
 * @author Andrew, Amiya, and Joshua
 */
public class FacultyRecordIO {

	/**
	 * Reads Faculty records from a file. Invalid faculty are ignored. If file
	 * cannot be read or found, a FileNotFoundExceptio is thrown.
	 * @param fileName name of file containing records
	 * @return list of Faculty records
	 * @throws FileNotFoundException if file cannot be found or read
	 */
	public static LinkedList<Faculty> readFacultyRecords(String fileName) 
			throws FileNotFoundException {
		Scanner reader = new Scanner(new FileInputStream(fileName));
		LinkedList<Faculty> facultyDirectory = new LinkedList<Faculty>();
		while (reader.hasNextLine()) {
			try {
				Faculty f = processFaculty(reader.nextLine());
				if (f == null) {
					throw new IllegalArgumentException();
				}
				boolean duplicate = false;
				for (int i = 0; i < facultyDirectory.size(); i++) {
					Faculty f1 = facultyDirectory.get(i);
					if (f.getLastName().equals(f1.getLastName())
							&& f.getFirstName().equals(f1.getFirstName())) {
						duplicate = true;
					}
				}
				if (!duplicate) {
					facultyDirectory.add(f);
				}
			} catch (IllegalArgumentException e) {
				// Invalid student records will not be added to directory
			}
		}
		reader.close();
		return facultyDirectory;
	}

	/**
	 * Processes line from file of Faculty records into Faculty object
	 * @param nextLine line to be processed
	 * @return the Faculty object
	 * @throws IllegalArgumentException
	 *             if maxCourses is not set correctly
	 * @throws IllegalArgumentException
	 *             if NoSuchElementException is found
	 */
	private static Faculty processFaculty(String nextLine) {
		Faculty s = null;
		@SuppressWarnings("resource")
		Scanner readLine = new Scanner(nextLine).useDelimiter(",");
		try {
			String firstName = readLine.next();
			String lastName = readLine.next();
			String id = readLine.next();
			String email = readLine.next();
			String hashPW = readLine.next();
			int maxCourses = readLine.nextInt();
			s = new Faculty(firstName, lastName, id, email, hashPW, maxCourses);
			if (s.getMaxCourses() != maxCourses) {
				throw new IllegalArgumentException();
			}
		}
		catch (NoSuchElementException e) {
			throw new IllegalArgumentException();
		}
		readLine.close();
		return s;
	}
	
	/**
	 * Writes Faculty records to given file. If i/o error occurs, and
	 * IOException is thrown.
	 * @param fileName name of file to be written to
	 * @param list directory of Faculty records to be written to file
	 * @throws IOException if file cannot be written to properly
	 */
	public static void writeFacultyRecords(String fileName, LinkedList<Faculty> list)
			throws IOException {
		PrintStream write = new PrintStream(new File(fileName));

		for (int i = 0; i < list.size(); i++) {
			write.println(list.get(i).toString());
		}

		write.close();
	}
	
}
