/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Creates ConflictException to be thrown when Activities conflict
 * @author Andrew Hensley
 */
public class ConflictException extends Exception {

	/** ID used for serialization. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructs ConflictException with message
	 * @param message the message to be displayed
	 */
	public ConflictException(String message) {
		super(message);
	}
	
	/**
	 * Constructs ConflictException with default message
	 */
	public ConflictException() {
		super("Schedule conflict.");
	}

}
