/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.EmptyStackException;

/**
 * Implements Stack with LinkedAbstractList
 * @author Andrew, Amiya, and Joshua
 * @param <E> arbitrary object
 */
public class LinkedStack<E> implements Stack<E> {
	
	/** List of elements */
	private LinkedAbstractList<E> list;
	
	/**
	 * Constructs LinkedStack on capacity
	 * @param capacity capacity to be set
	 */
	public LinkedStack(int capacity) {
		list = new LinkedAbstractList<E>(capacity);
	}
	
	/**
	 * Adds element to the top of stack
	 * @param element element to be added
	 * @throws IllegalArgumentException if stack is full
	 */
	@Override
	public void push(E element) {
		try {
			list.add(0, element);
		}
		catch(IllegalArgumentException e) {
			throw new IllegalArgumentException("");
		}
		
	}

	/**
	 * Returns element on top of the stack
	 * @return the element
	 */
	@Override
	public E pop() {
		if(list.isEmpty()) {
			throw new EmptyStackException();
		}
		try {
			return list.remove(0);
		}
		catch (IndexOutOfBoundsException e) {
			throw new EmptyStackException();
		}
	}

	/**
	 * Returns whether or not stack is empty
	 * @return true if empty, false otherwise
	 */
	@Override
	public boolean isEmpty() {
		if (list.isEmpty()) {
			return true;
		}
		return false;
	}

	/**
	 * Returns size of the stack
	 * @return the size
	 */
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return list.size();
	}

	/**
	 * Sets capacity of the stack
	 * @param capacity the capacity
	 */
	@Override
	public void setCapacity(int capacity) {
		list.setCapacity(capacity);
		
	}

}
