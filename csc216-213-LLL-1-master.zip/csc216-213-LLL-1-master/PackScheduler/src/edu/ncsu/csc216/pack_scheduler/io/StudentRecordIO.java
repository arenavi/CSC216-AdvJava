package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.user.Student;

/**
 * Reads Student records from files. Writes a set of Student records to a file.
 * 
 * @author Andrew Hensley and Shiyi Ding
 */
public class StudentRecordIO {

	/**
	 * Reads Student records from a file. Invalid students are ignored. If file
	 * cannot be read or found, a FileNotFoundExceptio is thrown.
	 * 
	 * @param fileName
	 *            name of file containing records
	 * @return list of Student records
	 * @throws FileNotFoundException
	 *             if file cannot be found or read
	 */
	public static SortedList<Student> readStudentRecords(String fileName) throws FileNotFoundException {
		Scanner reader = new Scanner(new FileInputStream(fileName));
		SortedList<Student> studentDirectory = new SortedList<Student>();
		while (reader.hasNextLine()) {
			try {
				Student student = processStudent(reader.nextLine());
				if (student == null) {
					throw new IllegalArgumentException();
				}
				boolean duplicate = false;
				for (int i = 0; i < studentDirectory.size(); i++) {
					Student s = studentDirectory.get(i);
					if (student.getLastName().equals(s.getLastName())
							&& student.getFirstName().equals(s.getFirstName())) {
						duplicate = true;
					}
				}
				if (!duplicate) {
					studentDirectory.add(student);
				}
			} catch (IllegalArgumentException e) {
				// Invalid student records will not be added to directory
			}
		}
		reader.close();
		return studentDirectory;
	}

	/**
	 * Processes line from file of Student records into Student object
	 * 
	 * @param nextLine
	 *            line to be processed
	 * @return the Student object
	 * @throws IllegalArgumentException
	 *             if maxCredits is not set correctly
	 * @throws IllegalArgumentException
	 *             if NoSuchElementException is found
	 */
	@SuppressWarnings("resource")
	private static Student processStudent(String nextLine) {
		Student s = null;
		Scanner readLine = new Scanner(nextLine).useDelimiter(",");
		try {
			String firstName = readLine.next();
			String lastName = readLine.next();
			String id = readLine.next();
			String email = readLine.next();
			String hashPW = readLine.next();
			int maxCredits = readLine.nextInt();
			s = new Student(firstName, lastName, id, email, hashPW, maxCredits);
			if (s.getMaxCredits() != maxCredits) {
				throw new IllegalArgumentException();
			}
		}
		catch (NoSuchElementException e) {
			throw new IllegalArgumentException();
		}
		readLine.close();
		return s;
	}

	/**
	 * Writes Student records to given file. If i/o error occurs, and
	 * IOException is thrown.
	 * 
	 * @param fileName
	 *            name of file to be written to
	 * @param studentDirectory
	 *            directory of Student records to be written to file
	 * @throws IOException
	 *             if file cannot be written to properly
	 */
	public static void writeStudentRecords(String fileName, SortedList<Student> studentDirectory) throws IOException {
		PrintStream write = new PrintStream(new File(fileName));

		for (int i = 0; i < studentDirectory.size(); i++) {
			write.println(studentDirectory.get(i).toString());
		}

		write.close();
	}

}
