package edu.ncsu.csc216.pack_scheduler.user;

import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.user.schedule.Schedule;

/**
 * Contsructs and modifies Student Objects
 * @author Andrew Hensley and Shiyi Ding
 */
public class Student extends User implements Comparable<Student> {
	
	/** Student's maximum credits. */
	private int maxCredits;
	/** Maximum credits allowed.*/
	public static final int MAX_CREDITS = 18;
	/** Minimum credits allowed. */
	public static final int MIN_CREDITS = 3;
	/** Student's schedule */
	private Schedule schedule; 
	
	
	/**
	 * Constructs a student with given first name, last name, id, email, password, and maximum credits
	 * @param firstName first name of student
	 * @param lastName last name of student
	 * @param id id of student
	 * @param email email address of student
	 * @param hashPW password of student
	 * @param maxCredits maximum credits of student
	 */
	public Student(String firstName, String lastName, String id, String email, String hashPW, int maxCredits) {
		super(firstName, lastName, id, email, hashPW);
		setMaxCredits(maxCredits);
		schedule = new Schedule();
	}
	
	/**
	 * Constructs Student with given first name, last name, id, email, and password
	 * @param firstName first name of student
	 * @param lastName last name of student
	 * @param id id of student
	 * @param email email address of student
	 * @param hashPW password of student
	 */
	public Student(String firstName, String lastName, String id, String email, String hashPW) {
		this(firstName, lastName, id, email, hashPW, MAX_CREDITS);
	}
	
	/**
	 * Returns Student's maximum credits
	 * @return the credits
	 */
	public int getMaxCredits() {
		return maxCredits;
	}
	
	/**
	 * Sets Student's maximum credits. If less than 3 or more than 18, an IllegalArgumentException is thrown.
	 * @param maxCredits is the max credit of the student
	 * @throws IllegalArgumentException if maxCredits is not between 3 and 18 inclusive
	 */
	public void setMaxCredits(int maxCredits) {
		if (maxCredits < MIN_CREDITS || maxCredits > MAX_CREDITS) {
			throw new IllegalArgumentException("Invalid max credits");
		}
		this.maxCredits = maxCredits;
	}

	/**
	 * Returns a comma separated value String of all Course fields.
	 * @return String representation of Student
	 */
	@Override
	public String toString() {
		String s = "";
		s += getFirstName() + ",";
		s += getLastName() + ",";
		s += getId() + ",";
		s += getEmail() + ",";
		s += getPassword() + ",";
		s += maxCredits;
		return s;
	}

	/**
	 * Compares the ranking of Student objects
	 * @return 1 if greater, -1 if less than, 0 otherwise
	 */
	@Override
	public int compareTo(Student s) {
		if (this.getLastName().compareTo(s.getLastName()) != 0) {
			if (this.getLastName().compareTo(s.getLastName()) > 0) {
				return 1;
			}
			else {
				return -1;
			}
		}
		else if (this.getFirstName().compareTo(s.getFirstName()) != 0) {
			if (this.getFirstName().compareTo(s.getFirstName()) > 0) {
				return 1;
			}
			else {
				return -1;
			}
		}
		else if (this.getId().compareTo(s.getId()) != 0) {
			if (this.getId().compareTo(s.getId()) > 0) {
				return 1;
			}
			else {
				return -1;
			}
		}
		else {
			return 0;
		}
	}

	/**
	 * Generates hashCode for Student
	 * @return numerical value of hashCode
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + maxCredits;
		return result;
	}

	/**
	 * Compares objects for equality one User states and max credits
	 * @return true if equal, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (maxCredits != other.maxCredits)
			return false;
		return true;
	}

	/**
	 * Returns schedule
	 * @return schedule to be returned
	 */
	public Schedule getSchedule() {
		return schedule;
	}
	
	/**
	 * Checks whether course can be added to schedule
	 * @param course course to be added to schedule
	 * @return whether course can be added
	 */
	public boolean canAdd(Course course) {
		int futureCredits = course.getCredits() + schedule.getScheduleCredits();
		if (schedule.canAdd(course) && futureCredits <= maxCredits) {
			return true;
		}
		return false;
	}
}
