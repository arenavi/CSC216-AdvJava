/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

/**
 * Implements Stack data structure
 * @author Andrew, Amiya, and Joshua 
 * @param <E> arbitrary object
 */
public interface Stack<E> {

	/**
	 * Adds element to the top of the stack
	 * @param element data to be added
	 */
	void push(E element);
	
	/**
	 * Returns data on top of stack
	 * @return the data
	 */
	E pop();
	
	/**
	 * Returns whether or not stack is empty
	 * @return true if empty, false otherwise
	 */
	boolean isEmpty();
	
	/**
	 * Returns size of stack
	 * @return the size
	 */
	public int size();
	
	/**
	 * Sets capacity of the stack
	 * @param capacity capacity to be set
	 */
	void setCapacity(int capacity);
	
	
}
