/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.util;

import java.util.NoSuchElementException;

/**
 * Implements Queue with ArrayList
 * @author Andrew, Amiya, and Joshua
 * @param <E> arbitrary object
 */
public class ArrayQueue<E> implements Queue<E> {

	/** List of elements */
	private ArrayList<E> list;
	/** Capacity of Queue */
	private int capacity;
	
	/**
	 * Constructs Queue on capacity
	 * @param capacity the capacity
	 */
	public ArrayQueue(int capacity) {
		list = new ArrayList<E>();
		setCapacity(capacity);
	}
	
	/**
	 * Adds element to back of Queue
	 * @param element the element
	 * @throws IllegalArgumentException if enqueue is full
	 */
	@Override
	public void enqueue(E element) {
		if (list.size() >= capacity) {
			throw new IllegalArgumentException();
		}
		list.add(list.size(), element);
		
	}

	/**
	 * Removes element from front of list
	 * @return the element
	 */
	@Override
	public E dequeue() {
		if (list.isEmpty()) {
			throw new NoSuchElementException();
		}
		return list.remove(0);
	}

	/**
	 * Returns whether or not queue is empty
	 * @return true if empty, false otherwise
	 */
	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * Returns size of queue
	 * @return the size
	 */
	@Override
	public int size() {
		return list.size();
	}

	/**
	 * Sets capacity of queue
	 * @param capacity capacity to be set
	 */
	@Override
	public void setCapacity(int capacity) {
		if (capacity < list.size()) {
			throw new IllegalArgumentException();
		}
		this.capacity = capacity;
		
	}

}
