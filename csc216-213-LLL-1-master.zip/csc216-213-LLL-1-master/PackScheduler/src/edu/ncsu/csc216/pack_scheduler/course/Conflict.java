/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Handles conflicts during scheduling
 * @author Andrew Hensley
 */
public interface Conflict {
	/**
	 * Checks to see if two Activity objects conflict
	 * @param possibleConflictingActivity activity to be compared
	 * @throws ConflictException if conflict occurs
	 */
	void checkConflict(Activity possibleConflictingActivity) throws ConflictException;
}
