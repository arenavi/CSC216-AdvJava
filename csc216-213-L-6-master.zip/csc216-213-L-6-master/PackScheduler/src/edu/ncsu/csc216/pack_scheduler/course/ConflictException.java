/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * An exception that gets thrown when there is a schedule conflict
 * @author Joshua Cowles (jlcowles)
 *
 */
public class ConflictException extends Exception {

	/** ID used for serialization. */
	private static final long serialVersionUID = 1L;

	/**
	 * ConflictException with Custom exception message
	 * @param str The exception message
	 */
	public ConflictException(String str){
		super(str);
	}
	
	/**
	 * Default ConflictException constructor with message "Schedule conflict."
	 */
	public ConflictException() {
		super("Schedule conflict.");
	}
}
