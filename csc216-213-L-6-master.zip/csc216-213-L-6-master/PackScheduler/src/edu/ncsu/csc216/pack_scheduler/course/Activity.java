package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Abstract parent class for Event and Course, contains title, meeting days.
 * start and end times, and related methods.
 * @author Joshua Cowles (jlcowles)
 *
 */
abstract public class Activity implements Conflict {

	/** activity's title. */
	private String title;
	/** 
	 * Eclipse generated toString() implementation.
	 */
	@Override
	public String toString() {
		return title + "," + meetingDays + "," + startTime + "," + endTime;
	}

	/** Activity's meeting days */
	private String meetingDays;
	/** Activity's starting time */
	private int startTime;
	/** Activity's ending time */
	private int endTime;
	
// This code is not implemented yet in GP2, but is in the design document,
//	so as to avoid innacurate static analysis errors it has been commented out.
//	
//	/**Maximum allowed credits for an activity*/
//	private static final int MAX_CREDITS = 5;
//	/**Minimum allowed credits for an activity*/
//	private static final int MIN_CREDITS = 1;
//	/**The upper time*/
//	private static final int UPPER_TIME = 2400;
//	/**The upper hour*/
//	private static final int UPPER_HOUR = 60;

	/**
	 * Constructor for the activity class
	 * @param title The activity's title
	 * @param meetingDays The activity's meeting days
	 * @param startTime The activity's start time
	 * @param endTime The activity's ending time
	 */
	public Activity(String title, String meetingDays, int startTime, int endTime) {
		setTitle(title);
		setMeetingDays(meetingDays);
		setActivityTime(startTime, endTime);
	}

	/**
	 * Returns the activity's title.
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the activity's title. If the title is null or an empty String,
	 * an IllegalArgumentException is thrown.
	 * @param title the title to set
	 * @throws IllegalArgumentException if title is null or an empty String
	 */
	public void setTitle(String title) {
		if (title == null) {
			throw new IllegalArgumentException();
		}
		if (title.equals("")) {
			throw new IllegalArgumentException();
		}
		this.title = title;
	}

	/**
	 * Returns the activity's meeting days.
	 * @return the meetingDays
	 */
	public String getMeetingDays() {
		return meetingDays;
	}

	/**
	 * Sets the meeting days
	 * @param meetingDays the meeting days
	 */
	public void setMeetingDays(String meetingDays) {
		this.meetingDays = meetingDays;
	}

	/**
	 * Sets the Activity's start and end time. Throws an IllegalArgumentException if either value is less than 0 or greater than 2359,
	 * if either is not valid military time, if endTime is less than startTime, or if a time other than 0 is set for
	 * days with an arranged time.
	 * @param startTime The time the activity starts
	 * @param endTime The time the activity ends
	 * @throws IllegalArgumentException if either value is less than 0 or greater than 2359, if either is not valid military time, 
	 * if endTime is less than startTime, or if a time other than 0 is set for days with an arranged time.
	 */
	public void setActivityTime(int startTime, int endTime) {
		if (startTime < 0 || startTime > 2359) {
			throw new IllegalArgumentException();
		}
		if (endTime < 0 || endTime > 2359) {
			throw new IllegalArgumentException();
		}
		if ((startTime  / 10) % 10 < 0 || (startTime / 10) % 10 > 5) {
			throw new IllegalArgumentException();
		}
		if ((endTime / 10) % 10 < 0 || (endTime / 10) % 10 > 5) {
			throw new IllegalArgumentException();
		}
		if (endTime < startTime) {
			throw new IllegalArgumentException();
		}
		if (this.getMeetingDays().equals("A") && (startTime != 0 || endTime != 0)) {
			throw new IllegalArgumentException();
		}
		this.startTime = startTime;
		this.endTime = endTime;
	}

	/**
	 * Returns the Activity's start time.
	 * @return the startTime
	 */
	public int getStartTime() {
		return startTime;
	}

	/**
	 * Returns the Activity's end time.
	 * @return the endTime
	 */
	public int getEndTime() {
		return endTime;
	}

	/**
	 * Returns the meeting times of an activity in standard day and time format
	 * @return The meeting times of the activity as a String
	 */
	public String getMeetingString() {
		if(this.meetingDays.equals("A")) {
			return "Arranged";
		} else {
			return "" + this.meetingDays + " " + milToStandard(this.startTime) + "-" + milToStandard(this.endTime);
		}
	}

	/**
	 * Private helper method to convert meeting times from military to standard time, and formats them.
	 * @param time The time to convert
	 * @return The time in "XX:XXAM" formatted String
	 */
	private String milToStandard(int time) {
		boolean pmCheck;
		if(time >= 1200) {
			pmCheck = true;
			if(time >= 1300) {
				time = time % 1200;
			}
		} else {
			pmCheck = false;
		}
		StringBuilder timeString = new StringBuilder(String.valueOf(time));
		timeString.insert(timeString.length() / 2, ':');
		if(pmCheck) {
			timeString.append("PM");
		} else {
			timeString.append("AM");
		}
		return timeString.toString();
	}

	/**
	 * Eclipse generated hashcode function
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + endTime;
		result = prime * result + ((meetingDays == null) ? 0 : meetingDays.hashCode());
		result = prime * result + startTime;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	/**
	 * Abstract method to force child classes to implement shortDisplayArray functionality
	 * @return An array of strings describing the object
	 */
	public abstract String[] getShortDisplayArray();
	
	/**
	 * Abstract method to force child classes to implement longDisplayArray functionality
	 * @return An array of strings describing the object
	 */
	public abstract String[] getLongDisplayArray();
	
	/**
	 * Abstract method to force child classes to implement isDuplicate functionality
	 * @param activity the object to compare
	 * @return true if it is a duplicate, false otherwise
	 */
	public abstract boolean isDuplicate(Activity activity);

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Activity other = (Activity) obj;
		if (endTime != other.endTime)
			return false;
		if (meetingDays == null) {
			if (other.meetingDays != null)
				return false;
		} else if (!meetingDays.equals(other.meetingDays))
			return false;
		if (startTime != other.startTime)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	/**
	 * Checks the implicit activity against the passed in activity for a schedule conflict
	 * @param possibleConflictingActivity The activity to check
	 * @throws ConflictException If a schedule conflict is found
	 */
	@Override
	public void checkConflict(Activity possibleConflictingActivity) throws ConflictException {
		char[] a1 = this.getMeetingDays().toCharArray();
		char[] a2 = possibleConflictingActivity.getMeetingDays().toCharArray();
		
		for(int i = 0; i < a1.length; i++) {
			for(int j = 0; j < a2.length; j++) {
				if(a1[i] == a2[j] && a1[i] != 'A' && (conflictTimeCheck(possibleConflictingActivity.getStartTime(), possibleConflictingActivity.getEndTime()))) { 
						throw new ConflictException();
				}
			}
		}
	}
	
	
	private boolean conflictTimeCheck(int checkStart, int checkEnd) {
		return (checkStart >= this.startTime && checkStart <= this.endTime) || (checkEnd >= this.startTime && checkEnd <= this.endTime) || (this.startTime >= checkStart && this.startTime <= checkEnd) || (this.endTime >= checkStart && this.endTime <= checkEnd);
	}

}