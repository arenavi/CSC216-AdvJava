package edu.ncsu.csc216.pack_scheduler.catalog;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.course.Course;
import edu.ncsu.csc216.pack_scheduler.io.CourseRecordIO;

/**
 * Logic for the management of schedules in GP1
 * 
 * @author Joshua Cowles (jlcowles)
 * @author Amiya Renavikar 
 */
public class CourseCatalog {
	
	/**The SortedList of courses */
	private SortedList<Course> catalog;

	
	/**
	 * WolfScheduler constructor, requires the filename for the course records to be passed in.
	 * @param fileName The filename of the course records
	 */
	public CourseCatalog(String fileName) {
		this.catalog = new SortedList<Course>();
		try {
			this.catalog = CourseRecordIO.readCourseRecords(fileName);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Cannot find file");
		}
	}
	
	/**
	 * CourseCatalog constructor sets catalog to a new sorted list.
	 */
	public CourseCatalog() {
		this.catalog = new SortedList<Course>();
	}
	
	/**
	 * Sets the catalog list to a new Sorted List of Course.
	 */
	public void newCourseCatalog() {
		this.catalog = new SortedList<Course>();
	}
	
	
	/**
	 * Returns a 2d array of Strings representing the courses in the catalog,
	 * each course is on it's own row, with columns for name, section, and title.
	 * @return The 2d array
	 */
	public String[][] getCourseCatalog() {
		String[][] courses = new String[catalog.size()][4];
		for (int i = 0; i < catalog.size(); i++) {
			courses[i][0] = catalog.get(i).getName();
			courses[i][1] = catalog.get(i).getSection();
			courses[i][2] = catalog.get(i).getTitle();
			courses[i][3] = catalog.get(i).getMeetingString();
		}
		return courses;
	}
	
	
	/**
	 * Checks to see if a course is on the catalog, then returns it.
	 * @param name The name of the course checked for
	 * @param section The section of the course checked for
	 * @return The course object if found, else null
	 */
	public Course getCourseFromCatalog(String name, String section) {
		for (int i = 0; i < this.catalog.size(); i++) {
			if (catalog.get(i).getName().equals(name) && catalog.get(i).getSection().equals(section)) {
				return catalog.get(i);
			}
		}
		return null;
	}
	

	
	/**
     * Reads course records from a file and generates a list of valid Courses.  Any invalid
     * Courses are ignored.  If the file to read cannot be found or the permissions are incorrect
     * a File NotFoundException is thrown.
     * @param fileName file to read Course records from file
     * @throws IllegalArgumentException if the file cannot be found or read
     */
	public void  loadCoursesFromFile(String fileName) {
	    try{
	    	Scanner fileReader = new Scanner(new File(fileName));
	    	this.newCourseCatalog();
	    	while (fileReader.hasNextLine()) {
	    		try {
	    			Course course = readCourse(fileReader.nextLine());
	    			boolean duplicate = false;
	    			for (int i = 0; i < catalog.size(); i++) {
	    				Course c = catalog.get(i);
	    				if (course.getName().equals(c.getName()) &&
	         	              course.getSection().equals(c.getSection())) {
	    					//it's a duplicate
	    					duplicate = true;
	    				}
	    			}
	    			if (!duplicate) {
	    				catalog.add(course);
	    			}
	    		} catch (IllegalArgumentException e) {
	            //skip the line
	    		}
	    }
	    fileReader.close();
	    } catch (FileNotFoundException e) {
	    	throw new IllegalArgumentException();
	    }
	    
	}

	/**
	 * Attempts to parse a line of data as a course, then creates and returns the course 
	 * if it is the basis for a valid course.
	 * @param nextLine The string of the line being analyzed
	 * @return A course object based on the information given in the line.
	 */
	private static Course readCourse(String nextLine) {
		Scanner parse = new Scanner(nextLine);
		parse.useDelimiter(",");
		
		try {
			String name = parse.next();
			String title = parse.next();
			String section = parse.next();
			int credits = parse.nextInt();
			String instructorId = parse.next();
			String meetingDays = parse.next();
			if (meetingDays.equals("A")) {
				if(parse.hasNext()) {
					parse.close();
					throw new IllegalArgumentException();
				}
				parse.close();
				return new Course(name, title, section, credits, instructorId, meetingDays);
			} else {
				int startTime = parse.nextInt();
				int endTime = parse.nextInt();
				parse.close();
				return new Course(name, title, section, credits, instructorId, meetingDays, startTime, endTime);
			}
		} catch (NoSuchElementException e) {
			throw new IllegalArgumentException();
		}
	}
	
	
	/**
	 * Adds the Course to Course Catalog.
	 * @param name Course name
	 * @param title Course title
	 * @param section Course section
	 * @param credits number of credits
	 * @param instructorId instructor id
	 * @param meetingDays Course meeting days
	 * @param startTime Course start time
	 * @param endTime Course end time
	 * @return false if course not added to CourseCatalog
	 */
	public boolean addCourseToCatalog (String name, String title, String section, int credits, 
									String instructorId, String meetingDays, int startTime, int endTime) {
        Course course = new Course(name, title, section, credits, instructorId, meetingDays, startTime, endTime);
        boolean duplicate = false;
        for (int i = 0; i < catalog.size(); i++) {
            Course c = catalog.get(i);
            if (course.getName().equals(c.getName()) &&
                    course.getSection().equals(c.getSection())) {
                //it's a duplicate
                duplicate = true;
                }
            }
            if (!duplicate) {
                catalog.add(course);
                return true;
            }
            return false;
	}
	
	/**
	 * Removes the Course form the CourseCatalog.
	 * @param name Course name
	 * @param section Course section
	 * @return true if Course is removed from Course Catalog, false otherwise.
	 */
	public boolean removeCourseFromCatalog (String name, String section) {
		try {
			if(catalog.indexOf(getCourseFromCatalog(name, section)) > 0) {
				catalog.remove(catalog.indexOf(getCourseFromCatalog(name, section)));
				return true;
			} else {
				return false;
			}
		} catch (NullPointerException e) {
			return false;
		}
	}
	
	/**
	 * Writes the given list of courses to a file
	 * @param fileName The filename the list is written to
	 * @param courses The list of courses to write
	 * @throws IOException If there is an error with the file
	 */
	public static void writeActivityRecords(String fileName, SortedList<Course> courses){
		try {
			PrintStream fileWriter = new PrintStream(new File(fileName));
			for (int i = 0; i < courses.size(); i++) {
			    fileWriter.println(courses.get(i).toString());
			}
		
			fileWriter.close();
		} catch (IOException e) {
			throw new IllegalArgumentException("Invalid filename");
		}
	}
	
	/**
	 * Saves the Course Catalog.
	 * @param filename the filename that the list is saved to
	 */
	public void saveCourseCatalog(String filename) {
		CourseCatalog.writeActivityRecords(filename, this.catalog);
	}

}
