package edu.ncsu.csc216.pack_scheduler.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.collections.list.SortedList;
import edu.ncsu.csc216.pack_scheduler.user.Student;


/**
 * Provides static methods that support reading in student records 
 * from a file and writing student records to a file.
 * 
 * @author Amiya Renavikar
 * @author Joshua Cowles
 *
 */
public class StudentRecordIO {


	/**
	 * Reads the Student records from the file represented by the fileName.
	 * @param fileName file name
	 * @return students SortedList for Student
	 * @throws FileNotFoundException If the file does not exist in the given directory
	 */
	public static SortedList<Student> readStudentRecords(String fileName) throws FileNotFoundException {
		Scanner fileReader = new Scanner(new FileInputStream(fileName));
	    SortedList<Student> students = new SortedList<Student>();
	    while (fileReader.hasNextLine()) {
	        try {
	            Student student = processStudent(fileReader.nextLine());
	            boolean duplicate = false;
	            for (int i = 0; i < students.size(); i++) {
	                Student s = students.get(i);
	                if (student.getFirstName().equals(s.getFirstName()) &&
	                        student.getLastName().equals(s.getLastName())) {
	                    //it's a duplicate
	                    duplicate = true;
	                }
	            }
	            if (!duplicate) {
	                students.add(student);
	            }
	        } catch (IllegalArgumentException e) {
	            //skip line
	        	
	        }
	    }
	    fileReader.close();
	    return students;
	}

	/**
	 * Processes the Student through the SortedList.
	 * Based mostly on GP1 code.
	 * @param nextLine next line
	 * @return null
	 */
	private static Student processStudent(String nextLine) {
		Scanner parse = new Scanner(nextLine);
		parse.useDelimiter(",");
		try {
			String firstName = parse.next();
			String lastName = parse.next();
			String id = parse.next();
			String email = parse.next();
			String hashedPass = parse.next();
			int maxCredits = parse.nextInt();
			parse.close();
			return new Student(firstName, lastName, id, email, hashedPass, maxCredits);
		} catch (NoSuchElementException e) {
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 * Writes the Students in studentDirectory to the file represented
	 * by the fileName one Student record at a time.
	 * @param fileName file name
	 * @param studentDirectory student directory
	 * @throws IOException if unable to write to the file.
	 */
	public static void writeStudentRecords(String fileName, SortedList<Student> studentDirectory) throws IOException {
		

			PrintStream write = new PrintStream(new File(fileName));
	        
	    	for (int i = 0; i < studentDirectory.size(); i++) {
	    		
	    		write.println(studentDirectory.get(i).toString());
	    	}
	    	write.close();
		
		
	}
	
	

}
