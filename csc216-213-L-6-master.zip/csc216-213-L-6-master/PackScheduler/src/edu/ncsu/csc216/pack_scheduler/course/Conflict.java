/**
 * 
 */
package edu.ncsu.csc216.pack_scheduler.course;

/**
 * Interface for checking whether there is a conflict between two activities.
 * @author Josh
 *
 */
public interface Conflict {
	
	/**
	 * Checks whether a given activity has a schedule conflict, throws a ConflictException if there is a conflict
	 * @param possibleConflictingActivity The activity to check
	 * @throws ConflictException If there is a schedule conflict
	 */
	void checkConflict(Activity possibleConflictingActivity) throws ConflictException;
}

