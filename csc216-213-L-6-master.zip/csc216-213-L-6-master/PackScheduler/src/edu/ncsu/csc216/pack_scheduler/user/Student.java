package edu.ncsu.csc216.pack_scheduler.user;

/**
 * Student class is an object for PackScheduler.
 * @author Joshua Cowles
 * @author Amiya Renavikar
 * @author Edgar Woode
 */
public class Student implements Comparable<Student> {
	
	/** First Name */
	private String firstName;
	/** Last Name */
	private String lastName;
	/** Student id number */
	private String id;
	/** Students email */
	private String email;
	/** Students hashed password */
	private String password;
	/** Maximum credits allowed */
	private int maxCredits;
	/** Constant for max credits */
	public static final int MAX_CREDITS = 18;
	
	/**
	 * Constructs Student class by calling the setter methods.
	 * @param firstName First Name
	 * @param lastName Last Name
	 * @param id ID number
	 * @param email Student Email
	 * @param password Hashed Password
	 * @param maxCredits Maximum credits
	 */
	public Student(String firstName, String lastName, String id, String email, String password, int maxCredits) {

		setFirstName(firstName);
		setLastName(lastName);
		setId(id);
		setEmail(email);
		setPassword(password);
		setMaxCredits(maxCredits);
	}
	
	/**
	 * Constructs Student class, setting maxCredits to default 18.
	 * @param firstName First Name
	 * @param lastName Last Name
	 * @param id ID number
	 * @param email Student Email
	 * @param password Hashed Password
	 */
	public Student(String firstName, String lastName, String id, String email, String password) {
		this(firstName, lastName, id, email, password, MAX_CREDITS);
	}
	
	/**
	 * Returns the student's first name.
	 * @return firstName Student's First Name
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Returns the student's email.
	 * @return email Students email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets student email.
	 * @param email Students email
	 * @throws IllegalArgumentException For invalid email addresses
	 */
	public void setEmail(String email) {
		if (email == null || email.equals("")) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (!email.contains("@") || !email.contains(".")) {
			throw new IllegalArgumentException("Invalid email");
		}
		if (email.lastIndexOf('.') < email.lastIndexOf('@')) {
			throw new IllegalArgumentException("Invalid email");
		}
		this.email = email;
	}

	/**
	 * Returns the student's password.
	 * @return password Student password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the Student password.
	 * @param password Student Password
	 * @throws IllegalArgumentException if password is null or empty
	 */
	public void setPassword(String password) {
		if (password == null || password.equals("")) {
			throw new IllegalArgumentException("Invalid password");
		}
		this.password = password;
	}

	/**
	 * Returns the max credits.
	 * @return maxCredits max credits
	 */
	public int getMaxCredits() {
		return maxCredits;
	}

	/**
	 * Sets the max credits of Student.
	 * @param maxCredits max credits
	 * @throws IllegalArgumentException if max credits are less than 3 or greater than 18
	 */
	public void setMaxCredits(int maxCredits) {
		if (maxCredits < 3 || maxCredits > 18) {
			throw new IllegalArgumentException("Invalid max credits");
		}
		this.maxCredits = maxCredits;
	}

	/**
	 * Sets the Student first name.
	 * @param firstName Student first name
	 * @throws IllegalArgumentException if first name is null or empty
	 */
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.equals("")) {
			throw new IllegalArgumentException("Invalid first name");
		}
		this.firstName = firstName;
	}

	/**
	 * Sets the Student last name.
	 * @param lastName Student last name
	 * @throws IllegalArgumentException if last name is null or empty
	 */
	public void setLastName(String lastName) {
		if (lastName == null || lastName.equals("")) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}

	/**
	 * Sets the student id no.
	 * @param id student id
	 * @throws IllegalArgumentException if id is null or empty
	 */
	private void setId(String id) {
		if (id == null || id.equals("")) {
			throw new IllegalArgumentException("Invalid id");
		}
		this.id = id;
	}

	/**
	 * Returns a string representation of Student details.
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "" + firstName + "," + lastName + "," + id + "," + email + "," + password + "," + maxCredits;
	}

	/**
	 * Returns the hash code of Student details.
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + maxCredits;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	/**
	 * Returns true if the student objects are equal.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (maxCredits != other.maxCredits)
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	/**
	 * Returns the Student last name. 
	 * @return lastName last name
	 */
	public String getLastName() {
		// TODO Auto-generated method stub
		return lastName;
	}
	
	/**
	 * Returns the Student id.
	 * @return id student id
	 */
	public String getId() {
		// TODO Auto-generated method stub
		return id;
	}

//	@Override
//	public int compareTo(Student student) {
//		int test = this.toString().compareTo(student.toString());
//		if(test > 0) {
//			return 1;
//		} else if(test == 0) {
//			return 0;
//		} else {
//			return -1;
//		}
//		
//	}
	
	@Override
	public int compareTo(Student student) {
		String first = student.getFirstName();
		String last = student.getLastName();
		String testID = student.getId();
		if(this.getLastName().compareTo(last) > 0) {
			return 1;
		} else if (this.getLastName().compareTo(last) < 0) {
			return -1;
		} else {
			if(this.getFirstName().compareTo(first) > 0) {
				return 1;
			} else if(this.getFirstName().compareTo(first) < 0) {
				return -1;
			} else {
				if(this.getId().compareTo(testID) > 0) {
					return 1;
				} else if(this.getId().compareTo(testID) < 0) {
					return -1;
				} else {
					return 0;
				}
			}
		}
	}

}
