package edu.ncsu.csc216.pack_scheduler.user;

import static org.junit.Assert.*;


import org.junit.Test;

/**
 * 
 * JUnit tests for the Student class
 *
 * @author Joshua Cowles (jlcowles)
 * @author Amiya Renavikar
 * 
 */
public class StudentTest  {

	/**
	 * Tests the hashcode function
	 */
	@Test
	public void testHashCode() {
		
		Student s1 = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		Student s2 = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		Student s3 = new Student("firstOne", "lastOne", "id1", "email123@ncsu.edu", "password");
		//Test for the same hash code for the same values
				assertEquals(s1.hashCode(), s2.hashCode());
				
				//Test for each of the fields
				assertNotEquals(s1.hashCode(), s3.hashCode());
				assertNotEquals(s2.hashCode(), s3.hashCode());
		
	}

	/**
	 * Tests the full student constructor
	 */
	@Test
	public void testStudentStringStringStringStringStringInt() {
		Student s1 = new Student("first", "last", "id", "email@gmail.com", "pass", 18);
		assertEquals("first", s1.getFirstName());
		assertEquals("last", s1.getLastName());
		assertEquals("id", s1.getId());
		assertEquals("email@gmail.com", s1.getEmail());
		assertEquals("pass", s1.getPassword());
		assertEquals(18, s1.getMaxCredits());
		
		Student s = null; //Initialize a student reference to null
		try {
		    s = new Student(null, "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", null, "id", "email@ncsu.edu", "hashedpassword", 18);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", null, "email@ncsu.edu", "hashedpassword", 18);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		
		try {
		    s = new Student("first", "last", "", "email@ncsu.edu", "hashedpassword", 18);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", "id", "invalidEmail", "hashedpassword", 18);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", "id", "email@ncsu.edu", null, 18);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 27);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
	}

	/**
	 * Tests the Student constructor with the default MAX_CREDITS
	 */
	@Test
	public void testStudentStringStringStringStringString() {
		Student s1 = new Student("first", "last", "id", "email@gmail.com", "pass");
		assertEquals("first", s1.getFirstName());
		assertEquals("last", s1.getLastName());
		assertEquals("id", s1.getId());
		assertEquals("email@gmail.com", s1.getEmail());
		assertEquals("pass", s1.getPassword());
		
		Student s = null; //Initialize a student reference to null
		try {
		    s = new Student(null, "last", "id", "email@ncsu.edu", "hashedpassword");
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", null, "id", "email@ncsu.edu", "hashedpassword");
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", null, "email@ncsu.edu", "hashedpassword");
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", "id", "invalidEmail", "hashedpassword");
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		s = null; //Initialize a student reference to null
		try {
		    s = new Student("first", "last", "id", "email@ncsu.edu", null);
		    //Note that for testing purposes, the password doesn't need to be hashedpassword
		    fail(); //If we reach this point a Student was constructed when it shouldn't have been!
		} catch (IllegalArgumentException e) {
		    //We should get here if the expected IllegalArgumentException is thrown, but that's not enough
		    //for the test.  We also need to make sure that the reference s is still null!
		    assertNull(s);
		}
		
	}

	/**
	 * Tests setEmail()
	 */
	@Test
	public void testSetEmail() {
		Student s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		s.setEmail("email2@ncsu.edu");
		assertEquals(s.getEmail(), "email2@ncsu.edu");
		s = null;
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setEmail(null);
			fail("Email set to null!");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getEmail(), "email@ncsu.edu");
		}
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setEmail("emailncsu.edu");
			fail("Email doesn't contain an @ character!");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getEmail(), "email@ncsu.edu");
		}
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setEmail("email@ncsuedu");
			fail("Email doesnt contain a . ");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getEmail(), "email@ncsu.edu");
		}
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setEmail("email.email@ncsuedu");
			fail("the index of the last '.' character in the email string is earlier than the index of the first '@' character");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getEmail(), "email@ncsu.edu");
		}
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setEmail("");
			fail("empty String");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getEmail(), "email@ncsu.edu");
		}
	}

	/**
	 * Tests setPassword()
	 */
	@Test
	public void testSetPassword() {
		Student s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		s.setPassword("123");
		assertEquals(s.getPassword(), "123");
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setPassword("");
			fail("empty String for password");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getPassword(), "hashedpassword");
		}
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setPassword(null);
			fail("password can't be null!");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getPassword(), "hashedpassword");
		}
	}

	/**
	 * Tests setMaxCredits()
	 */
	@Test
	public void testSetMaxCredits() {
		Student s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		s.setMaxCredits(15);
		assertEquals(s.getMaxCredits(), 15);
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setMaxCredits(2);
			fail("Max credit not below 3!");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getMaxCredits(), 18);
		}
		
		try {
			s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
			s.setMaxCredits(19);
			fail("Max credit greater than 18!");
		} catch (IllegalArgumentException e) {
			assertEquals(s.getMaxCredits(), 18);
		}
	}

	/**
	 * Tests setFirstName
	 */
	@Test
	public void testSetFirstName() {
		Student s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		try {
		    s.setFirstName(null);
		    fail(); //We don't want to reach this point - an exception should be thrown!
		} catch (IllegalArgumentException e) {
		    //We've caught the exception, now we need to make sure that the field didn't change
		    assertEquals("first", s.getFirstName());
		}
		
		s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		try {
		    s.setFirstName("");
		    fail(); //We don't want to reach this point - an exception should be thrown!
		} catch (IllegalArgumentException e) {
		    //We've caught the exception, now we need to make sure that the field didn't change
		    assertEquals("first", s.getFirstName());
		}
		
		s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		s.setFirstName("firstOne");
		assertEquals(s.getFirstName(), "firstOne");
	}

	/**
	 * Tests setLastName()
	 */
	@Test
	public void testSetLastName() {
		Student s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		try {
		    s.setLastName(null);
		    fail(); //We don't want to reach this point - an exception should be thrown!
		} catch (IllegalArgumentException e) {
		    //We've caught the exception, now we need to make sure that the field didn't change
		    assertEquals("last", s.getLastName());
		}
		
		s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		try {
		    s.setLastName("");
		    fail(); //We don't want to reach this point - an exception should be thrown!
		} catch (IllegalArgumentException e) {
		    //We've caught the exception, now we need to make sure that the field didn't change
		    assertEquals("last", s.getLastName());
		}
		
		s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		s.setLastName("lastOne");
		assertEquals(s.getLastName(), "lastOne");
	}
	
	

	/**
	 * Tests toString
	 */
	@Test
	public void testToString() {
		Student s = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword", 18);
		
		String s1 = "first,last,id,email@ncsu.edu,hashedpassword,18";
		assertEquals(s1, s.toString());
	}

	/**
	 * Tests the student equals method
	 */
	@Test
	public void testEqualsObject() {
		Student s1 = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		Student s2 = new Student("first", "last", "id", "email@ncsu.edu", "hashedpassword");
		Student s3 = new Student("firstOne", "lastOne", "id1", "email123@ncsu.edu", "password");
		
		//Test for equality in both directions
		assertTrue(s1.equals(s2));
		
		//Test for each of the fields
		assertFalse(s1.equals(s3));
		assertFalse(s2.equals(s3));

	}
	
	/**
	 * Tests compareTo method
	 */
	@Test
	public void testCompareTo() {
		Student s1 = new Student("Zarik", "AFirstName", "Aid", "email@ncsu.edu", "hashedpassword");
		Student s2 = new Student("Alice", "AFirstName", "Aid", "email@ncsu.edu", "hashedpassword");
		Student s3 = new Student("Alice", "AFirstName", "Zid", "email@ncsu.edu", "hashedpassword");
		Student s4 = new Student("Zarik", "AFirstName", "Aid", "email@ncsu.edu", "hashedpassword");
		
		assertEquals(s1.compareTo(s2), 1);
		assertEquals(s2.compareTo(s3), -1);
		assertEquals(s1.compareTo(s4), 0);
		
		
	}

}
