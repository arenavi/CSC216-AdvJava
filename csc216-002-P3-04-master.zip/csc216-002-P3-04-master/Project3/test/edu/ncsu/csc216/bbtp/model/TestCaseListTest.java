package edu.ncsu.csc216.bbtp.model;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

/**
 * Tests the TestCaseList class.
 * @author arenavi, jlcowles
 */
public class TestCaseListTest {
	
	private static final Date CASE_DATE_1 = new Date();
	private static final String CASE_DESC = "testDesc";
	private static final TestingType CASE_TYPE = new TestingType("TypeID", "TypeName", "TypeDesc");
	private static final String CASE_EXP = "expected";
	private static final String CASE_ACT = "actual";
    private Date caseDate2;

	private static final String NAME = "TestName";
	private static final String TEST_ID = "TestID";
	
	/**
	 * Tests the testCaseList Class.
	 */
	@Test
	public void testTestCaseList() {
		TestCaseList list = new TestCaseList(NAME, TEST_ID);
		
		assertEquals(NAME, list.getName());
		
		try {
			list.setName("");
		} catch (IllegalArgumentException e) {
			assertEquals(NAME, list.getName());
		}
		try {
			list.setName(null);
		} catch (IllegalArgumentException e) {
			assertEquals(NAME, list.getName());
		}
		
		list.setName(NAME + "2");
		assertEquals(NAME + "2", list.getName());
		
		assertEquals(TEST_ID, list.getTestCaseListID());
		assertEquals(0, list.size());
		assertTrue(list.isEmpty());
		
		try {
			Thread.sleep(50);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		caseDate2 = new Date();
		
		assertTrue(list.addTestCase(CASE_DESC, CASE_TYPE, CASE_DATE_1, CASE_EXP, false, caseDate2, CASE_ACT, false));
		assertFalse(list.isEmpty());
		assertEquals(1, list.size());
		assertEquals(0, list.indexOf(TEST_ID + "-TC1"));
		
		try {
			list.getTestCaseAt(-1);
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, list.size());
		}
		try {
			list.getTestCaseAt(5);
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, list.size());
		}
		
		assertEquals(CASE_DESC, list.getTestCaseAt(0).getDescription());
		assertEquals(0, list.indexOf(TEST_ID  + "-TC" + 1));
		
		assertEquals(CASE_DESC, list.get2DArray()[0][1]);
		
		assertTrue(list.addTestCase(CASE_DESC + "2", CASE_TYPE, CASE_DATE_1, CASE_EXP, true, CASE_DATE_1, CASE_ACT, false));
		assertTrue(list.addTestCase(CASE_DESC + "3", CASE_TYPE, CASE_DATE_1, CASE_EXP, true, CASE_DATE_1, CASE_ACT, false));
		assertEquals(CASE_DESC + "2", list.removeTestCaseAt(0).getDescription());
		assertTrue(list.addTestCase(CASE_DESC + "4", CASE_TYPE, CASE_DATE_1, CASE_EXP, false, null, CASE_ACT, false));
		assertEquals(CASE_DESC + "4", list.removeTestCaseAt(0).getDescription());
		assertTrue(list.removeTestCase(TEST_ID  + "-TC" + 1));
		assertTrue(list.addTestCase(CASE_DESC + "3", CASE_TYPE, CASE_DATE_1, CASE_EXP, false, CASE_DATE_1, CASE_ACT, false));
	}
}
