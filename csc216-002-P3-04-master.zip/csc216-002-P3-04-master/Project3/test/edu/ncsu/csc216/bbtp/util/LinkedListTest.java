package edu.ncsu.csc216.bbtp.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the LinkedList class.
 * @author arenavi, jlcowles
 */
public class LinkedListTest {
	
    /** Object 1 */
	Object obj1 = "string1";
	
	/** Object 2 */
	Object obj2 = "string2";
	
	/** Object 3 */
	Object obj3 = "string3";
	
	/** Object 4 */
	Object obj4 = "string4";

	/**
	 * Tests the LinkedList constructor.
	 */
	@Test
	public void testLinkedList() {
		LinkedList arr = null;
		try {
			arr = new LinkedList();
		} catch (IllegalArgumentException e) {
			assertNull(arr);
		}
		arr = new LinkedList();
		
		assertEquals(0, arr.size());
		assertTrue(arr.isEmpty());
		
		arr.add(obj1);
		assertTrue(arr.contains(obj1));
		assertFalse(arr.isEmpty());
		assertEquals(obj1, arr.get(0));
		
		assertFalse(arr.contains(null));
	}
	
	/**
	 * Tests the IO methods in LinkedList class.
	 */
	@Test
	public void testLinkedListIO() {
		LinkedList arr = new LinkedList();
		
		assertFalse(arr.contains(obj1));
		
		arr.add(obj1);
		try {
			arr.add(obj1);
			fail();
		} catch (IllegalArgumentException e) {
			assertEquals(1, arr.size());
		}
		try {
			arr.add(-1, obj2);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, arr.size());
		}
		try {
			arr.add(null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(1, arr.size());
		}
		
		arr.add(obj2);
		assertEquals(obj1, arr.get(0));
		assertEquals(obj2, arr.get(1));
		
		arr.add(0, obj3);
		assertEquals(obj3, arr.get(0));
		assertEquals(obj1, arr.get(1));
		assertEquals(obj2, arr.get(2));
		assertEquals(3, arr.size());
		assertEquals(2, arr.indexOf(obj2));
		
		assertEquals(0, arr.indexOf(obj3));
		arr.remove(0);
		assertEquals(2, arr.size());
		assertEquals(obj1, arr.get(0));
		assertEquals(obj2, arr.get(1));
		
		assertFalse(arr.contains(obj4));
		
		arr.add(1, obj3);
		assertEquals(obj3, arr.get(1));
		
		arr.remove(1);
		assertEquals(obj2, arr.get(1));
		assertEquals(2, arr.size());
		
		
		
	}
}
