package edu.ncsu.csc216.bbtp.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * A class for testing the TestingTypeList class.
 * @author jlcowles, arenavi
 */
public class TestingTypeListTest {
    
    /**
     * Tests all methods for testingTypeList.
     */
    @Test
    public void testTestingTypeList() {
        TestingTypeList l = new TestingTypeList();
        assertEquals("Testing Types", l.getName());
        assertEquals(0, l.size());
        assertTrue(l.isEmpty());
        
        //adding elements
        l.addTestingType("test", "for testing only");
        l.addTestingType("test", "for testing only");
        l.addTestingType("test", "for testing only");
        assertEquals(3, l.size());
        assertFalse(l.isEmpty());
        assertEquals("TT3", l.getTestingTypeAt(2).getTestingTypeID());
        
        try {
            l.getTestingTypeAt(-1);
            fail();
        } catch (IndexOutOfBoundsException e) {
            // do nothing
        }
        
        try {
            l.getTestingTypeAt(4);
            fail();
        } catch (IndexOutOfBoundsException e) {
            // do nothing
        }
        
        assertEquals(-1, l.indexOfName("abc"));
        assertEquals(0, l.indexOfName("test"));
        
        //remove elements
        assertFalse(l.removeTestingType("TTT"));
        assertTrue(l.removeTestingType("TT2"));
        assertEquals(2, l.size());
        
        //error at index -1
        try {
            l.removeTestingTypeAt(-1);
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(2, l.size());
        }
        try {
            l.removeTestingTypeAt(4);
            fail();
        } catch (IndexOutOfBoundsException e) {
            assertEquals(2, l.size());
        }
        
        assertEquals(new TestingType("TT1", "test", "for testing only"), l.removeTestingTypeAt(0));
        assertEquals(1, l.size());
        
        //2-D array
        TestingTypeList l2 = new TestingTypeList();
        
        l2.addTestingType("a", "badada");
        l2.addTestingType("a", "badada");
        l2.addTestingType("a", "badada");
        
        Object[][] arr = l2.get2DArray();
        
        for (int i = 0; i < l2.size(); i++) {
            assertEquals("TT" + (1 + i), arr[i][0]);
            assertEquals("a", arr[i][1]);
            assertEquals("badada", arr[i][2]);
        }
    }
}