package edu.ncsu.csc216.bbtp;

import static org.junit.Assert.*;
import java.util.Observable;

import org.junit.Test;

/**
 * Tests the BBTP class.
 * @author arenavi, jlcowles
 */
public class BBTPTest {
    
    /**
     * Tests the constructor of BBTP.
     */
    @Test
    public void testBBTPTest() {
        BBTP list = new BBTP();
        assertEquals(null, list.getFilename());
        assertEquals(1, list.getNumTestCaseLists());
    }
    
    /**
     * Tests the isChanged() method.
     */
    @Test
    public void testIsChanged() {
        BBTP list = new BBTP();
        assertFalse(list.isChanged());
        list.setChanged(true);
        assertTrue(list.isChanged());
    }
    
    /**
     * Tests the setFileName() method.
     */
    @Test
    public void testSetFileName() {
        BBTP list = new BBTP();
        //null filename
        try {
            list.setFilename(null);
            fail();
        } catch (IllegalArgumentException e) {
            //do nothing
        }
        
       //empty filename
        try {
            list.setFilename("");
            fail();
        } catch (IllegalArgumentException e) {
            //do nothing
        }
        
        list.setFilename("file.txt");
    }
    
    /**
     * Tests the getTestCaseList() method.
     */
    @Test
    public void testGetTestCaseList() {
        BBTP list = new BBTP();
        
        //index less than 0
        try {
            list.getTestCaseList(-1);
            fail();
        } catch (IndexOutOfBoundsException e) {
            //do nothing
        }
        
       //index less than or equal to testCase size
        try {
            list.getTestCaseList(0);
            
        } catch (IndexOutOfBoundsException e) {
        	fail();
        }
        
        try {
            list.getTestCaseList(1);
            fail();
        } catch (IndexOutOfBoundsException e) {
        	assertEquals(1, list.getNumTestCaseLists());
        }
        
        list.getTestingTypeList();
        
        //add 
        assertEquals(1, list.addTestCaseList());
        assertEquals(2, list.addTestCaseList());
        assertEquals(3, list.getNumTestCaseLists());
        assertEquals(3, list.addTestCaseList());
        
        //remove
        try {
            list.removeTestCaseList(-1);
            fail();
        } catch (IndexOutOfBoundsException e) {
            //nothing
        }
        
        try {
            list.removeTestCaseList(7);
            fail();
        } catch (IndexOutOfBoundsException e) {
            //do nothing
        }
        
        //remove valid
        list.removeTestCaseList(1);
        
        //save data file
        assertTrue(list.saveDataFile("test-files/examplelist.txt"));
        
        //null file name
        assertFalse(list.saveDataFile(null));
        
        //empty file name
        assertFalse(list.saveDataFile(""));
        
        BBTP b = new BBTP();
        b.saveDataFile("test-files/t.txt");
        
        BBTP newlist = new BBTP();
        newlist.openDataFile("test-files/t.txt");
        
        //update method coverage
        Observable obs = null;
        Object obj = null;
        list.update(obs, obj);
    }
    


}
