package edu.ncsu.csc216.bbtp.model;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the TestingType class.
 * @author jlcowles, arenavi
 */
public class TestingTypeTest {
    
    /**
     * Tests all methods for TestingType class.
     */
    @Test
    public void testingType() {
        TestingType type = null;
        //null id
        try {
            type = new TestingType(null, "amiya", "testing");
            fail();
        } catch (IllegalArgumentException e) {
            //do nothing
        }
        //blank id
        try {
            type = new TestingType("", "amiya", "testing");
            fail();
        } catch (IllegalArgumentException e) {
            //do nothing
        }
        //null name
        try {
            type = new TestingType("T123", null, "testing");
            fail();
        } catch (IllegalArgumentException e) {
            //do nothing
        }
        //blank name
        try {
            type = new TestingType("T123", "", "testing");
            fail();
        } catch (IllegalArgumentException e) {
            //do nothing
        }
        
        //valid test
        type = new TestingType("T123", "amiya", "testing");
        assertEquals("T123", type.getTestingTypeID());
        assertEquals("amiya", type.getName());
        assertEquals("testing", type.getDescription());
        
        type = new TestingType("T123", "sample", "testing");
        assertEquals("sample", type.toString());
        assertNotNull(type.hashCode());
        
        TestingType t1 = new TestingType("abc12", "a", "test");
        TestingType t2 = new TestingType("abc12", "a", "test");
        TestingType t3 = new TestingType("abc12", "ab", "test");
        assertEquals(0, t1.compareTo(t2));
        assertTrue(t1.equals(t2));
        assertNotNull(t1.equals(t3));
        
    }

}
