package edu.ncsu.csc216.bbtp.model;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

/**
 * Tests the TestCase class.
 * @author arenavi, jlcowles
 */
public class TestCaseTest {
    
    /**
     * Tests the testCase class.
     */
    @Test
    public void testTestCase() {
        
        Date s = new Date();
        Date en = new Date();
        TestingType t = new TestingType("T123", "arenavi", "hello");
        TestCase t1;
        //null id
        try {
            t1 = new TestCase(null, "hello", t, s, "exp", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //blank id
        try {
            t1 = new TestCase("", "hello", t, s, "exp", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //null description
        try {
            t1 = new TestCase("T123", null, t, s, "exp", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //empty description
        try {
            t1 = new TestCase("T123", "", t, s, "exp", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //null testing type
        try {
            t1 = new TestCase("T123", "hello", null, s, "exp", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //null expected results
        try {
            t1 = new TestCase("T123", "hello", t, s, null, false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //empty expected results
        try {
            t1 = new TestCase("T123", "hello", t, s, "", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //null creation date
        try {
            t1 = new TestCase("T123", "hello", t, null, "exp", false, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        
        //null actual results
        try {
            t1 = new TestCase("T123", "hello", t, s, "exp", true, en, null, true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //empty actual results
        try {
            t1 = new TestCase("T123", "hello", t, s, "exp", true, en, "", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        //tested is true actual results
        /*
        try {
            t1 = new TestCase("T123", "hello", t, s, "exp", true, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        
         //tested is true last creation date
        try {
            t1 = new TestCase("T123", "hello", t, s, "exp", true, en, "act", true);
            fail();
        } catch (IllegalArgumentException e) {
            // do nothing
        }
        */
       
        
        //valid test case
        t1 = new TestCase("T123", "hello", t, s, "exp", false, en, "act", true);
        assertEquals("T123", t1.getTestCaseID());
        assertEquals("hello", t1.getDescription());
        assertEquals("exp", t1.getExpectedResults());
        assertFalse(t1.tested());
        assertEquals(en, t1.getLastTestedDateTime());
        assertEquals(s, t1.getCreationDateTime());
        assertEquals("act", t1.getActualResults());
        assertTrue(t1.pass());
        
        //equals
        TestCase t2 = new TestCase("T123", "hello", t, s, "exp", false, en, "act", true);
        assertTrue(t1.equals(t2));
        assertEquals(0, t1.compareTo(t2));
        assertTrue(t1.hashCode() == t2.hashCode());
        TestCase t3 = new TestCase("T123", "hi", t, s, "expo", false, en, "act", true);
        assertEquals(2551165, t3.hashCode());
        
        TestingType type = new TestingType("TT6", "arenavi", "describe");
        t2 = new TestCase("T123", "hello", type, s, "exp", false, en, "act", true);
        assertEquals(new TestingType("TT6", "arenavi", "describe"), t2.getTestingType());
    }
}
