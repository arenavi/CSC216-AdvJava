package edu.ncsu.csc216.bbtp.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the ArrayList class.
 * @author arenavi, jlcowles
 */
public class ArrayListTest {
	
    /** Object 1 */
	Object obj1 = "string1";
	
	/** Object 2 */
	Object obj2 = "string2";
	
	/** Object 3 */
	Object obj3 = "string3";
	
	/** Object 4 */
	Object obj4 = "string4";

	/**
	 * Tests the ArrayList constructor.
	 */
	@Test
	public void testArrayList() {
		ArrayList arr = null;
		try {
			arr = new ArrayList(0);
		} catch (IllegalArgumentException e) {
			assertNull(arr);
		}
		arr = new ArrayList();
		
		assertEquals(0, arr.size());
		assertTrue(arr.isEmpty());
		
		arr.add(obj1);
		assertTrue(arr.contains(obj1));
		assertFalse(arr.isEmpty());
		assertEquals(obj1, arr.get(0));
		
		assertFalse(arr.contains(null));
	}
	
	/**
	 * Tests the IO methods in ArrayList class.
	 */
	@Test
	public void testArrayListIO() {
		ArrayList arr = new ArrayList();
		
		assertFalse(arr.contains(obj1));
		
		arr.add(obj1);
		try {
			arr.add(obj1);
		} catch (IllegalArgumentException e) {
			assertEquals(1, arr.size());
		}
		try {
			arr.add(-1, obj2);
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, arr.size());
		}
		try {
			arr.add(null);
		} catch (NullPointerException e) {
			assertEquals(1, arr.size());
		}
		
		arr.add(obj2);
		assertEquals(obj1, arr.get(0));
		assertEquals(obj2, arr.get(1));
		
		arr.add(0, obj3);
		assertEquals(obj3, arr.get(0));
		assertEquals(obj1, arr.get(1));
		assertEquals(obj2, arr.get(2));
		assertEquals(3, arr.size());
		
		assertEquals(0, arr.indexOf(obj3));
		arr.remove(0);
		assertEquals(2, arr.size());
		assertEquals(obj1, arr.get(0));
		assertEquals(obj2, arr.get(1));
		
		assertFalse(arr.contains(obj4));
		
		
		arr = new ArrayList(1);
		arr.add(obj1);
		arr.add(obj2);
		assertEquals(2, arr.size());
		
		arr = new ArrayList(1);
		arr.add(obj1);
		arr.add(0, obj2);
		assertEquals(2, arr.size());

		
	}
}
