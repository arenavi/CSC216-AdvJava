/**
 * 
 */
package edu.ncsu.csc216.bbtp;

import java.util.Observable;
import edu.ncsu.csc216.bbtp.model.TestingTypeList;
import edu.ncsu.csc216.bbtp.util.ArrayList;   

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Observer;

import edu.ncsu.csc216.bbtp.model.TestCaseList;


/**
 * The main class for the BBTP tools. Holds references to the top-level data
 * structures that contain TestCase and TestingType objects and acts as the
 * controller between the model and the GUI presentation view.
 * @author arenavi, jlcowles
 */
public class BBTP extends Observable implements Serializable, Observer {

	/** Serial version UID. */
	private static final long serialVersionUID = 34992L;
	/** Increment for increasing the capacity of the array of TestCaseLists */
    private static final int RESIZE = 3;
    /** A collection of TestCaseList */
    private TestCaseList[] testCases;
    /** Number of TestCaseList */
    private int numLists;
    /** A collection of TestingTypes */
    private TestingTypeList testingTypes;
    /** Filename for saving the bbtp information */
    private String filename;
    /** True if bbtp has changed since last save */
    private boolean changed;
    /** The next number for a task list id */
    private int nextTestCaseListNum = 1;

	/**
	 * Constructor for the BBTP
	 */
	public BBTP() {
		testCases = new TestCaseList[RESIZE];
		testCases[0] = new TestCaseList("New List", "TCL" + getNextTestCaseListNum());
		incNextTestCase();
		numLists++;
		testCases[0].addObserver(this);
		testingTypes = new TestingTypeList();
		testingTypes.addObserver(this);
		setChanged(false);
	}
	
	/**
	 * Returns whether the BBTP has been changed
	 * @return Whether it has been changed
	 */
	public boolean isChanged() {
		return changed;
	}
	
	/**
	 * Sets whether the class has been changed for the Observer design pattern
	 * @param bool The value changed is set too
	 */
	public void setChanged(boolean bool) {
		this.changed = bool;
	}
	
	/**
	 * Returns the filename the program reads and writes from
	 * @return The filename
	 */
	public String getFilename() {
		return filename;
	}
	
	/**
	 * Sets the filename the program reads/writes to
	 * @param name The string the filename is being set to
	 */
	public void setFilename(String name) {
		if(name == null || name.equals("")) {
			throw new IllegalArgumentException();
		}
		this.filename = name;
	}
	
	private int getNextTestCaseListNum() {
		return nextTestCaseListNum;
	}
	
	private void incNextTestCase() {
		nextTestCaseListNum++;
	}
	
	/**
	 * Gets the number of test case lists
	 * @return The number of test case lists
	 */
	public int getNumTestCaseLists() {
		return numLists;
	}
	
	/**
	 * Gets the TestCaseList at a given index
	 * @param idx The index to get from
	 * @return The TestCaseList stored at the given index
	 */
	public TestCaseList getTestCaseList(int idx) {
		if(idx < 0 || idx >= numLists) {
			throw new IndexOutOfBoundsException();
		}
		return testCases[idx];
	}
	
	/**
	 * Gets the TestingTypeList
	 * @return The list of TestingTypes
	 */
	public TestingTypeList getTestingTypeList() {
		return testingTypes;
	}
	
	/**
	 * Initializes and adds a new TestCaseList
	 * @return The index the list is added to
	 */
	public int addTestCaseList() {
		TestCaseList newList = new TestCaseList("New List", "TCL" + getNextTestCaseListNum());
		incNextTestCase();
		newList.addObserver(this);
		if(numLists == testCases.length) {
		    TestCaseList[] templist = new TestCaseList[(testCases.length + RESIZE)];
	        for(int i = 0; i < testCases.length; i++) {
	            templist[i] = testCases[i];
	        }
	        testCases = templist;
		}
		int ret = numLists;
		testCases[ret] = newList;
		numLists++;
		setChanged(true);
		notifyObservers(newList);
		return ret;
	}
	
	/**
	 * Removes the TestCaseList at the given index
	 * @param idx The index to remove from
	 */
	public void removeTestCaseList(int idx) {
		if(idx < 0 || idx >= numLists) {
			throw new IndexOutOfBoundsException();
		}
		for (int i = idx; i < testCases.length; i++) {
		    if (i + 1 >= testCases.length) {
		        testCases[i] = null;
		    } else {
		        testCases[i] = testCases[i + 1];
		    }
		}
		
		numLists--;
	}
	
	 /**
     * Saves the TestingTypeList and the array of TestCaseLists to the given
     * file using object serialization.
     * 
     * @param fname filename to save BBTP information to.
     * @return true is saved successfully
     */
    public boolean saveDataFile(String fname) {
        if (fname == null || fname.trim().equals("")) {
            System.err.println("Invalid filename" + fname);
            return false;
        } else {
            try {
                FileOutputStream fileOut = new FileOutputStream(fname);
                ObjectOutputStream out = new ObjectOutputStream(fileOut);
                for (int i = 0; i < numLists; i++) {
                    out.writeObject(testCases[i]);
                }
                out.writeObject(testingTypes);
                out.writeObject(filename);
                out.writeInt(nextTestCaseListNum);
                changed = false;
                out.close();
                fileOut.close();
                return true;
            } catch (IOException e) {
                System.err.println("An error occurred while saving file " + fname);
                e.printStackTrace(System.err);
                return false;
            }
        }
    }

    /**
     * Opens a data file with the given name and creates the data structures
     * from the serialized objects in the file.
     * 
     * @param fname filename to create BBTP information from.
     * @return true is opened successfully
     */
    public boolean openDataFile(String fname) {
        if (changed) {
            saveDataFile(filename);
        }
        try {
            FileInputStream fileIn = new FileInputStream(fname);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            ArrayList temp = new ArrayList();
            Object tl = in.readObject();
            while (tl instanceof TestCaseList) {
                TestCaseList l = (TestCaseList) tl;
                l.addObserver(this);
                temp.add(l);
                tl = in.readObject();
            }
            testCases = new TestCaseList[temp.size()];
            for (int i = 0; i < temp.size(); i++) {
                testCases[i] = (TestCaseList) temp.get(i);
            }
            numLists = temp.size();
            testingTypes = (TestingTypeList) tl;
            testingTypes.addObserver(this);
            filename = (String) in.readObject();
            nextTestCaseListNum = (int) in.readInt();
            for (int i = 0; i < numLists; i++) {
                TestCaseList list = testCases[i];
                for (int j = 0; j < list.size(); j++) {
                    list.getTestCaseAt(j).addObserver(list);
                }
            }
            for (int i = 0; i < testingTypes.size(); i++) {
                testingTypes.getTestingTypeAt(i).addObserver(testingTypes);
            }
            changed = false;
            in.close();
            fileIn.close();
            return true;
        } catch (IOException e) {
            System.err.println("An error occurred while reading file " + fname);
            e.printStackTrace(System.err);
            return false;
        } catch (ClassNotFoundException c) {
            System.err.println("Error reconstructing BBTP from file " + fname);
            c.printStackTrace(System.err);
            return false;
        }
    }

	/**
	 * Runs when a class this class is observing changes, and notifies the classes observing this one
	 * @param obs The object notifying
	 * @param obj The object passed to the notifyObservers method in the class notifying
	 */
	public void update(Observable obs, Object obj) {
		this.setChanged(true);
		setChanged();
		notifyObservers(obj);
	}	
}