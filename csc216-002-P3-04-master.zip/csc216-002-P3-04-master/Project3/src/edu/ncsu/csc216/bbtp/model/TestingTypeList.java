/**
 * 
 */
package edu.ncsu.csc216.bbtp.model;

import java.io.Serializable;
import java.util.Observable;
import java.util.Observer;

import edu.ncsu.csc216.bbtp.util.ArrayList;

/**
 * A TestingTypeList has an ArrayList of TestingTypes and maintains the list of TestingTypes.
 * @author arenavi, jlcowles
 */
public class TestingTypeList extends Observable implements Tabular, Serializable, Observer {

    /** Serial version UID */
	private static final long serialVersionUID = 984509L;
	
	/** Instance of ArrayList */
	private ArrayList list;
	
	/** Name */
	private String name = "Testing Types";
	
	/** Value appended to the next TestingType */
	private int nextTestingTypeNum;
	
	/**
	 * Constructs the ArrayList and sets nextTestingTypeNum to 1.
	 */
	public TestingTypeList() {
		list = new ArrayList();
		nextTestingTypeNum = 1;
	}
	
	/**
	 * Returns the TestingTypeList name.
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Returns true if the TestingType is added to the list and false otherwise.
	 * @param name TestingType name
	 * @param desc TestingType description
	 * @return true if the TestingType is added to the list and false otherwise
	 */
	public boolean addTestingType(String name, String desc) {
	    TestingType type = new TestingType("TT" + getNextTestingTypeNum(), name, desc);
	    type.addObserver(this);
	    
	    if (list.add(type)) {
	        incNextTestingTypeNum();
	        setChanged(); //Marks the Observable as changed
	        notifyObservers(this); //Sends a message to any Observer classes that the object has changed.
	        // The current instance is passed in except in specific instance listed in the detailed method descriptions, below.
	        return true;
	    } else {
	        return false;
	    }
	     
		
	}
	
	/**
	 * Returns the TestingType at the given index.
	 * @param idx The index whose TestingType is being returned
	 * @return The TestingType at the given index
	 */
	public TestingType getTestingTypeAt(int idx) {
	    if (idx < 0 || idx >= size()) {
	        throw new IndexOutOfBoundsException();
	    }
		return (TestingType) list.get(idx);
	}
	
	/**
	 * Returns the index of a TestingType with a ID.
	 * @param id The ID of the TestingType being searched for
	 * @return The index of the TestingType or -1 if there are no matches
	 */
	public int indexOf(String id) {
	    for (int i = 0; i < list.size(); i++) {
	        if (getTestingTypeAt(i).getTestingTypeID().equals(id)) {
	            return i;
	        }
	    }
		return -1;
	}
	
	/**
	 * Returns the index of the TestingType with a given name.
	 * @param name The name of the TestingType being looked for
	 * @return The index of the TestingType with a given name of -1 if there are no matches
	 */
	public int indexOfName(String name) {
	    for (int i = 0; i < list.size(); i++) {
	        if (getTestingTypeAt(i).getName().equals(name)) {
	            return i;
	        }
	    }
		return -1;
	}
	
	/**
	 * Returns the size of the list
	 * @return The size of the list
	 */
	public int size() {
		return list.size();
	}
	
	/**
	 * Returns whether the list is empty.
	 * @return true if the list is empty, false otherwise
	 */
	public boolean isEmpty() {
	    if (size() == 0) {
	        return true;
	    }
		return false;
	}
	
	/**
	 * Removes the TestingType at the given index
	 * @param idx The index of the TestingType to remove
	 * @return The TestingType at the index
	 */
	public TestingType removeTestingTypeAt(int idx) {
	    if (idx < 0 || idx >= size()) {
            throw new IndexOutOfBoundsException();
        }
        
        TestingType type = (TestingType) list.remove(idx); 
        type.deleteObserver(this);
        
        setChanged();
        notifyObservers(this);
        
        return type;
	}
	
	/**
	 * Removes the TestingType from the list with the given id.
	 * @param id The id of the TestingType to remove
	 * @return TestingType with the id is found and removed
	 */
	public boolean removeTestingType(String id) {
	    if (indexOf(id) == -1) {
	        return false;
	    }
	    
	    TestingType type = getTestingTypeAt(indexOf(id));
	    TestingType rm = (TestingType) list.remove(indexOf(id));
	    
	    rm.deleteObserver(this);
	    setChanged();
	    notifyObservers(this);
	    
		return type.equals(rm);
	}
	
	/**
	 * Returns the next TestingType number.
	 * @return nextTestingTypeNum next TestingType number
	 */
	private int getNextTestingTypeNum() {
		return nextTestingTypeNum;
	}
	
	/**
	 * Increments the next TestingType number.
	 */
	private void incNextTestingTypeNum() {
		nextTestingTypeNum++;
	}
	
	/**
	 * Returns an array consisting of all TestingTypes, their ids, names, and descriptions
	 * @return type Array of TestingType
	 */ 
	public Object[][] get2DArray() {
	    Object[][] type = new Object[size()][3];
	    
	    for (int i = 0; i < size(); i++) {
	        TestingType t = (TestingType) list.get(i);
	        type[i][0] = t.getTestingTypeID();
	        type[i][1] = t.getName();
	        type[i][2] = t.getDescription();
	    }
		return type;
	}
	
	/**
	 * If a TestingType in the list changes this method is automatically called to propagate the notification to TestingTypeList observers
	 * @param o The observable that changed
	 * @param arg The argument in notifyObservers(Object) called by the Observable 
	 */
	public void update(Observable o, Object arg) {
	    for (int i = 0; i < size(); i++) {
	        if (o.equals(list.get(i))) {
	            setChanged();
	            notifyObservers(arg);
	        }
	    }		
	}
}
