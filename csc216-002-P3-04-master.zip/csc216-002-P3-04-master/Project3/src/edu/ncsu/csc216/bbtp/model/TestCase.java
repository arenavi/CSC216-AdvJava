/**
 * 
 */
package edu.ncsu.csc216.bbtp.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Observable;


/**
 * A representation of a TestCase in the BBTP application. 
 * A TestCase has a TestingType.
 * @author arenavi, jlcowles
 */
public class TestCase extends Observable implements Serializable {

    /** Serial Version UID */
    private static final long serialVersionUID = 7459L;
	
	/** Test Case ID */
	private String testCaseID;
	
	/** Create Date Time */
	private Date creationDateTime;
	
	/** Test Case description */
	private String description;
	
	/** Expected Results */
	private String expectedResults;
	
	/** Actual Results */
	private String actualResults;
	
	/** Last Tested Date */
	private Date lastTestedDate;
	
	/** Test Status */
	private boolean testedStatus;
	
	/** Variable to check for passing */
	private boolean pass;
	
	/** Testing Type instance */
	private TestingType testingType;
	
	/**
	 * Constructs the Test Case class by calling setter methods.
	 * @param id Test Case id
	 * @param description Test Case description
	 * @param testingType Testing Type
	 * @param creationDateTime Creation Date and Time
	 * @param expectedResults Expected results
	 * @param tested Testing variable
	 * @param lastTestedDate Last Tested Date
	 * @param actualResults Actual results
	 * @param pass Passing variable
	 */
	public TestCase(String id, String description, TestingType testingType, Date creationDateTime, String expectedResults, boolean tested, Date lastTestedDate, String actualResults, boolean pass) {
		setDescription(description);
		setTestCaseID(id);
		setTestingType(testingType);
		setCreationDateTime(creationDateTime);
		setExpectedResults(expectedResults);
		setTestedStatus(tested);
		setLastTestedDateTime(lastTestedDate);
		setActualResults(actualResults);
		setPass(pass);
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Returns the Test Case description.
	 * @return description Test Case description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the Test Case description.
	 * @param description Test Case description 
	 * @throws IllegalArgumentException if description is null or empty
	 */
	public void setDescription(String description) {
	    if (description == null || description.equals("")) {
	        throw new IllegalArgumentException();
	    }
		this.description = description;
		setChanged(); //Marks the Observable as changed
		notifyObservers(this);
	}
	
	/**
	 * Returns the Expected Results.
	 * @return expectedResults Expected results from the test case
	 */
	public String getExpectedResults() {
		return expectedResults;
	}
	
	/**
	 * Sets the Expected Results of the test.
	 * @param expectedResults Expected results from the test case
	 * @throws IllegalArgumentException if expectedResults are null or an empty string
	 */
	public void setExpectedResults(String expectedResults) {
	    if (expectedResults == null || expectedResults.equals("")) {
            throw new IllegalArgumentException();
        }
        this.expectedResults = expectedResults;
        setChanged(); //Marks the Observable as changed
        notifyObservers(this);		
	}

	/**
	 * Returns the Creation Date and Time.
	 * @return the creationDateTime Creation Date and Time
	 */
	public Date getCreationDateTime() {
		return creationDateTime;
	}

	/**
	 * Sets the Creation Date and Time.
	 * @param creationDateTime the creationDateTime to set
	 * @throws IllegalArgumentException if creationDateTime is null
	 */
	public void setCreationDateTime(Date creationDateTime) {
	    if (creationDateTime == null) {
	        throw new IllegalArgumentException();
	    }
		this.creationDateTime = creationDateTime;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}

	/**
	 * Returns the Actual Results of the test.
	 * @return actualResults the actualResults to set
	 */
	public String getActualResults() {
		return actualResults;
	}

	/**
	 * Sets the Actual Results of the test.
	 * @param actualResults the actualResults to set
	 * @throws IllegalArgumentException if tested is true or actualResults is null or empty
	 */
	public void setActualResults(String actualResults) {
	    if (tested() && (actualResults == null || actualResults.equals("") || actualResults.trim().length() == 0)) {
	        throw new IllegalArgumentException();
	    }
		this.actualResults = actualResults;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}

	/**
	 * Returns the Last Tested Date.
	 * @return lastTestedDate Last Tested Date
	 */
	public Date getLastTestedDateTime() {
		return lastTestedDate;
	}

	/**
	 * Sets the Last Tested Date.
	 * @param lastTestedDate the lastTestedDate to set
	 */
	public void setLastTestedDateTime(Date lastTestedDate) {
	    if (tested() && lastTestedDate == null) {
	        throw new IllegalArgumentException();
	    }
		this.lastTestedDate = lastTestedDate;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}

	/**
	 * Returns the Tested Status.
	 * @return testedStatus the testedStatus to set
	 */
	public boolean tested() {
		return testedStatus;
	}

	/**
	 * Sets the Tested Status.
	 * @param testedStatus the testedStatus to set
	 */
	public void setTestedStatus(boolean testedStatus) {
		this.testedStatus = testedStatus;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Returns whether the test passed.
	 * @return pass Passing variable
	 */
	public boolean pass() {
		return pass;
	}
	
	/**
	 * Sets the passing variable.
	 * @param pass Passing variable
	 */
	public void setPass(boolean pass) {
	    this.pass = pass;
	    setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Sets the Testing type.
	 * @param t TestingType to set
	 */
	public void setTestingType(TestingType t) {
	    if (t == null) {
	        throw new IllegalArgumentException();
	    }
		this.testingType = t;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Returns the Testing type.
	 * @return testingType TestingType to set
	 */
	public TestingType getTestingType() {
		return testingType;
	}
	
	/**
	 * Returns the Test Case ID.
	 * @return testCaseID Test Case ID
	 */
	public String getTestCaseID() {
		return testCaseID;
	}
	
	/**
	 * Sets the Test Case ID.
	 * @param id Test Case ID
	 */
	private void setTestCaseID(String id) {
	    if (id == null || id.equals("")) {
	        throw new IllegalArgumentException();
	    }
	    this.testCaseID = id;
	    setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Returns true if two cases with the same id are equal.
	 * @param o Object
	 * @return true if both id's are the same
	 */
	@Override
	public boolean equals(Object o) {
	    if (this == o) {
	        return true;
	    } 
	    
	    if (o == null) {
	        return false;
	    }
	    
	    if (getClass() != o.getClass()) {
	        return false;
	    }
	    
	    TestCase t = (TestCase) o;
	    if (testCaseID == null) {
	        if (t.testCaseID != null) {
	            return false;
	        }
	    } else if (!(testCaseID.equals(t.testCaseID))) {
	        return false;
	    }
	    
		return true;
	}
	
	/**
	 * Returns the Test Case as a hash code.
	 * @return 0
	 */
	@Override
	public int hashCode() {
	    final int prime = 31;
	    int res = 1;
	    res = prime * res + ((testCaseID == null) ? 0 : testCaseID.hashCode());
		return res;
	}
	
	/**
	 * Compares two TestCases by their lastTestedDateTime and delegates to
	 * Date's compareTo method.
	 * @param c Test Case
	 * @return index of Test Case
	 */
	public int compareTo(TestCase c) {
		return lastTestedDate.compareTo(c.lastTestedDate);
	}		
}
