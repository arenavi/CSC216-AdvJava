/**
 * 
 */
package edu.ncsu.csc216.bbtp.ui;
import java.awt.Color;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import edu.ncsu.csc216.bbtp.model.TestCaseList;

/**
 * Controls the ListPane functionality of the program.
 * @author arenavi, jlcowles
 */
public class TestCaseListPane extends JScrollPane implements Observer {
    
    /** Serial Version UID */
    private static final long serialVersionUID = -2210716111020406799L;
    
    /** Instance of TestCaseList */
    private TestCaseList testCases;
    
    /** J Table */
    private JTable table;
    
    /** Column Widths */
    private int[] colWidths = {50, 50, 50, 50, 50, 50, 50};
    
    /** TestCaseTablemodel object */
    private TestCaseTableModel tctm;
    
    /**
     * Constructs the TestCaseListPane class by constructing the TestCaseTableModel object,
     * initializing view, and calling super().
     * @param testCases TestCaseList
     */
    public TestCaseListPane(TestCaseList testCases) {
        super();
        this.testCases = testCases;
        this.testCases.addObserver(this);
        tctm = new TestCaseTableModel(testCases.get2DArray());
        initView();      
    }
    
    /**
     * Returns the TestCaseTableModel object.
     * @return tctm TestCaseTableModel object
     */
    public TestCaseTableModel getTestCaseTableModel() {
        return tctm;
    }

    /**
     * Returns the JTable object.
     * @return table JTable object
     */
    public JTable getTable() {
        return table;
    }
    
    /**
     * Handles initial view of the List Pane.
     */
    private void initView() {
        table = new JTable(tctm);
        for (int i = 0; i < colWidths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(colWidths[i]);
        }
        int selectionMode = javax.swing.ListSelectionModel.SINGLE_SELECTION;
        table.setSelectionMode(selectionMode);
        table.setFillsViewportHeight(false);
        setViewportView(table);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }
    
    /**
     * Clears current selection.
     */
    public void clearSelection() {
        table.clearSelection();
    }
    
    /**
     * Updates the TestCaseListPane class.
     * @param o Observable
     * @param arg Object
     */
    public void update(Observable o, Object arg) {
        if (o instanceof TestCaseList) {
            testCases = (TestCaseList) o;
            if (testCases.size() != tctm.getRowCount()) {
                tctm = new TestCaseTableModel(testCases.get2DArray());
                table.setModel(tctm);
            } else {
                Object[][] obj = testCases.get2DArray();
                for (int i = 0; i < obj.length; i++) {
                    for (int j = 0; j < tctm.getColumnCount(); j++) {
                        tctm.setValueAt(obj[i][j], i, j);
                    }
                }
            }
        }
        
        
    }
}
