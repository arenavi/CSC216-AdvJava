/**
 * 
 */
package edu.ncsu.csc216.bbtp.ui;

import java.util.Date;

import javax.swing.table.AbstractTableModel;

import edu.ncsu.csc216.bbtp.model.TestingType;

/**
 * Implements the TaskTableModel and handles functionality
 * for the TestCaseTavleModel class.
 * @author arenavi, jlcowles
 */
public class TestCaseTableModel extends AbstractTableModel {
    
    /** Serial version UID */
    private static final long serialVersionUID = 5954551753060998701L;
    
    /** Column names */
    private String[] colNames = {"ID", "Description", "Testing Type", "Creation Date", "Last Tested Date", "Tested?", "Expected Results", "Actual Results", "Pass?"};
    
    /** Data object 2-D array */
    private Object[][] data;
    
    /**
     * Constructs the TestCaseTableModel class.
     * @param data Object 2-D array
     */
    public TestCaseTableModel(Object[][] data) {
        super();
        this.data = data;
    }
    
    /**
     * Returns Row count of the data.
     * @return row count as length
     */
    public int getRowCount() {
        return data.length;
    }

    /**
     * Returns Column count of the data.
     * @return count column length
     */
    public int getColumnCount() {
        int count = colNames.length;
        return count;
    }
    
    /**
     * Returns the Column Name.
     * @param col column
     * @return s column name
     */
    public String getColumnName(int col) {
        String s = colNames[col];
        return s;
    }
    
    /**
     * Returns value at specified row and column.
     * @param row Row
     * @param col Column
     * @return object at specified row and column
     */
    public Object getValueAt(int row, int col) {
        return data[row][col];
    }
    
    /**
     * Sets the value at specified row and column.
     * @param obj Object
     * @param row Row
     * @param col Column
     */
    public void setValueAt(Object obj, int row, int col) {
        data[row][col] = obj;
        fireTableCellUpdated(row, col);
    }
    
    /**
     * Returns the TestCaseRowData.
     * @param row row integer
     * @return The TestCaseData of the Row
     */
    public TestCaseData getTestCaseRowData(int row) {
    	
    	TestCaseData testGet = new TestCaseData(((String) data[row][0]), (String) data[row][1], (TestingType) data[row][2], (Date) data[row][3], (Date) data[row][4], ((Boolean) data[row][5]).booleanValue(), (String) data[row][6], (String) data[row][7], ((Boolean) data[row][8]).booleanValue());
        return testGet;
    }
    
    /**
     * Sets the Task row data.
     * @param row integer row
     * @param data TestCaseData
     */
    public void setTaskRowData(int row, TestCaseData data) {
        setValueAt(data.getTestCaseID(), row, 0);
        setValueAt(data.getTestingType(), row, 1);
        setValueAt(data.getDescription(), row, 2);
        
    }
}
