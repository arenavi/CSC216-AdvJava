/**
 * 
 */
package edu.ncsu.csc216.bbtp.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;

import edu.ncsu.csc216.bbtp.util.LinkedList;

/**
 * A TestCaseList has a LinkedList of TestCases and maintains the list of TestCases.
 * @author arenavi, jlcowles
 */
public class TestCaseList extends Observable implements Tabular, Serializable, Observer {
	
    /** Serial version UID */
	private static final long serialVersionUID = 98734509L;
	
	/** List Name */
	private String name;
	
	/** Next Test Case Number */
	private int nextTestCaseNum;
	
	/** Test Case List ID */
	private String testCaseListID;
	
	/** Instance of LinkedList */
	private LinkedList list;
	
	/**
	 * Constructs the TestCaseList class, sets the fields with respective
	 * parameter values, sets nextTestCaseNum to 1, and notifies Observers.
	 * @param name Name
	 * @param testCaseListID Test Case List ID
	 */
	public TestCaseList(String name, String testCaseListID) {
		setName(name);
		setTestCaseListID(testCaseListID);
		
		nextTestCaseNum = 1;
		list = new LinkedList();
		
		setChanged();
		notifyObservers(this);
	}
	
	/**
	 * Returns the TestCaseList name.
	 * @return name TestCaseList name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the TestCaselist name.
	 * @param name TestCaseList name
	 * @throws IllegalArgumentException if name is null or empty
	 */
	public void setName(String name) {
	    if (name == null || name.equals("")) {
	        throw new IllegalArgumentException();
	    }
		this.name = name;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Returns the TestCaseList id.
	 * @return testCaseListID TestCaseList id
	 */
	public String getTestCaseListID() {
		return testCaseListID;
	}
	
	/**
	 * Sets the TestCaseList id.
	 * @param testCaseListID TestCaseList id
	 */
	private void setTestCaseListID(String testCaseListID) {
	    if (testCaseListID == null || testCaseListID.equals("")) {
            throw new IllegalArgumentException();
        }
	    this.testCaseListID = testCaseListID;
	    setChanged(); //Marks the Observable as changed
        notifyObservers(this);
	}
	
	/**
	 * Returns the Next TestCase number.
	 * @return nextTestCaseNum Next TestCase number
	 */
    private int getNextTestCaseNum() {
		return nextTestCaseNum;
	}
	
	/**
	 * Increments the next TestCase number.
	 */
    private void incNextTestCaseNum() {
		nextTestCaseNum++;
	}
	
	/**
	 * Adds the TestCase to the TestCaseList and returns true if it is added,
	 * false otherwise.
	 * @param desc Description
	 * @param type Testing Type
	 * @param creation Creation Date and Time
	 * @param exp Expected Results
	 * @param tested Testing variable
	 * @param lastTestDate Last test date
	 * @param act Actual Results
	 * @param pass Passing variable
	 * @return true if TestCase is added to the list, false otherwise
	 */
	public boolean addTestCase(String desc, TestingType type, Date creation, String exp, boolean tested, Date lastTestDate, String act, boolean pass) {
		String id = testCaseListID + "-TC" + getNextTestCaseNum();
		incNextTestCaseNum();
		TestCase c = new TestCase(id, desc, type, creation, exp, tested, lastTestDate, act, pass);

		if(list.contains(c)) {
			return false;
		}
		if (lastTestDate == null) {
			int j = 0;
			for(int i = 0; i < list.size(); i++) {
				if(getTestCaseAt(i).getLastTestedDateTime() == null) {
					j++;
				}
			}
			list.add(j, c);
			setChanged();
			notifyObservers(this);
			return true;
		}
		for (int i = 0; i < list.size(); i++) {
			TestCase get = (TestCase) list.get(i);
			if (lastTestDate.compareTo(get.getLastTestedDateTime()) < 0) {
				setChanged();
				notifyObservers(this);
				list.add(i, c);
				return true;
			}
		}
		list.add(list.size(), c);
		setChanged();
		notifyObservers(this);
		return true;
	   
	    
	    
	    /*if(list.contains(c)) {
	    	return false;
	    }
	    if(list.size() == 0) {
	    	list.add(c);
	    	setChanged();
	    	notifyObservers(this);
	    	return true;
	    }
	    boolean added = false;
	    for(int i = 0; i < list.size(); i++) {
	    	if(added == false && (c.getLastTestedDateTime().before(((TestCase) list.get(i)).getLastTestedDateTime()) || i == list.size() || c.getLastTestedDateTime() == null)) {
	    		list.add(i, c);
	    		added = true;
	    		setChanged();
	    		notifyObservers(this);
	    	}
	    }
	    return added;
	    */
	}
	
	/**
	 * Returns the TestCase at the given index in the list.
	 * @param idx given index
	 * @return c TestCase found at index
	 */
	public TestCase getTestCaseAt(int idx) {
	    
	    if (idx >= size() || idx < 0) {
	        throw new IndexOutOfBoundsException();
	    }
	    
	    TestCase c = (TestCase) list.get(idx);
	    return c;
	}
	
	/**
	 * Returns the index of the first occurrence of a TestCase that has an exact match to the provided id 
	 * or -1 if there are no TestCases with an exact match on the given id. 
	 * @param id Test case id
	 * @return index of the first occurrence of a TestCase or -1 if there are no TestCases with an exact match
	 */
	public int indexOf(String id) {
	    for (int i = 0; i < list.size(); i++) {
	        if (getTestCaseAt(i).getTestCaseID().equals(id)) {
	            return i;
	        }
	    }
		return -1;
	}
	
	/**
	 * Returns the number of TestCases in the list.
	 * @return size of the list
	 */
	public int size() {
		return list.size();
	}
	
	/**
	 * Returns true if the list is empty and false otherwise.
	 * @return true if the list is empty and false otherwise
	 */
	public boolean isEmpty() {
	    if (size() == 0) {
	        return true;
	    }
		return false;
	}
	
	/**
	 * Returns the TestCase removed from the list at the given index 
	 * and Observers of TestCaseList are notified of the change.
	 * @param idx given index
	 * @return c Test Case that is removed
	 */
	public TestCase removeTestCaseAt(int idx) {
	    if (idx < 0 || idx >= size()) {
	        throw new IndexOutOfBoundsException();
	    }
	    
	    getTestCaseAt(idx).deleteObserver(this);
	    setChanged();
	    notifyObservers(this);
	    TestCase c = (TestCase) list.remove(idx);
		return c;
	}
	
	/**
	 * Removes the first occurrence of the TestCase with the given TestCaseID from the list. 
	 * Returns false if there is no such TestCase.
	 * @param testCaseID TestCase ID
	 * @return first occurrence of the TestCase with the given TestCase, false is no TestCase exists
	 */
	public boolean removeTestCase(String testCaseID) {
	    int idx = indexOf(testCaseID);
	    if( idx == -1) {
	        return false;
	    }
	    
	    TestCase t = getTestCaseAt(idx);
	    t.deleteObserver(this);
	    boolean bool = t.equals(list.remove(idx));
	    setChanged();
	    notifyObservers(this);
	  
		return bool;
	}
	
	/**
	 * Returns an Object[] array.
	 * @return testCase Object[] array
	 */
	public Object[][] get2DArray() {
	    Object[][] testCase = new Object[size()][9];
	    
	    for (int i = 0; i < size(); i++) {
	        TestCase c = (TestCase) list.get(i);
	        testCase[i][0] = c.getTestCaseID();
	        testCase[i][1] = c.getDescription();
	        testCase[i][2] = c.getTestingType();
	        testCase[i][3] = c.getCreationDateTime();
	        testCase[i][4] = c.getLastTestedDateTime();
	        testCase[i][5] = c.tested();
	        testCase[i][6] = c.getExpectedResults();
	        testCase[i][7] = c.getActualResults();
	        testCase[i][8] = c.pass();
	    }
	    
		return testCase;
	}
	
	/**
	 * Updates the TestCaseList for any changes.
	 * @param o Observable
	 * @param arg Object
	 */
	public void update(Observable o, Object arg) {
		for (int i = 0; i < size(); i++) {
		    if (o.equals(list.get(i))) {
		        setChanged();
		        notifyObservers(arg);
		    }
		}
	}

}