/**
 * 
 */
package edu.ncsu.csc216.bbtp.model;

import java.io.Serializable;
import java.util.Observable;

/**
 * A representation of a TestingType in the BBTP application.
 * @author arenavi, jlcowles
 */
public class TestingType extends Observable implements Serializable {

    /** Serial version UID */
	private static final long serialVersionUID = 459188L;
	
	/** Type name */
	private String name;
	
	/** Type description */
	private String description;
	
	/** Testing type ID */
	private String testingTypeID;
	
	/**
	 * Constructs the TestingType class with the provided parameters.
	 * @param id Id
	 * @param name Name
	 * @param desc Description
	 * @throws IllegalArgumentException if id, name, desc are null or empty
	 */
	public TestingType(String id, String name, String desc) {
		setTestingTypeID(id);
	    setName(name);
	    setDescription(desc);
	    
	    setChanged(); //Marks the Observable as changed
	    notifyObservers(this); //Sends a message to any Observer classes that the object has changed.
	    // The current instance is passed in except in specific instance listed in the detailed method descriptions, below.
	}
	
	/**
	 * Returns the name of the Testing Type.
	 * @return name Type name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name of the Testing Type.
	 * @param name Type name
	 * @throws IllegalArgumentException is name is null or empty
	 */
	public void setName(String name) {
	    if (name == null || name.equals("")) {
	        throw new IllegalArgumentException();
	    }
		this.name = name;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this); //Sends a message to any Observer classes that the object has changed.
        // The current instance is passed in except in specific instance listed in the detailed method descriptions, below.
	}
	
	/**
	 * Returns the description of the Testing Type.
	 * @return description Type description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description of the Testing Type.
	 * @param desc Type description
	 */
	public void setDescription(String desc) {
		this.description = desc;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this); //Sends a message to any Observer classes that the object has changed.
        // The current instance is passed in except in specific instance listed in the detailed method descriptions, below.
	}
	
	/**
	 * Returns the Testing Type ID.
	 * @return testingTypeID Type id
	 */
	public String getTestingTypeID() {
		return testingTypeID;
	}
	
	/**
	 * Sets the id of the Testing Type.
	 * @param id Type id
	 * @throws IllegalArgumentException if id is null or empty
	 */
	private void setTestingTypeID(String id) {
	    if (id == null || id.equals("")) {
            throw new IllegalArgumentException();
        }
		this.testingTypeID = id;
		setChanged(); //Marks the Observable as changed
        notifyObservers(this); //Sends a message to any Observer classes that the object has changed.
        // The current instance is passed in except in specific instance listed in the detailed method descriptions, below.
	}
	
	/**
	 * Returns if two testing types are the same by matching their id.
	 * @param o The object being checked
	 * @return Whether the objects are equivalent
	 */
	public boolean equals(Object o) {
	    if (this == o) {
            return true;
        } 
        
        if (o == null) {
            return false;
        }
        
        if (getClass() != o.getClass()) {
            return false;
        }
        
        TestingType t = (TestingType) o;
        if(this.getTestingTypeID().equals(t.getTestingTypeID())) {
            return true;
        }
        
        return false;
	}
	
	/**
	 * Compares two Testing Types by their id.
	 * @param c Testing Type
	 * @return index of Testing Type
	 */
	public int compareTo(TestingType c) {
		return this.getTestingTypeID().compareTo(c.getTestingTypeID());
	}
	
	/**
	 * Returns hashcode of Testing Type.
	 * @return result resulting Hashcode
	 */
	public int hashCode() {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((testingTypeID == null) ? 0 : testingTypeID.hashCode());
	    result = prime * result + ((name == null) ? 0 : name.hashCode());
	    result = prime * result + ((description == null) ? 0 : description.hashCode());
		return result;
	}
	
	/**
	 * Returns the Testing Type as a String.
	 * @return the name of the TestingType
	 */
	public String toString() {
		return getName();
	}
}
