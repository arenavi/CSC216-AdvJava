/**
 * 
 */
package edu.ncsu.csc216.bbtp.util;

import java.io.Serializable;

/**
 * A custom implementation of the LinkedList datatype, implements the teaching staff List interface.
 * @author arenavi, jlcowles
 */
public class LinkedList implements List, Serializable {
	
    /** Serial version UID */
	private static final long serialVersionUID = 349987L;
	
	private ListNode front;
	
	private int size;
	
	/**
	 * Constructs a new LinkedList
	 */
	public LinkedList() {
		front = new ListNode(null, null);
	}

	/**
	 * Returns the size of the list
	 * @return The size
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Returns whether the list is empty or not
	 * @return true if empty, otherwise false
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * Checks whether the list contains an object or not.
	 * @param obj The object being looked for
	 * @return True if the list contains the onject, false otherwise.
	 */
	@Override
	public boolean contains(Object obj) {
		if(obj == null) {
			return false;
		}
		ListNode iterate = front;
		for(int i = 0; i < size; i++) {
			if(obj.equals(iterate.data)) {
				return true;
			}
			iterate = iterate.next;
		}
		
		return false;
	}

	/**
	 * Adds an object to the end of the list
	 * @param element The object being added
	 * @return True if the object is added successfully
	 */
	@Override
	public boolean add(Object element) {
		if (element == null) {
		    throw new NullPointerException();
		}
		if(size == 0) {
			front.data = element;
			size++;
			return true;
		}
		
		if(contains(element)) {
			throw new IllegalArgumentException();
		}
		
		
		ListNode iterate = front;
		for(int i = 0; i < (size - 1); i++) {
			
			iterate = iterate.next;
		}
		iterate.next = new ListNode(element, null);
		size++;
		return true;
	}

	/**
	 * Returns the element at the given index of the list
	 * @param index The index being returned
	 * @return The object at the given index
	 */
	@Override
	public Object get(int index) {
		if (index < 0 || index >= size) {
		    throw new IndexOutOfBoundsException();
		}
		
		ListNode iterate = front;
		for(int i = 0; i < index; i++) {
			iterate = iterate.next;
		}
		
		return iterate.data;
	}

	/**
	 * Adds an element to a particular index, then shifts the other elements to compensate
	 * @param index The index to add an element
	 * @param element The element being added
	 */
	@Override
	public void add(int index, Object element) {
		if (element == null) {
		    throw new NullPointerException();
		}
		if (index < 0 || index > size) {
		    throw new IndexOutOfBoundsException();
		}
		if(contains(element)) {
			throw new IllegalArgumentException();
		}
		if(index == 0) {
			front = new ListNode(element, front);
			size++;
			return;
		}
		ListNode iterate = front;
		for(int i = 0; i < (index - 1); i++) {
			iterate = iterate.next;
		}
		iterate.next = new ListNode(element, iterate.next);
		size++;
		
	}

	/**
	 * Removes an object from the list and returns it, shifts other elements to compensate
	 * @param index The index of the element to remove
	 * @return The object removed
	 */
	@Override
	public Object remove(int index) {
		if (index < 0 || index >= size) {
		    throw new IndexOutOfBoundsException();
		}
		if(index == 0 && size > 1) {
			ListNode temp = front;
			front = front.next;
			size--;
			return temp.data;
		} else if (index == 0) {
			Object temp = front.data;
			front.data = null;
			size--;
			return temp;
		}
		ListNode iterate = front;
		for(int i = 0; i < (index - 1); i++) {
			iterate = iterate.next;
		}
		ListNode temp = iterate.next;
		iterate.next = iterate.next.next;
		size--;
		return temp.data;
	}

	/**
	 * Returns the index of a given object
	 * @param obj The object being searched for
	 * @return The index of the object
	 */
	@Override
	public int indexOf(Object obj) {
		ListNode iterate = front;
		for(int i = 0; i < (size); i++) {
			if(obj.equals(iterate.data)) {
				return i;
			}
			iterate = iterate.next;
		}
		return -1;
	}
	
	/**
	 * Private class representing the individual nodes of the LinkedList.
	 */
	private class ListNode implements Serializable {
	    
	    /** Serial version UID */
		private static final long serialVersionUID = 484909840L;
		
		/** Object */
		Object data;
		
		/** List node */
		ListNode next;
		
		/**
		 * ListNode constructor
		 * @param obj The object contained by the node
		 * @param node The next node referenced
		 */
		public ListNode(Object obj, ListNode node) {
			data = obj;
			next = node;
		}
	}

}
