/**
 * 
 */
package edu.ncsu.csc216.bbtp.ui;

import java.awt.Color;


import java.awt.FlowLayout;
import java.util.Date;
import java.util.EventListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentListener;

import edu.ncsu.csc216.bbtp.model.TestingType;
import edu.ncsu.csc216.bbtp.model.TestingTypeList;

/**
 * Controls functionality of the Edit Pane.
 * @author arenavi, jlcowles
 */
public class TestCaseEditPane extends JPanel implements Observer {
    
    /** Serial Version UID */
    private static final long serialVersionUID = 5479139338455751629L;
    
    /** Testing types */
    private TestingTypeList testingTypes;
    
    /** Test case ID */
    private JTextField testCaseID;
    
    /** tc Testing Type */
    private JComboBox<TestingType> tcTestingType;
    
    /** Expected Results */
    private JTextArea expectedResults;
    
    /** Actual Results */
    private JTextArea actualResults;
    
    /**TestCase description */
    private JTextArea testCaseDescription;
    
    /** Test creation date */
    private JSpinner testCreationDate;
    
    /** Test last tested date */
    private JSpinner testLastTestedDate;
    
    /** Tested variable */
    private JCheckBox tested;
    
    /** Passing variable */
    private JCheckBox pass;
    
    /** Add */
    private boolean add;
    
    /** Edit */
    private boolean edit;
    
    /** Data */
    private TestCaseData data;
    
    private JPanel firstPanel;
    
    /**
     * Constructs testingType, calls superclass constructor, adds observers, and initializes view.
     * @param testingTypes TestingTypelist
     */
    public TestCaseEditPane(TestingTypeList testingTypes) {
        this(new TestCaseData("", "", null, null, null, false, "", "", false), testingTypes);
    }
    
    /**
     * Constructs data and testingType.
     * @param data Test case data
     * @param testingTypes testing type list
     */
    public TestCaseEditPane(TestCaseData data, TestingTypeList testingTypes) {
        super();
        this.data = data;
        this.testingTypes = testingTypes;
        add = false;
        edit = false;
        init();
        
    }

    /**
     * Initializes the edit panel.
     */
    private void init() {
    	testingTypes.addObserver(this);
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        setBorder(BorderFactory.createLineBorder(Color.black));
        initView();
        fillFields();
        
    }
    
    /**
     * Initializes the view.
     */
    private void initView() {
        firstPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
        firstPanel.add(new JLabel("Test Case ID: ", SwingConstants.LEFT));
        firstPanel.add(getTestCaseID());
        firstPanel.add(new JLabel("Testing Type: ", SwingConstants.LEFT));
        firstPanel.add(getTestingType());

        firstPanel.add(new JLabel("Test Creation Date and Time: ", SwingConstants.LEFT));
        testCreationDate = new JSpinner(new SpinnerDateModel());
  
        firstPanel.add(getTestCreationDateSpinner());
        testCreationDate.setEditor(new JSpinner.DateEditor(testCreationDate, "EEE MMM dd, yyyy HH:MM"));
        this.add(firstPanel);
                
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(new JLabel("Description: ", SwingConstants.LEFT));
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(getTestCaseDescription());
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(new JLabel("Tested? ", SwingConstants.LEFT));
        tested = new JCheckBox();
        p.add(tested);
        p.add(new JLabel("Last Tested Date & Time: "));
        testLastTestedDate = new JSpinner(new SpinnerDateModel());
        testLastTestedDate.setEditor(new JSpinner.DateEditor(testLastTestedDate, "EEE MMM dd, yyyy HH:MM"));
        p.add(testLastTestedDate);
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(new JLabel("Expected Results: ", SwingConstants.LEFT));
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(getExpectedResults());
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(new JLabel("Actual Results: ", SwingConstants.LEFT));
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(getActualResults());
        this.add(p);
        
        p = new JPanel(new FlowLayout(FlowLayout.LEADING));
        p.add(new JLabel("Pass? ", SwingConstants.LEFT));
        pass = new JCheckBox();
        p.add(pass);
        this.add(p);
    }
    
    /**
     * Returns the test creation date.
     * @return testCreationDate creation date
     */
    protected JSpinner getTestCreationDateSpinner() {
        
        if (testCreationDate == null) {
            testCreationDate = new JSpinner(new SpinnerDateModel());
            JSpinner.DateEditor editor = new JSpinner.DateEditor(testCreationDate, "EEE MMM d, yyyy HH:mm");
            testCreationDate.setEditor(editor);
            testCreationDate.setValue(new Date());
            testCreationDate.setVisible(true);
        }
        
        return testCreationDate;
    }
   
    /**
     * Returns the last tested date.
     * @return testLastTestedDate last tested date
     */
    protected JSpinner getLastTestedDateSpinner() {
        if (testLastTestedDate == null) {
            testLastTestedDate = new JSpinner();
            testLastTestedDate.setValue(new Date());
            testLastTestedDate.setVisible(true);
        }
        return testLastTestedDate;
    }
    
    /**
     * Returns the testCreation date value.
     * @return testCreation date value
     */
    protected Date getTestCreationDate() {
        return (Date) testCreationDate.getModel().getValue();
    }
    
    
    /**
     * Returns the lastTestedDate date value.
     * @return testlastTestedDate date value
     */
    protected Date getLastTestedDate() {
        return (Date) testLastTestedDate.getModel().getValue();
    }
    
    /**
     * Returns the test case ID.
     * @return testCaseID test case ID
     */
    protected JTextField getTestCaseID() {
        if (testCaseID == null) {
            testCaseID = new JTextField(10);
            testCaseID.setVisible(true);
            testCaseID.setEditable(false);
            testCaseID.setHorizontalAlignment(SwingConstants.LEFT);
        }
        return testCaseID;
    }
    
    /**
     * Returns the test case description.
     * @return testCaseDescription test case description
     */
    protected JTextArea getTestCaseDescription() {
        if (testCaseDescription == null) {
            testCaseDescription = new JTextArea(5, 70);
            testCaseDescription.setEditable(false);
            testCaseDescription.setVisible(true);
            testCaseDescription.setLineWrap(true);
            testCaseDescription.setAutoscrolls(true);
        }
        return testCaseDescription;
    }
    
    /**
     * Returns the testing type.
     * @return tcTestingType testing type
     */
    protected JComboBox<TestingType> getTestingType() {
    	tcTestingType = new JComboBox<TestingType>();
    	for(int i = 0; i < testingTypes.size(); i++) {
        	tcTestingType.addItem(testingTypes.getTestingTypeAt(i));
    	}
        return tcTestingType;
    }
    
    /**
     * Returns the expected results.
     * @return expectedResults expected results 
     */
    protected JTextArea getExpectedResults() {
        if (expectedResults == null) {
            expectedResults = new JTextArea(5, 70);
            expectedResults.setEditable(false);
            expectedResults.setVisible(true);
            expectedResults.setLineWrap(true);
            expectedResults.setAutoscrolls(true);
        }
        return expectedResults;
    }
    
    /**
     * Returns the actual results.
     * @return actualResults actual results 
     */
    protected JTextArea getActualResults() {
        if (actualResults == null) {
            actualResults = new JTextArea(5, 70);
            actualResults.setEditable(false);
            actualResults.setVisible(true);
            actualResults.setLineWrap(true);
            actualResults.setAutoscrolls(true);
        }
        return actualResults;
        
    }
    
    /**
     * Returns the passing variable.
     * @return pass passing variable
     */
    protected JCheckBox pass() {
        if (this.pass == null) {
            pass = new JCheckBox();
            pass.setVisible(true);
        }
        return pass;
    }
    
    /**
     * Returns the tested variable.
     * @return tested tested variable
     */
    protected JCheckBox tested() {
        if (this.tested == null) {
            tested = new JCheckBox();
            tested.setVisible(true);
        }
        return tested;
    }
    
    /**
     * Sets the creation date and time.
     * @param date Date
     */
    protected void setCreationDateTime(Date date) {
        if (date == null) {
            getTestCreationDateSpinner().getModel().setValue(new Date());
            ((JSpinner.DateEditor)testCreationDate.getEditor()).getTextField().setVisible(false);
        } else {
            getTestCreationDateSpinner().getModel().setValue(date);
            ((JSpinner.DateEditor)testCreationDate.getEditor()).getTextField().setVisible(true);
        }
    }
    
    /**
     * Sets the last tested date and time.
     * @param date Date
     */
    protected void setLastTestedDateTime(Date date) {
        if (date == null) {
            getLastTestedDateSpinner().getModel().setValue(new Date());
            ((JSpinner.DateEditor)testLastTestedDate.getEditor()).getTextField().setVisible(false);
        } else {
            getLastTestedDateSpinner().getModel().setValue(date);
            ((JSpinner.DateEditor)testLastTestedDate.getEditor()).getTextField().setVisible(true);
        }
    }
    
    /**
     * Returns the add variable.
     * @return add add variable
     */
    protected boolean isAddMode() {
        return add;
    }
    
    /**
     * Returns the edit variable.
     * @return edit edit variable
     */
    protected boolean isEditMode() {
        return edit;
    }
    
    /**
     * Enables Add.
     */
    protected void enableAdd() {
    	if (!isAddMode()) {
            add = true;
            edit = false;
            clearFields();
        }
        add = true;
    }
    
    /**
     * Disables Add.
     */
    protected void disableAdd() {
    	add = false;
        clearFields();
    }
    
    /**
     * Enables Edit.
     * @param data TestCaseData
     */
    protected void enableEdit(TestCaseData data) {
    	if (!isEditMode()) {
            edit = true;
            add = false;
            this.data = data;
            fillFields();
        }
    }
    
    /**
     * Disables Edit. 
     */
    protected void disableEdit() {
        edit = false;
        clearFields();
    }
    
    /**
     * Return true if the fields are not empty, false otherwise.
     * @return false
     */
    protected boolean fieldsNotEmpty() {
        return (!testCaseDescription.getText().isEmpty() && tcTestingType.getSelectedItem() != null && testCreationDate.getValue() != null && !expectedResults.getText().isEmpty());
    }
    
    /**
     * Sets the TestCase data.
     * @param data TestCaseData
     */
    protected void setTestCaseData(TestCaseData data) {
        this.data = data;
        fillFields();
    }
    
    /**
     * Fills the fields.
     */
    protected void fillFields() {
        
        if (data == null) {
            testCaseID.setText("");
            testCaseDescription.setText("");
            testCreationDate.setValue(new Date());
            testLastTestedDate.setValue(new Date());
            tested.setSelected(false);
            pass.setSelected(false);
            expectedResults.setText("");
            actualResults.setText("");
            
        } else {
            testCaseID.setText(data.getTestCaseID());
            testCaseDescription.setText(data.getDescription());
            if(data.getCreationDateTime() != null) {
            	testCreationDate.setValue(data.getCreationDateTime());
            } else {
            	testCreationDate.setValue(new Date());
            }
            if(data.getLastTestedDateTime() != null) {
            	testLastTestedDate.setValue(data.getLastTestedDateTime());
            } else {
            	testLastTestedDate.setValue(new Date());
            }
            tested.setSelected(data.tested());
            expectedResults.setText(data.getExpectedResults());
            actualResults.setText(data.getActualResults());
            pass.setSelected(data.pass());
        }
        
        if (isAddMode() || isEditMode()) {
            testCaseDescription.setEditable(true);
            testCreationDate.setEnabled(true);
            tested.setEnabled(true);
            expectedResults.setEditable(true);
            actualResults.setEditable(true);
            pass.setEnabled(true);
            if(tested.isSelected()) {
            	testLastTestedDate.setEnabled(true);
            } else {
            	testLastTestedDate.setEnabled(false);
            }
         }
    }
    
    
    /**
     * Clears the fields.
     */
    protected void clearFields() {
        data = null;
        fillFields();
    }
    
    /**
     * Returns the fields.
     * @return fields
     */
    protected TestCaseData getFields() {
        return new TestCaseData(getTestCaseID().getText(), getTestCaseDescription().getText(), (TestingType)getTestingType().getSelectedItem(),
                getTestCreationDate(), getLastTestedDate(), tested().isSelected(), getExpectedResults().getText(), getActualResults().getText(), pass().isSelected());      
    }
    

    /**
     * Updates the class.
     */
    @Override
	public void update(Observable o, Object arg) {
		if(o instanceof TestingTypeList) {
			testingTypes = (TestingTypeList) o;
			tcTestingType = new JComboBox<TestingType>();
			
			 for(int i = 0; i < testingTypes.size(); i++) {
		        	tcTestingType.addItem(testingTypes.getTestingTypeAt(i));
		     }
			 this.removeAll();
			 initView();

		}
    }
    
    /**
     * Adds a field listener.
     * @param ev EventListener
     */
    protected void addFieldListener(EventListener ev) {
        testCaseDescription.getDocument().addDocumentListener((DocumentListener) ev);
        expectedResults.getDocument().addDocumentListener((DocumentListener) ev);
        ((JTextField) tcTestingType.getEditor().getEditorComponent()).getDocument().addDocumentListener((DocumentListener) ev);
    }
}