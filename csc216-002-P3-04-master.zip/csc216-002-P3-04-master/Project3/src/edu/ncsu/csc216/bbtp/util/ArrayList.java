/**
 * 
 */
package edu.ncsu.csc216.bbtp.util;

import java.io.Serializable;

/**
 * A custom implementation of the ArrayList datatype, implements the teaching staff List interface.
 * @author arenavi, jlcowles
 */
public class ArrayList implements List, Serializable {
	
    /** Serial version UID */
	private static final long serialVersionUID = 28592L;
	
	/** Resize variable */
	private static final int RESIZE = 10;
	
	/** List object */
	private Object[] list;
	
	/** Size variable */
	private int size;

	/**
	 * Constructs a new ArrayList to the default size.
	 */
	public ArrayList() {
		this(RESIZE);
	}
	
	/**
	 * Constructs a new ArrayList to the given size and
	 * constructs a new Object of size size.
	 * @param size size of ArrayList
	 * @throws IllegalArgumentException if size is equal to 0
	 */
	public ArrayList(int size) {
	    if (size == 0) {
	        throw new IllegalArgumentException();
	    }
	    
	    this.size = 0;
	    list = new Object[size];
		
	}
	/**
	 * Returns the size of the list.
	 * @return size size of Arraylist
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Returns whether the list is empty or not.
	 * @return true if empty, otherwise false
	 */
	@Override
	public boolean isEmpty() {
	    if (size == 0) {
	        return true;
	    }
		return false;
	}

	/**
	 * Checks whether the list contains an object or not.
	 * @param obj The object being looked for
	 * @return True if the list contains the object, false otherwise.
	 */
	@Override
	public boolean contains(Object obj) {
	    if (obj == null) {
	        return false;
	    }
	    
	    if (list.length == 0) {
	        return false;
	    }
	    
	    for (int i = 0; i < size; i++) {
	        if (obj.equals(list[i])) {
	            return true;
	        }
	    }
	    
		return false;
	}

	/**
	 * Adds an object to the end of the list.
	 * @param obj The object being added
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is a duplicate
	 * @return true if the object is added successfully
	 */
	@Override
	public boolean add(Object obj) {
		if (obj == null) {
		    throw new NullPointerException();
		}
		
		for(int i = 0; i < size; i++) {
		    if (list[i].equals(obj)) {
		        throw new IllegalArgumentException();
		    }
		}
		
		if (size == list.length) {
		    Object[] ll = new Object[size + RESIZE];
		    for (int i = 0; i < size; i++) {
		        ll[i] = list[i];
		    }
		    list = ll;
		}
		
		list[size] = obj;
		size++;
		
		return true;
	}

	/**
	 * Returns the element at the given index of the list.
	 * @param index The index being returned
	 * @return The object at the given index
	 */
	@Override
	public Object get(int index) {
		if (index < 0 || index >= size) {
		    throw new IndexOutOfBoundsException();
		}
		
		return list[index];
	}

	/**
	 * Adds an element to a particular index, then shifts the other elements to compensate.
	 * @param index The index to add an element
	 * @param element The element being added
	 */
	@Override
	public void add(int index, Object element) {
		if (element == null) {
		    throw new NullPointerException();
		}
		
		if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException();
        }
		
		int i = 0;
		
		for (i = 0; i < size; i++) {
		    if (list[i].equals(element)) {
		        throw new IllegalArgumentException();
		    }
		}
				
		if (size == list.length) {
            Object[] ll = new Object[size + RESIZE];
            for (i = 0; i < size; i++) {
                ll[i] = list[i];
            }
            list = ll;
        }
		
		for (i = size; i >= index; i--) {
		    list[i + 1] = list[i];
		}
		
		list[index] = element;
		size++;
		
	}

	/**
	 * Removes an object from the list and returns it, shifts other elements to compensate.
	 * @param index The index of the element to remove
	 * @return ret The removed object
	 */
	@Override
	public Object remove(int index) {
	    if (index >= size || index < 0) {
            throw new IndexOutOfBoundsException();
        }
        Object ret = list[index];
        for(int i = index; i < size - 1; i++) {
            list[i] = list[i + 1];
        }
        size--;
        return ret;
	}

	/**
	 * Returns the index of a given object.
	 * @param obj The object being searched for
	 * @return The index of the object if found, -1 otherwise
	 */
	@Override
	public int indexOf(Object obj) {
		if (obj == null) {
		    throw new NullPointerException();
		}
		
		for (int i = 0; i < size; i++) {
		    if (obj.equals(list[i])) {
		        return i;
		    }
		}
		return -1;
	}

}
