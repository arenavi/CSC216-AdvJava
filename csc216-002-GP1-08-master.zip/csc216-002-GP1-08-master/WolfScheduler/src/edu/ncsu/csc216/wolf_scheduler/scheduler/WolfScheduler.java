package edu.ncsu.csc216.wolf_scheduler.scheduler;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import edu.ncsu.csc216.wolf_scheduler.course.Course;
import edu.ncsu.csc216.wolf_scheduler.io.CourseRecordIO;

/**
 * Reads in and stores as a list all of the Course records stored in a file,
 * creates a schedule for the current user and provides functionality.
 * @author Amiya Renavikar
 */
public class WolfScheduler {
	
	/** Courses ArrayList */
	private ArrayList<Course> catalog;
	
	/** Schedule ArrayList */
	private ArrayList<Course> schedule;
	
	/** Schedule title */
	private String title;
	

	/**
	 * Constructs the WolfScheduler class.
	 * @param validTestFile test file
	 */
	public WolfScheduler(String validTestFile) {
		// TODO Auto-generated constructor stub
		catalog = new ArrayList<Course>();
		schedule = new ArrayList<Course>();
		title = "My Schedule";
		
		try {
			catalog = edu.ncsu.csc216.wolf_scheduler.io.CourseRecordIO.readCourseRecords(validTestFile);
			
		} catch (FileNotFoundException e) {
			
			System.out.println("Cannot find file");
		}
	}

	/**
	 * Returns a 2D String array of catalog, returns an empty String array
	 * if there are no Courses in the catalog.
	 * @return catalogs 2D String catalog array
	 */
	public String[][] getCourseCatalog() {
		// TODO Auto-generated method stub
		String[][] catalogs = new String[catalog.size()][3];
		
		if (catalog.size() == 0) {
			
			return catalogs;
		}
		
		for (int i = 0; i < catalog.size(); i++) {
			
			Course c1 = catalog.get(i);
			
			catalogs[i][0] = c1.getName();
			catalogs[i][1] = c1.getSection();
			catalogs[i][2] = c1.getTitle();
		}
		
		return catalogs;
	}

	/**
	 * Returns a 2D String array of schedule, returns an empty String array
	 * if there are no Courses in the schedule.
	 * @return courses 2D String schedule array
	 */
	public String[][] getScheduledCourses() {
		// TODO Auto-generated method stub
		
		String[][] courses = new String[schedule.size()][3];
		
		if (schedule.size() == 0) {
			
			return courses;
		}
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Course c2 = schedule.get(i);
			
			courses[i][0] = c2.getName();
			courses[i][1] = c2.getSection();
			courses[i][2] = c2.getTitle();
			
		}
		
		return courses;
	}

	/**
	 * Returns a 2D String array of the schedule with all information, or returns
	 * an empty String array if there are no Courses in the schedule.
	 * @return courses 2D String array
	 */
	public String[][] getFullScheduledCourses() {
		// TODO Auto-generated method stub
        String[][] courses = new String[schedule.size()][6];
        
        if (schedule.size() == 0) {
			
			return courses;
		}
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Course c3 = schedule.get(i);
			
			courses[i][0] = c3.getName();
			courses[i][1] = c3.getSection();
			courses[i][2] = c3.getTitle();
			courses[i][3] = Integer.toString(c3.getCredits());
			courses[i][4] = c3.getInstructorId();
			courses[i][5] = c3.getMeetingString();
			
		}
		
		return courses;
	}

	/**
	 * Return the Course title.
	 * @return title Course title
	 */
	public String getTitle() {
		// TODO Auto-generated method stub
		return title;
	}

	/**
	 * Receives a String parameter to save the student's schedule.
	 * @param fileName name of file
	 * @throws IllegalArgumentException if file not saved
	 */
	public void exportSchedule(String fileName) {
		// TODO Auto-generated method stub
		try {
			
			CourseRecordIO.writeCourseRecords(fileName, schedule);
		} catch (IOException e) {
			
			throw new IllegalArgumentException("The file cannot be saved.");
		}
		
	}

	/**
	 * Returns the Course from the catalog if found. Else returns null.
	 * @param name Course name
	 * @param section Course section
	 * @return Course if found, null otherwise
	 */
	public Course getCourseFromCatalog(String name, String section) {
		// TODO Auto-generated method stub
		for (int i = 0; i < catalog.size(); i++) {
			
			Course d = null;
			Course c = catalog.get(i);
			
			if (c.getName().equals(name) && c.getSection().equals(section)) {
				
				d = c;
				
				return d;
			}
		}
		
		return null;
	}

	/**
	 * Returns true if the given Course can be added to the student's schedule, false if Course is not in the catalog.
	 * @param name Course name
	 * @param section Course section
	 * @throws IllegalArgumentException if student is already enrolled in the Course
	 * @return true if Course added, false otherwise
	 */
	public boolean addCourse(String name, String section) {
		// TODO Auto-generated method stub
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Course a = schedule.get(i);
			
			if (a.getName().equals(name)) {
				
				throw new IllegalArgumentException("You are already enrolled in " + a.getName());
				
			}
			
		}
		
		for (int i = 0; i < catalog.size(); i++) {
			
			Course b = catalog.get(i);
			
			if (b.getName().equals(name) && b.getSection().equals(section)) {
				
				schedule.add(b);
				
				return true;
			}
			
		}
		
		return false;
	}

	/**
	 * Returns true if the given Course can be removed to the student's schedule, false if Course not in schedule.
	 * @param name Course name
	 * @param section Course section
	 * @return true if Course added, false otherwise
	 */
	public boolean removeCourse(String name, String section) {
		// TODO Auto-generated method stub
		
		for (int i = 0; i < schedule.size(); i++) {
			
			Course c = schedule.get(i);
			
			if (c.getName().equals(name) && c.getSection().equals(section)) {
				
				schedule.remove(c);
				
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Creates an empty ArrayList.
	 */
	public void resetSchedule() {
		// TODO Auto-generated method stub
		schedule = new ArrayList<Course>();		
	}

	/**
	 * Sets the title.
	 * @param title Course title
	 * @throws IllegalArgumentException if the title is null
	 */
	public void setTitle(String title) {
		// TODO Auto-generated method stub
		if (title == null) {
			
			throw new IllegalArgumentException("Title cannot be null");
		}
		
		this.title = title;
	}

}
