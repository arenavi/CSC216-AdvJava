package edu.ncsu.csc216.wolf_scheduler.io;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc216.wolf_scheduler.course.Course;

/**
 * Reads Course records from text files.  Writes a set of CourseRecords to a file.
 * 
 * @author Sarah Heckman
 */
public class CourseRecordIO {

    /**
     * Reads course records from a file and generates a list of valid Courses.  Any invalid
     * Courses are ignored.  If the file to read cannot be found or the permissions are incorrect
     * a File NotFoundException is thrown.
     * @param fileName file to read Course records from
     * @return a list of valid Courses
     * @throws FileNotFoundException if the file cannot be found or read
     */
	public static ArrayList<Course> readCourseRecords(String fileName) throws FileNotFoundException {
	    Scanner fileReader = new Scanner(new File(fileName));
	    ArrayList<Course> courses = new ArrayList<Course>();
	    while (fileReader.hasNextLine()) {
	        try {
	            Course course = readCourse(fileReader.nextLine());
	            boolean duplicate = false;
	            for (int i = 0; i < courses.size(); i++) {
	                Course c = courses.get(i);
	                if (course.getName().equals(c.getName()) &&
	                        course.getSection().equals(c.getSection())) {
	                    //it's a duplicate
	                    duplicate = true;
	                }
	            }
	            if (!duplicate) {
	                courses.add(course);
	            }
	        } catch (IllegalArgumentException e) {
	            //skip the line
	        }
	    }
	    fileReader.close();
	    return courses;
	}

	/**
	 * Reads line from the file and separates using delimiter.
	 * @param file file
	 * @return course course
	 * @throws FileNotFoundException if file is not found
	 */
	public static Course readCourse(String file) throws FileNotFoundException {
		
		Course c1 = null;
    	String name = null;
    	String title = null;
    	String id = null;
    	int credits = 0;
    	String insId = null;
    	String meetDays = null;
    	int start = 0;
    	int end = 0;
    	
    	try {
    		Scanner in = new Scanner(file);
        	
        	in.useDelimiter(",");
        	
        	while (in.hasNext()) {
        		name = in.next();
            	title = in.next();
            	id = in.next();
            	credits = in.nextInt();
            	insId = in.next();
            	meetDays = in.next();
            	
            	if (meetDays.equals("A") || meetDays.equals("a")) {
            		
            		c1 = new Course(name, title, id, credits, insId, meetDays);
            		
            	} else {
            	
            		start = in.nextInt();
            		end = in.nextInt();
            		c1 = new Course(name, title, id, credits, insId, meetDays, start, end);
            	}
        	}
    	
    	} catch (NoSuchElementException e) {
    		
    		throw new IllegalArgumentException();
    	}
    	
		return c1;
	}

	/**
     * Writes the list of Courses to the file.
     * @param fileName file name
     * @param courses ArrayList of Course
     * @throws IOException to catch exception
     */
    public static void writeCourseRecords(String fileName, ArrayList<Course> courses) throws IOException {
        
    	PrintStream write = new PrintStream(new File(fileName));
        
    	for (int i = 0; i < courses.size(); i++) {
    		
    		write.println(courses.get(i).toString());
    	}
    	write.close();
    }

}
