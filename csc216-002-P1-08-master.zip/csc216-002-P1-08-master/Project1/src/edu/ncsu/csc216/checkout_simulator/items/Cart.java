package edu.ncsu.csc216.checkout_simulator.items;

import java.awt.Color;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;

/**
 * Acts as the abstract parent class of the Cart hierarchy and contains
 * the common state and behavior for all shopping carts.
 * @author Amiya Renavikar
 */
public abstract class Cart {
	
	/** Initial register index of Cart */
	public static final int INITIAL_REGISTER_IDX = -1;
	
	/** Time when the cart leaves shopping area and enters a checkout register */
	private int arrivalTime;
	
	/** Number of seconds the cart waits in a checkout register line before processing */
	private int waitTime;
	
	/** Number of seconds required to check out at the register */
	private int processTime;
	
	/** Index of the register that the cart has selected */
	private int registerIndex;
	
	/** Whether the cart is waiting to process */
    private boolean waitingProcessing;
	
	/**
	 * Constructs the Cart class.
	 * @param arrivalTime time when cart enters a checkout register
	 * @param processTime time required to check out
	 */
	public Cart(int arrivalTime, int processTime) {
		
		this.setArrivalTime(arrivalTime);
		this.setProcessTime(processTime);
		this.registerIndex = INITIAL_REGISTER_IDX;
		waitingProcessing = false;
	}
	
	/**
	 * Sets the process time of the Cart.
	 * @param processTime Cart's process time
	 */
	public void setProcessTime(int processTime) {
        
        if (processTime < 0) {
            
            throw new IllegalArgumentException();
        }
        
        this.processTime = processTime;
    }

    /**
	 * Sets the arrival time of the Cart.
	 * @param arrivalTime Cart's arrival time
	 */
	public void setArrivalTime(int arrivalTime) {
       
	    if (arrivalTime < 0) {
	        
	        throw new IllegalArgumentException();
	    }
	    
	    this.arrivalTime = arrivalTime;
    }

    /**
	 * Returns the arrival time of the Cart.
	 * @return arrivalTime Cart's arrival time
	 */
	public int getArrivalTime() {
		
		return arrivalTime;
	}
	
	/**
	 * Returns the wait time of the Cart.
	 * @return waitTime Cart's wait time
	 */
	public int getWaitTime() {
		
		return waitTime;
	}
	
	/**
	 * Sets the wait time of the Cart.
	 * @param waitTime Cart's wait time
	 */
	public void setWaitTime(int waitTime) {
		
		this.waitTime = waitTime;
	}
	
	/**
	 * Returns the process time of the Cart.
	 * @return processTime Cart's process time
	 */
	public int getProcessTime() {
		
		return processTime;
	}
	
	/**
	 * Returns the register index of the Cart.
	 * @return registerIndex Cart's register index
	 */
	public int getRegisterIndex() {
		
		return registerIndex;
	}
	
	/**
	 * Returns whether the Cart is waiting in the Register line.
	 * @return waitingProcessing as true if Cart is waiting in Register line
	 */
	public boolean isWaitingInRegisterLine() {
		
		return waitingProcessing;
	}
	
	/**
	 * Removes the Cart from the waiting line.
	 */
	public void removeFromWaitingLine() {
		
		waitingProcessing = false;
	}
	
	/**
	 * Sets the register index of Cart.
	 * @param registerIndex register index
	 */
	protected void setRegisterIndex(int registerIndex) {
		
		this.registerIndex = registerIndex;
		
		if (registerIndex >= 0) {
		    
		    waitingProcessing = true;
		}
	}
	
	/**
	 * Gets the Cart in line for check out.
	 * @param register Checkout register array
	 */
	public abstract void getInLine(CheckoutRegister[] register);
	
	/**
	 * Returns the color of the Cart.
	 * @return color color of the Cart
	 */
	public abstract Color getColor();

}
