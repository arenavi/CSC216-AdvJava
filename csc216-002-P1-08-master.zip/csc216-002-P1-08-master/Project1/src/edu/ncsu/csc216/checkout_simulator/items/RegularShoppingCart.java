
package edu.ncsu.csc216.checkout_simulator.items;

import java.awt.Color;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;

/**
 * Implements the behavior for joining the line for a checkout register line that is not 
 * restricted to express carts and does not offer special handling.
 * @author Amiya Renavikar
 */
public class RegularShoppingCart extends Cart {
	
	/** Color of Cart */
	private static Color color;

	/**
	 * Constructs the RegularShoppingCart class.
	 * @param arrivalTime Cart's arrival time
	 * @param processTime Cart's process time
	 */
	public RegularShoppingCart(int arrivalTime, int processTime) {
		super(arrivalTime, processTime);
		
	}

	/**
	 * Gets the Cart in line to check out.
	 * @param register Checkout Register array
	 */
	@Override
	public void getInLine(CheckoutRegister[] register) {
	    int index = 1;
        for (int i = 2; i < register.length; i++) {
            
            if (register[i].size() < register[index].size()) {
                
                index = i;
            }
            
            
        }
        register[index].addCartToLine(this);
        super.setRegisterIndex(index);
  	
	}

	/**
	 * Returns the Color of the Cart.
	 * @return color Color of the Cart
	 */
	@Override
	public Color getColor() {
		
	    color = Color.BLUE;
		return color;
	}

}
