/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.queues;

import edu.ncsu.csc216.checkout_simulator.items.Cart;
import edu.ncsu.csc216.checkout_simulator.items.CartFactory;

/**
 * Contains the line of carts completing their shopping and entering the checkout area.
 * @author Amiya Renavikar
 */
public class Store implements LineOfItems {
	
	/** The queue of Carts created by the CartFactory */
	private ShoppingCartQueue shopping;
	
	/** Array of CheckoutRegisters */
    private CheckoutRegister[] register;
	
	
	/**
	 * Constructs the Store class.
	 * @param numCarts number of shopping carts
	 * @param register Array of CheckoutRegisters
	 */
	public Store(int numCarts, CheckoutRegister[] register) {
		
	    
	    this.register = register;
	    shopping = new ShoppingCartQueue();
	    for (int i = 0; i < numCarts; i++) {
	        
	        shopping.add(CartFactory.createCart());
	    }
	    
		
	}
	
	/**
	 * Returns the number of carts still in the shopping queue.
	 * @return the number of carts in the shopping queue
	 */
	public int size() {
		
		return shopping.size();
	}
	
	/**
	 * Returns true if the shopping queue is not empty.
	 * @return false if shopping is empty, if not, return true
	 */
	public boolean hasNext() {
	    
		if (shopping.isEmpty()) {
		    
		    return false;
		}
		
		return true;
	}
	
	/**
	 * Removes the front cart from the shopping queue and sends it a getInLine message
	 * and returns the removed cart.
	 * @return cart removed cart
	 */
	public Cart processNext() {
        
        Cart cart = shopping.remove();
        
        cart.getInLine(register);
        
        return cart;
	}
	
	/**
	 * Returns Integer.MAX_VALUE if the shopping queue is empty.
	 * @return Integer.MAX_VALUE max value
	 */
	public int departTimeNext() {
		
	    if (shopping.isEmpty()) {
            
            return Integer.MAX_VALUE;
        }
	    
		return shopping.front().getArrivalTime();
	}

}
