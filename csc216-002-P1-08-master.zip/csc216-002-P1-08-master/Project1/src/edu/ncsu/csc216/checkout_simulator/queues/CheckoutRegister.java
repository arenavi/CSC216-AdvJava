/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.queues;



import edu.ncsu.csc216.checkout_simulator.items.Cart;
import edu.ncsu.csc216.checkout_simulator.simulation.Log;

/**
 * Represents registers where carts line up to check out.
 * @author Amiya Renavikar
 */
public class CheckoutRegister implements LineOfItems {
	
	/** The ShoppingCartQueue of carts waiting for or being processed at this register */
	private ShoppingCartQueue line;
	
	/** The cart at the front of the line logs its information here during its actual checkout */
	private Log log;
	
	/** The time when the line for this checkout register will finally be clear all of carts currently in line */
	private int timeWhenAvailable;
	
	/**
	 * Constructs the CheckoutRegister class, initializes Log, and constructs line.
	 * @param log Log
	 */
	public CheckoutRegister(Log log) {
		
	    this.line = new ShoppingCartQueue();
		this.log = log;
	}
	
	/**
	 * Returns the number of carts still in line.
	 * @return line number of carts still in line
	 */
	public int size() {
		
		return line.size();
	}
	
	/**
	 * Returns true if the line is not empty.
	 * @return true if line is filled else return false
	 */
	public boolean hasNext() {
	    
		return !line.isEmpty();
	}
	
	
	
	/**
	 * Adds a cart to the end of the line, updates the cart's wait time,
	 * and the time when the line will be clear of all carts currently
	 * in the line.
	 * @param cart Cart that is to be added to the line
	 */
	public void addCartToLine(Cart cart) {
		
		if (line.size() == 0 || cart.getArrivalTime() == timeWhenAvailable) {
		    
		    timeWhenAvailable = cart.getArrivalTime() + cart.getProcessTime();
		    
		    cart.setWaitTime(0);
		    
		} else if (cart.getArrivalTime() <= timeWhenAvailable) {
		    
		    cart.setWaitTime(timeWhenAvailable - cart.getArrivalTime()); 
		    
		    timeWhenAvailable = timeWhenAvailable + cart.getProcessTime();
		}
		
		
		line.add(cart);
		
	}
	
	/**
     * Tells when the cart at the front of the line will finish
     * and leave simulation. If line is empty, returns the Integer.MAX_VALUE.
     * @return Integer.MAX_VALUE if line is empty else timeWhenAvailable
     */
    public int departTimeNext() {
        
        if (line.isEmpty()) {
            
            return Integer.MAX_VALUE;
        }
        
        return line.front().getWaitTime() + line.front().getArrivalTime() + line.front().getProcessTime();
    }

	/**
	 * Removes the front cart from the line and logs its 
	 * information and returns the removed cart.
	 */
	@Override
	public Cart processNext() {
	    
	    Cart cart = line.remove();
	    log.logCart(cart);
	        
	    cart.removeFromWaitingLine();
	        
	    return cart;
	   
	    
	    
	}

}
