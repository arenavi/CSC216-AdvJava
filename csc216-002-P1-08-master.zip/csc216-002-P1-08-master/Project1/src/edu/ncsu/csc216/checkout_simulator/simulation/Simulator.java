/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.simulation;

import java.awt.Color;

import edu.ncsu.csc216.checkout_simulator.items.Cart;
import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;
import edu.ncsu.csc216.checkout_simulator.queues.LineOfItems;
import edu.ncsu.csc216.checkout_simulator.queues.Store;

/**
 * Oversees the simulation, created the Store and CheckoutRegisters from user information,
 * steps through the simulation using its EventCalendar and reports the current state
 * of the simulation after each step using its Log.
 * @author Amiya Renavikar
 */
public class Simulator {
	
	/** Minimum number of Registers */
	private static final int MIN_NUM_REGISTERS = 3;
	
	/** Maximum number of Registers */
	private static final int MAX_NUM_REGISTERS = 12;
	
	/** Number of Registers */
	@SuppressWarnings("unused")
    private int numRegisters;
	
	/** Number of Carts */
	private int numCarts;
	
	/** Number of steps taken */
	private int stepsTaken;
	
	/** CheckoutRegister array */
	private CheckoutRegister[] register;
	
	/** Store object */
	private Store theStore;
	
	/** EventCalendar object */
	private EventCalendar theCalendar;
	
	/** Cart object */
	private Cart currentCart;
	
	/** Log object */
	private Log myLog;
	
	/**
	 * Creates a store, an array of CheckoutRegisters, creates the Log to keep
	 * track of statistics and an EventCalendar to control the order of events.
	 * @param numCarts number of carts
	 * @param numRegisters number of registers
	 */
	public Simulator (int numRegisters, int numCarts) {
	    if (numRegisters > MAX_NUM_REGISTERS || numRegisters < MIN_NUM_REGISTERS) {
	           
	        throw new IllegalArgumentException("Number of registers must be between 3 and 12 inclusive");
	    }
	    
	    if (numCarts < 1) {
	        
	        throw new IllegalArgumentException("There must be at least one shopping cart in the simulation.");
	    }
	    
	    myLog = new Log();
	  
	    register = new CheckoutRegister[numRegisters];
	    for (int i = 0; i < register.length; i++) {
	       
	       register[i] = new CheckoutRegister(myLog);
	    }
	    theStore = new Store(numCarts, register);
	    theCalendar = new EventCalendar(register, theStore);
	   
	    this.numCarts = numCarts;
	    this.numRegisters = numRegisters;
	}
	
	/**
	 * Returns the simulation colors.
	 * @return simulation colors
	 */
	public static Color[] simulationColors() {
		
	    Color[] colors = new Color[3];
	    
	    colors[0] = Color.GREEN;
	    colors[1] = Color.BLUE;
	    colors[2] = Color.RED;
	    
		return colors;
	}
	
	/**
	 * Returns the simulation labels.
	 * @return simulation labels
	 */
	public static String[] simulationLabels() {
		
	    String[] s = new String[3];
	    
	    s[0] = "Express Cart";
	    s[1] = "Regular Cart";
	    s[2] = "Special Handling Cart";
	    
		return s;
	}
	
	/**
	 * Handles the next event from the EventCalendar.
	 */
	public void step() {
		
	    currentCart = null; 
	    LineOfItems l = theCalendar.nextToBeProcessed();
	    if (l.hasNext()) {
	      
	        currentCart = l.processNext();
	        stepsTaken++;
	    }
	    
	}
	
	/**
	 * Returns the number of steps taken so far.
	 * @return stepsTaken number of steps taken
	 */
	public int getStepsTaken() {
		
		return stepsTaken;
	}
	
	/**
	 * Returns the total number of steps in the simulation.
	 * @return total number of steps in simulation
	 */
	public int totalNumberOfSteps() {
		
		return 2 * numCarts;
	}
	
	/**
	 * Returns true if simulation is not finished, false if finished.
	 * @return true if simulation not finished, false if finished
	 */
	public boolean moreSteps() {
		
	    if (myLog.getNumCompleted() == numCarts) {
	        
	        return false;
	    }
		return true;
	}
	
	/**
	 * Returns the index of CheckoutRegister selected by currentCart, -1
	 * if the current cart is null.
	 * @return index of CheckoutRegister selected by currentCart, -1
	 * if the current cart is null
	 */
	public int getCurrentIndex() {
		
	    if (currentCart == null) {
	        
	        return -1;
	    }
	        
	    return currentCart.getRegisterIndex();
	    
	}
	
	/**
	 * Returns the Color of the current cart, null if current cart is null.
	 * @return Color of the current cart, null if current cart is null
	 */
	public Color getCurrentCartColor() {
		
	    if (currentCart == null) {
	        
	        return null;
	    }
		return currentCart.getColor();
	}
	
	/**
	 * Returns true if the most recently handled cart completed checking out and 
	 * left a register line; false if the most recently handled cart left the shopping 
	 * area to enter a register line or if there is no current cart.
	 * @return true if cart leaves register line, false if Cart enters or if no current cart
	 */
	public boolean itemLeftSimulation() {
	    
	    if (currentCart == null || currentCart.isWaitingInRegisterLine()) {
	        
	        return false;
	        
	    }
	    
	    return true;
	    
	}
	
	/**
	 * Returns the average number of seconds that carts
	 * wait prior to checking out.
	 * @return average wait time as a double
	 */
	public double averageWaitTime() {
		
		return myLog.averageWaitTime();
	}
	
	/**
	 * Returns the average number of seconds that carts spent in checking out.
	 * @return average process time as a double
	 */
	public double averageProcessTime() {
		
		return myLog.averageProcessTime();
	}

}
