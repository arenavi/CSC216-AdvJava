
package edu.ncsu.csc216.checkout_simulator.items;

import java.awt.Color;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;

/**
 * Implements the behavior of an express cart for joining an appropriate
 * checkout register line.
 * @author Amiya Renavikar
 */
public class ExpressCart extends Cart {
	
	/** Color of cart */
	private static Color color;

	/**
	 * Constructs the Express Cart class.
	 * @param arrivalTime Cart's arrival time
	 * @param processTime Cart's process time
	 */
	public ExpressCart(int arrivalTime, int processTime) {
		super(arrivalTime, processTime);
		
	}

	/**
	 * Gets the Cart in line to check out.
	 * @param register Checkout Register array
	 */
	@Override
	public void getInLine(CheckoutRegister[] register) {
	    
	    int index = 0;
	    for (int i = 1; i < register.length; i++) {
            
            if (register[i].size() < register[index].size()) {
                
                index = i;
            }
            
            
        }
	   
	    register[index].addCartToLine(this);
	    super.setRegisterIndex(index);
	}

	/**
	 * Returns the Color of the Cart.
	 * @return color Color of the Cart
	 */
	@Override
	public Color getColor() {
		
	    color = Color.GREEN;
	    
		return color;
	}

}
