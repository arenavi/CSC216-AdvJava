/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.simulation;

import edu.ncsu.csc216.checkout_simulator.items.Cart;

/**
 * Handles logging of the the Cart.
 * @author Amiya Renavikar
 */
public class Log {
	
	/** The number of carts that have checked out and left the simulation */
	private int numCompleted;
	
	/** The sum of all wait times logged by carts that have checked out so far */
	private int totalWaitTime;
	
	/** The sum of all times that carts took to actually check out at registers */
	private int totalProcessTime;
	
	/**
	 * Constructs the Log class.
	 */
	public Log() {
		
	    numCompleted = 0;
	    totalWaitTime = 0;
	    totalProcessTime = 0;
		
	}
	
	/**
	 * Returns the number of carts that have checked out and left the simulation.
	 * @return numCompleted the number of carts that have checked out and left the simulation
	 */
	public int getNumCompleted() {
		
		return numCompleted;
	}
	
	/**
	 * Logs the Cart into the simulation.
	 * @param c Cart that is being logged in
	 */
	public void logCart(Cart c) {
		
		if (c != null) {
		    
		    numCompleted++;
		    totalWaitTime += c.getWaitTime();
		    totalProcessTime += c.getProcessTime();
		}
	}
	
	/**
	 * Returns the average wait time of the Cart as a double.
	 * @return average wait time of Cart
	 */
	public double averageWaitTime() {
		
	    if (numCompleted == 0) {
	        
	        return 0;
	    }
	    double avgW = (double) totalWaitTime / numCompleted;
		return avgW;
	}
	
	/**
	 * Returns the average process time of the Cart as a double.
	 * @return average process time of Cart
	 */
	public double averageProcessTime() {
		
	    if (numCompleted == 0) {
            
            return 0;
        }
	    double avgP = (double) totalProcessTime / numCompleted;
		return avgP;
	}

}
