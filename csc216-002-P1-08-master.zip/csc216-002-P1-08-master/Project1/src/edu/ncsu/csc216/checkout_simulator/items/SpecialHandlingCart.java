
package edu.ncsu.csc216.checkout_simulator.items;

import java.awt.Color;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;

/**
 * Implements the behavior for joining a line of a register 
 * that can provide special handling.
 * @author Amiya Renavikar
 */
public class SpecialHandlingCart extends Cart {

	/** Color of Cart */
	private static Color color;
	
	/**
	 * Constructs the Special Handling Cart class.
	 * @param arrivalTime Cart's arrival time
	 * @param processTime Cart's process time
	 */
	public SpecialHandlingCart(int arrivalTime, int processTime) {
		super(arrivalTime, processTime);
		
	}


	/**
	 * Gets the Cart in line to check out.
	 * @param register Checkout Register array
	 */
	@Override
	public void getInLine(CheckoutRegister[] register) {
	    
	    int value = register.length / 4;
	    
	    int mod = register.length % 4;
	    
	    int index = 0;
	    
	    if (mod != 0) {
	        
	        index = register.length - value - 1;
	    } else {
	        
	        index = register.length - value;
	    }
	    
	    for (int i = index + 1; i < register.length; i++) {
            
            if (register[i].size() < register[index].size()) {
                
                index = i;
            }
            
            
        }
	    register[index].addCartToLine(this);
        super.setRegisterIndex(index);
   	
	}


	/**
	 * Returns the Color of the Cart.
	 * @return color Color of the Cart
	 */
	@Override
	public Color getColor() {
		
	    color = Color.RED;
		return color;
	}

}
