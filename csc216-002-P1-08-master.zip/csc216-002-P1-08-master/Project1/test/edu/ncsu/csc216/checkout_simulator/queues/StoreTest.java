/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.queues;

import static org.junit.Assert.*;
import org.junit.Test;
import edu.ncsu.csc216.checkout_simulator.simulation.Log;

/**
 * Tests the Store class.
 * @author Amiya Renavikar
 */
public class StoreTest {
    
    private static final int SIZE = 10;
    
    private CheckoutRegister[] register;
    
    
    /**
     * Tests the Store class constructor.
     */
    @Test
    public void testStoreTest() {
        
        Store s = new Store(SIZE, register);
        
        assertEquals(10, s.size());
   
    }
    
    /**
     * Tests the size method.
     */
    @Test
    public void testSize() {
        
        Log l = new Log();
        register = new CheckoutRegister[3];
        for (int i = 0; i < register.length; i++) {
            
            register[i] = new CheckoutRegister(l);
        }
        Store s = new Store(10, register);
        assertEquals(10, s.size());
              
    }
    
    /**
     * Tests the hasNext() method.
     */
    @Test
    public void testHasNext() {
        
        Store s = new Store(0, register);
        assertFalse(s.hasNext());
        
    }
    
    /**
     * Tests the processNext method.
     */
    @Test
    public void testProcessNext() {
        
        Log l = new Log();
        CheckoutRegister[] r = new CheckoutRegister[3];
        for (int i = 0; i < r.length; i++) {
            
            r[i] = new CheckoutRegister(l);
        }
        Store s = new Store(3, r);
       
        s.processNext();
        assertEquals(2, s.size());
        
    }

}
