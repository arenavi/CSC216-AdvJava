/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.simulation;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Test;

/**
 * Tests the Simulator class.
 * @author Amiya Renavikar
 */
public class SimulatorTest {
    
    /**
     * Tests the Simulator constructor.
     */
    @Test
    public void testSimulator() {
        
        Simulator sim = new Simulator(4, 2);
        
        assertEquals(0.0, sim.averageWaitTime(), 0.01);
        assertEquals(0.0, sim.averageProcessTime(), 0.01);
        assertEquals(Color.GREEN, Simulator.simulationColors()[0]);
        assertEquals(Color.BLUE, Simulator.simulationColors()[1]);
        assertEquals("Express Cart", Simulator.simulationLabels()[0]);
        
        
        
    }
    
    
    /**
     * Tests the step method.
     */
    @Test
    public void testStep() {
        Simulator sim = new Simulator(5, 2);
        
        assertEquals(4, sim.totalNumberOfSteps());
        assertEquals(0, sim.getStepsTaken());
        
        sim.step();
        sim.step();
        assertEquals(2, sim.getStepsTaken());
            
    }
    
    /**
     * Tests the getStepsTaken method.
     */
    @Test
    public void testGetStepsTaken() {
        
        Simulator sim = new Simulator(4, 6);
        assertEquals(0, sim.getStepsTaken());
        sim.step();
        assertEquals(1, sim.getStepsTaken());
    }
    
    /**
     * Tests the totalNumberOfSteps method.
     */
    @Test
    public void testTotalNumberOfSteps() {
        
        Simulator sim = new Simulator(4, 6);
        assertEquals(12, sim.totalNumberOfSteps());
        
        
    }
    
    /**
     * Tests the moreSteps method.
     */
    @Test
    public void testMoreSteps() {
        
        Simulator sim2 = new Simulator(5, 1);
        assertTrue(sim2.moreSteps());
    }
    
    /**
     * Tests the getCurrentIndex method.
     */
    @Test
    public void testGetCurrentIndex() {
        
        Simulator sim = new Simulator(5, 1);
        assertEquals(-1, sim.getCurrentIndex());
    }
    
    /**
     * Tests the getCurrentCartColor method.
     */
    @Test
    public void testGetCurrentCartColor() {
        
        Simulator sim = new Simulator(5, 1);
        assertNull(sim.getCurrentCartColor());
        
    }
    
    /**
     * Tests the itemLeftSimulation method.
     */
    @Test
    public void testItemLeftSimulation() {
        
        Simulator sim = new Simulator(5, 1);
        assertFalse(sim.itemLeftSimulation());
    }
    
}
