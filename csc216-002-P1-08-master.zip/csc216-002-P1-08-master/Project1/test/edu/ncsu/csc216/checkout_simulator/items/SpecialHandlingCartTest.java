/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.items;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;
import edu.ncsu.csc216.checkout_simulator.simulation.Log;

/**
 * Tests the SpecialHandlingCart class.
 * @author Amiya Renavikar
 */
public class SpecialHandlingCartTest {

    private CheckoutRegister[] registers = new CheckoutRegister[10];
    
    private static final int ARRIVAL_TIME = 0; 

    private static final int INVALID_ARRIVAL_TIME = -2;
    
    private static final int PROCESS_TIME = 75;
    
    private static final int INVALID_PROCESS_TIME = -5;
    
    /**
     * Set up method to set up testing environment.
     */
    @Before
    public void setUp() {
        
        Log log = new Log();
        
        for (int i = 0; i < registers.length; i++) {
            
            registers[i] = new CheckoutRegister(log);
        }
    }
    
    /**
     * Tests the SpecialHandling constructor.
     */
    @Test
    public void testSpecialHandlingCart() {
        
        Cart cart = null;
        
        //Invalid arrival time
        try {
            
            cart = new SpecialHandlingCart(INVALID_ARRIVAL_TIME, PROCESS_TIME);
            fail();
            
        } catch (IllegalArgumentException e) {
            
            assertNull(cart);
        }
        
        //Invalid process time
        try {
            
            cart = new SpecialHandlingCart(ARRIVAL_TIME, INVALID_PROCESS_TIME);
            fail();
            
        } catch (IllegalArgumentException e) {
            
            assertNull(cart);
        }
        
      //Valid test
        try {
            
            cart = new SpecialHandlingCart(ARRIVAL_TIME, PROCESS_TIME);
            
        } catch (IllegalArgumentException e) {
            
            fail();
        }
        
    }
    
    /**
     * Tests the getInLine() method.
     */
    @Test
    public void testGetInLine() {
        
        ExpressCart e = new ExpressCart(20, 95);
        SpecialHandlingCart s = new SpecialHandlingCart(ARRIVAL_TIME, PROCESS_TIME); 
        RegularShoppingCart r1 = new RegularShoppingCart(50, 100);
        
        
        e.getInLine(registers);
        
        s.getInLine(registers);
        
        r1.getInLine(registers);
        
        assertEquals(e.getRegisterIndex(), 0);
        assertEquals(s.getProcessTime(), 75);
        assertEquals(registers[1].size(), 1);
    }
    
    /**
     * Tests the getColor() method.
     */
    @Test
    public void testGetColor() {
        
        SpecialHandlingCart e1 = new SpecialHandlingCart(ARRIVAL_TIME, PROCESS_TIME);
      
        assertEquals(e1.getColor(), Color.RED);
    }
}
