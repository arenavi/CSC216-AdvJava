/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.items;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;
import edu.ncsu.csc216.checkout_simulator.simulation.Log;

/**
 * Tests the RegularShoppingCart class.
 * @author Amiya Renavikar
 */
public class RegularShoppingCartTest {

    private CheckoutRegister[] registers = new CheckoutRegister[10];
    
    private static final int ARRIVAL_TIME = 27; 

    private static final int INVALID_ARRIVAL_TIME = -5;
    
    private static final int PROCESS_TIME = 100;
    
    private static final int INVALID_PROCESS_TIME = -1;
    
    /**
     * Set up method to set up testing environment.
     */
    @Before
    public void setUp() {
        
        Log log = new Log();
        
        for (int i = 0; i < registers.length; i++) {
            
            registers[i] = new CheckoutRegister(log);
        }
    }
    
    /**
     * Tests the RegularShoppingCart constructor.
     */
    @Test
    public void testRegularShoppingCart() {
        
        Cart cart = null;
        
        //Invalid arrival time
        try {
            
            cart = new RegularShoppingCart(INVALID_ARRIVAL_TIME, PROCESS_TIME);
            fail();
            
        } catch (IllegalArgumentException e) {
            
            assertNull(cart);
        }
        
        //Invalid process time
        try {
            
            cart = new RegularShoppingCart(ARRIVAL_TIME, INVALID_PROCESS_TIME);
            fail();
            
        } catch (IllegalArgumentException e) {
            
            assertNull(cart);
        }
        
      //Valid test
        try {
            
            cart = new RegularShoppingCart(ARRIVAL_TIME, PROCESS_TIME);
            
        } catch (IllegalArgumentException e) {
            
            fail();
        }
        
    }
    
    /**
     * Tests the getInLine() method.
     */
    @Test
    public void testGetInLine() {
        
        RegularShoppingCart e1 = new RegularShoppingCart(ARRIVAL_TIME, PROCESS_TIME); 
        RegularShoppingCart e2 = new RegularShoppingCart(30, 80); 
        
        
        e1.getInLine(registers);
        
        e2.getInLine(registers);
        
        assertEquals(e1.getRegisterIndex(), 1);
        assertEquals(e2.getRegisterIndex(), 2);
        assertEquals(registers[1].size(), 1);
    }
    
    /**
     * Tests the getColor() method.
     */
    @Test
    public void testGetColor() {
        
        RegularShoppingCart e1 = new RegularShoppingCart(ARRIVAL_TIME, PROCESS_TIME);
      
        assertEquals(e1.getColor(), Color.BLUE);
    }
}
