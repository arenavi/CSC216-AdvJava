/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.items;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

import edu.ncsu.csc216.checkout_simulator.queues.CheckoutRegister;
import edu.ncsu.csc216.checkout_simulator.simulation.Log;

/**
 * Tests the ExpressCart class.
 * @author Amiya Renavikar
 */
public class ExpressCartTest {
    
    private CheckoutRegister[] registers = new CheckoutRegister[10];
    
    private static final int ARRIVAL_TIME = 20; 

    private static final int INVALID_ARRIVAL_TIME = -2;
    
    private static final int PROCESS_TIME = 75;
    
    private static final int INVALID_PROCESS_TIME = -5;
    
    /**
     * Set up method to set up testing environment.
     */
    @Before
    public void setUp() {
        
        Log log = new Log();
        for (int i = 0; i < registers.length; i++) {
            
            registers[i] = new CheckoutRegister(log);
        }
    }
    
    /**
     * Tests the ExpressCart constructor.
     */
    @Test
    public void testExpressCart() {
        
        Cart cart = null;
        
        //Invalid arrival time
        try {
            
            cart = new ExpressCart(INVALID_ARRIVAL_TIME, PROCESS_TIME);
            fail();
            
        } catch (IllegalArgumentException e) {
            
            assertNull(cart);
        }
        
        //Invalid process time
        try {
            
            cart = new ExpressCart(ARRIVAL_TIME, INVALID_PROCESS_TIME);
            fail();
            
        } catch (IllegalArgumentException e) {
            
            assertNull(cart);
        }
        
      //Valid test
        try {
            
            cart = new ExpressCart(ARRIVAL_TIME, PROCESS_TIME);
            
        } catch (IllegalArgumentException e) {
            
            fail();
        }
        
    }
    
    /**
     * Tests the getInLine() method.
     */
    @Test
    public void testGetInLine() {
        
        ExpressCart e1 = new ExpressCart(ARRIVAL_TIME, PROCESS_TIME); 
        ExpressCart e2 = new ExpressCart(30, 80); 
        
        
        e1.getInLine(registers);
        
        e2.getInLine(registers);
        
        assertEquals(e1.getRegisterIndex(), 0);
        assertEquals(e2.getRegisterIndex(), 1);
        assertEquals(registers[1].size(), 1);
    }
    
    /**
     * Tests the getColor() method.
     */
    @Test
    public void testGetColor() {
        
      ExpressCart e1 = new ExpressCart(ARRIVAL_TIME, PROCESS_TIME);
      
      assertEquals(e1.getColor(), Color.GREEN);
    }
}
