/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.simulation;

import static org.junit.Assert.*;
import org.junit.Test;

import edu.ncsu.csc216.checkout_simulator.items.Cart;
import edu.ncsu.csc216.checkout_simulator.items.ExpressCart;
import edu.ncsu.csc216.checkout_simulator.items.RegularShoppingCart;

/**
 * Tests the Log class.
 * @author Amiya Renavikar
 */
public class LogTest {

    /**
     * Tests the Log constructor.
     */
    @Test
    public void testLog() {
        
        Log log = new Log();
        assertEquals(0.0, log.averageProcessTime(), 0.01);
        assertEquals(0.0, log.averageWaitTime(), 0.01);
        Cart c1 = new ExpressCart(10, 30);
        Cart c2 = new RegularShoppingCart(40, 75);
        log.logCart(c1);
        log.logCart(c2);
        assertEquals(52.5, log.averageProcessTime(), 0.01);
        
        
    }
    
    /**
     * Tests the getNumCompleted method.
     */
    @Test 
    public void testGetNumCompleted() {
        
        Log l = new Log();
        assertEquals(0, l.getNumCompleted());
    }
    
    /**
     * Tests the logCart method.
     */
    @Test
    public void testLogCart() {
        
        Log l = new Log();
        Cart c1 = new ExpressCart(1, 1);
        Cart c2 = new ExpressCart(2, 3);
        l.logCart(c1);
        l.logCart(c2);
        assertEquals(2, l.getNumCompleted());
        
    }
    
}
