/**
 * 
 */
package edu.ncsu.csc216.checkout_simulator.queues;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc216.checkout_simulator.items.Cart;
import edu.ncsu.csc216.checkout_simulator.items.ExpressCart;
import edu.ncsu.csc216.checkout_simulator.items.RegularShoppingCart;
import edu.ncsu.csc216.checkout_simulator.simulation.Log;

/**
 * Tests the CheckoutRegister class.
 * @author Amiya Renavikar
 */
public class CheckoutRegisterTest {
   
    
    /**
     * Tests the size method.
     */
    @Test
    public void testSize() {
        
        Log l = new Log();
        CheckoutRegister check = new CheckoutRegister(l);
        
        assertEquals(0, check.size());
        
    }
    
    /**
     * Tests the hasNext method.
     */
    @Test
    public void testHasNext() {
        
        Log log = new Log();
        LineOfItems l = new CheckoutRegister(log);
        assertFalse(l.hasNext());
  
    }
    
    /**
     * Tests the departTimeNext method.
     */
    @Test
    public void testDepartTimeNext() {
        
        Log log = new Log();
        LineOfItems l = new CheckoutRegister(log);
        
        assertEquals(Integer.MAX_VALUE, l.departTimeNext());
        

    }
    
    /**
     * Tests the addCartToLine method.
     */
    @Test
    public void testAddCartToLine() {
        
        Cart c = new ExpressCart(20, 200);
        
        Log l = new Log();
        
        CheckoutRegister c1 = new CheckoutRegister(l);
        
        c1.addCartToLine(c);
        
        assertEquals(1, c1.size());
        
    }
    
    /**
     * Tests the processNext method.
     */
    @Test
    public void testProcessNext() {

        Log l = new Log();
        CheckoutRegister ch = new CheckoutRegister(l);
        //add carts
        assertEquals(0, ch.size());
        Cart c1 = new RegularShoppingCart(30, 250);
        ch.addCartToLine(c1);
        Cart c2 = new RegularShoppingCart(50, 200);
        ch.addCartToLine(c2);
        
        ch.processNext();
        
        assertEquals(1, ch.size());
        
        
        
    }
    
}
